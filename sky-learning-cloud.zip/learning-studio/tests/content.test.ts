import assert from "node:assert/strict";
import { randomUUID } from "node:crypto";
import { mock, test } from "node:test";
import { retrieve, splitPosition, validateAnswer, validateKit } from "../lib/content.ts";
import { deepSeekJson, testModelConnection } from "../lib/deepseek.ts";
import { kitInput } from "../lib/contracts.ts";

const first = {
  id: randomUUID(), sourceId: randomUUID(), position: 2, part: 1,
  text: "A to-infinitive can express purpose, as in I went out to buy milk.",
};
const second = { ...first, id: randomUUID(), sourceId: randomUUID(), text: "A participle can modify a noun." };
const ref = { chunkId: first.id, quote: "A to-infinitive can express purpose" };
const answer = { status: "answered", sections: [{ text: "不定式可以表目的。", refs: [ref] }] };
const kit = {
  title: "非谓语动词",
  concepts: [{ key: "a", title: "不定式表目的", explanation: "to buy milk 表示外出的目的。", refs: [ref] }],
  route: [{ title: "识别目的", action: "说出动作和目的。", conceptKeys: ["a"] }],
  questions: [{
    prompt: "外出的目的是什么？", answer: "买牛奶。", explanation: "to buy milk 说明 went out 的目的。",
    conceptKeys: ["a"], refs: [ref],
  }],
};

test("引用只能指向提交给模型的片段及其中的原句", () => {
  assert.deepEqual(validateAnswer(answer, [first]), {
    status: "answered", sections: [{ text: "不定式可以表目的。", refs: [{ ...ref, sourceId: first.sourceId, position: 2, part: 1 }] }],
  });
  assert.throws(() => validateAnswer(answer, [second]), /引用无法/);
  assert.throws(() => validateAnswer(answer, [{ ...first, text: "Unrelated text" }]), /引用无法/);
  assert.deepEqual(validateAnswer({ status: "insufficient" }, [first]), { status: "insufficient" });
});

test("双语检索与长片段切分", () => {
  const text = "非谓语动词包含不定式、动名词和分词。 ".repeat(150);
  const pieces = splitPosition(text);
  assert.ok(pieces.length > 1 && pieces.every((piece) => piece.length <= 1150));
  const irrelevant = Array.from({ length: 15 }, () => ({ ...second, id: randomUUID() }));
  assert.equal(retrieve("不定式 infinitive 有哪些用法？", [...irrelevant, { ...first, text }])[0].id, first.id);
});

test("章节数量问题优先检索同一来源多页目录", () => {
  const sourceId = randomUUID();
  const contents = [
    { ...first, sourceId, position: 16, text: "目录　第一篇　基础" },
    { ...first, sourceId, id: randomUUID(), position: 17, text: "第一章 导论　第二章 词法" },
    { ...first, sourceId, id: randomUUID(), position: 18, text: "第二篇 进阶　第一章 句法　第二章 时态" },
  ];
  const distractors = Array.from({ length: 20 }, (_, index) => ({
    ...second, id: randomUUID(), position: 60 + index, text: "多少章节：本页只有一条例句。",
  }));
  assert.deepEqual(retrieve("有多少章节？", [...distractors, ...contents]).slice(0, 3), contents);
  assert.deepEqual(retrieve("How many chapters are there?", [...distractors, ...contents]).slice(0, 3), contents);
});

test("讲义、自测和路线共用知识点 ID，并拒绝不存在的知识点", () => {
  const a = validateKit(kit, [first]);
  const b = validateKit({
    ...kit,
    concepts: kit.concepts.map((item) => ({ ...item, key: "b" })),
    route: kit.route.map((item) => ({ ...item, conceptKeys: ["b"] })),
    questions: kit.questions.map((item) => ({ ...item, conceptKeys: ["b"] })),
  }, [first]);
  assert.equal(a.concepts[0].id, b.concepts[0].id);
  assert.equal(a.questions[0].conceptIds[0], a.concepts[0].id);
  assert.throws(() => validateKit({ ...kit, concepts: [{}] }, [first]), /JSON/);
  assert.throws(() => validateKit({ ...kit, route: [{ ...kit.route[0], conceptKeys: ["missing"] }] }, [first]), /未定义/);
});

test("复习资料工作台保留有出处的闪卡与可选的分层自测", () => {
  const { skill } = kitInput.parse({
    skill: "study-review-workbench", sources: [{ sourceId: first.sourceId }],
  });
  assert.throws(() => validateKit(kit, [first], skill), /缺少大纲、闪卡/);
  const review = {
    overview: "本段讲解不定式表目的。",
    cards: [{ front: "不定式可以表示什么？", back: "目的。", conceptKeys: ["a"], refs: [ref] }],
    relations: [],
  };
  const short = validateKit({ ...kit, review }, [first], skill);
  assert.equal(short.examOverview, undefined);
  assert.deepEqual(short.review?.cards[0].conceptIds, [short.concepts[0].id]);
  assert.equal(short.review?.cards[0].refs[0].quote, ref.quote);
  const chapter = validateKit({
    ...kit, review, examOverview: "目的用法 → 例句辨析",
    questions: [{ ...kit.questions[0], level: "understanding" }],
  }, [first], skill);
  assert.equal(chapter.examOverview, "目的用法 → 例句辨析");
  assert.equal(chapter.questions[0].level, "understanding");
  assert.throws(() => validateKit({
    ...kit, review: { ...review, cards: [{ ...review.cards[0], refs: [{ ...ref, quote: "Wrong quote" }] }] },
  }, [first], skill), /引用无法/);
});

test("DeepSeek 调用能区分缺少密钥、无效 JSON 与超时", async () => {
  const originalKey = process.env.DEEPSEEK_API_KEY;
  delete process.env.DEEPSEEK_API_KEY;
  try {
    await assert.rejects(deepSeekJson([]), { status: 503, message: /模型服务尚未配置/ });
    process.env.DEEPSEEK_API_KEY = "test-key";
    const fetchMock = mock.method(globalThis, "fetch", async () => Response.json({
      choices: [{ finish_reason: "stop", message: { content: " " } }],
    }));
    await assert.rejects(deepSeekJson([]), /两次未返回有效的 JSON/);
    assert.equal(fetchMock.mock.callCount(), 2);
    fetchMock.mock.mockImplementation(async (_url: URL | RequestInfo, init?: RequestInit) =>
      new Promise<Response>((_resolve, reject) => {
        const signal = init?.signal;
        const timer = setTimeout(() => reject(new Error("test deadline")), 200);
        signal?.addEventListener("abort", () => { clearTimeout(timer); reject(signal.reason); }, { once: true });
      }));
    await assert.rejects(deepSeekJson([], 10), /响应超时/);
  } finally {
    mock.restoreAll();
    if (originalKey === undefined) delete process.env.DEEPSEEK_API_KEY;
    else process.env.DEEPSEEK_API_KEY = originalKey;
  }
});

test("连接测试在模型返回空白时补试，并验证结构化结果", async (context) => {
  const connection = { baseUrl: "https://api.deepseek.com", model: "deepseek-flash", key: "test-key" };
  const requests: RequestInit[] = [];
  const completion = (content: string) => Response.json({
    choices: [{ finish_reason: "stop", message: { content } }],
  });
  const fetchMock = context.mock.method(globalThis, "fetch", async (_url: unknown, request: RequestInit) => {
    requests.push(request);
    return completion(requests.length === 1 ? "  " : '```json\n{"ok":true}\n```');
  });
  await testModelConnection(connection);
  assert.equal(requests.length, 2);
  assert.equal(requests[0].signal, requests[1].signal);
  assert.match(String(requests[0].body), /Output example/);
  fetchMock.mock.mockImplementation(async () => completion("{}"));
  await assert.rejects(testModelConnection(connection), /未通过 JSON 输出测试/);
  fetchMock.mock.mockImplementation(async () => new Response("<!doctype html>"));
  await assert.rejects(testModelConnection(connection), /请检查 API 地址/);
});

test("连接遇到短暂断开时自动补试，认证失败直接提示", async (context) => {
  const connection = { baseUrl: "https://api.example.test", model: "test", key: "test-key" };
  let requests = 0;
  const fetchMock = context.mock.method(globalThis, "fetch", async () => {
    if (++requests === 1) throw new TypeError("fetch failed", { cause: { code: "ECONNRESET" } });
    return Response.json({ choices: [{ finish_reason: "stop", message: { content: '{"ok":true}' } }] });
  });
  await testModelConnection(connection);
  assert.equal(requests, 2);
  fetchMock.mock.mockImplementation(async () => new Response(null, { status: 401 }));
  await assert.rejects(testModelConnection(connection), /认证失败/);
  assert.equal(fetchMock.mock.callCount(), 3);
});
