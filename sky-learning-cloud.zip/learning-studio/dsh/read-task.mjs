import { readFileSync } from "node:fs";

export const name = "learning-studio-task";

export function apply(ctx) {
  const task = readFileSync("task.txt", "utf8");
  ctx.provide("headlessStartup", { task });
}
