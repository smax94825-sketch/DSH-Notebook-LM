param(
  [Parameter(Mandatory=$true)][string]$Manifest,
  [Parameter(Mandatory=$true)][string]$Language
)
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Speech
$voice = New-Object System.Speech.Synthesis.SpeechSynthesizer
try {
  $match = $voice.GetInstalledVoices() | Where-Object {
    $_.Enabled -and $_.VoiceInfo.Culture.Name.StartsWith($Language.Substring(0,2), [StringComparison]::OrdinalIgnoreCase)
  } | Select-Object -First 1
  if (!$match) { throw "VOICE_UNAVAILABLE $Language" }
  $voice.SelectVoice($match.VoiceInfo.Name)
  $voice.Rate = 0
  $format = New-Object System.Speech.AudioFormat.SpeechAudioFormatInfo(48000, [System.Speech.AudioFormat.AudioBitsPerSample]::Sixteen, [System.Speech.AudioFormat.AudioChannel]::Mono)
  $items = Get-Content -LiteralPath $Manifest -Raw -Encoding UTF8 | ConvertFrom-Json
  foreach ($item in $items) {
    $voice.SetOutputToWaveFile($item.file, $format)
    $voice.Speak([string]$item.text)
    $voice.SetOutputToNull()
  }
} finally {
  $voice.Dispose()
}
