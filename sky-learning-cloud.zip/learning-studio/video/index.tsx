import React from "react";
import { AbsoluteFill, Composition, registerRoot } from "remotion";

type Frame = { title: string; visual: string; caption: string; source: string };
const defaults = { title: "", visual: "", caption: "", source: "" };
const font = '"Microsoft YaHei UI", "Microsoft YaHei", "Segoe UI", sans-serif';

// Adapted from the warm paper stage and caption band in grammar-lecture.
function TeachingFrame({ title, visual, caption, source }: Frame) {
  return <AbsoluteFill style={{
    fontFamily: font, color: "#1f2a24", background: "radial-gradient(ellipse at 90% 12%, #dbe9d8, transparent 53%), linear-gradient(135deg, #fcfaf0, #eeece0)",
  }}>
    <div style={{ position: "absolute", left: 77, right: 77, top: 64, fontSize: 47, fontWeight: 740, lineHeight: 1.18 }}>{title}</div>
    <div style={{ position: "absolute", left: 78, width: 82, top: 185, height: 3, background: "#367458" }} />
    <div style={{ position: "absolute", left: 77, right: 90, top: 218, height: 249, display: "flex", alignItems: "center", fontSize: 49, fontWeight: 660, color: "#22553f", lineHeight: 1.25 }}>{visual}</div>
    <div style={{ position: "absolute", left: 79, right: 79, top: 478, fontSize: 18, color: "#5e6a5f", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis" }}>{source}</div>
    <div style={{ position: "absolute", left: 76, right: 76, bottom: 42, minHeight: 97, display: "grid", placeItems: "center", padding: "14px 32px", fontSize: 28, lineHeight: 1.28, textAlign: "center", borderRadius: 13, background: "#22372d", color: "#fffaf0" }}>{caption}</div>
  </AbsoluteFill>;
}

registerRoot(() => <Composition id="TeachingFrame" component={TeachingFrame} width={1280} height={720}
  fps={25} durationInFrames={1} defaultProps={defaults} />);
