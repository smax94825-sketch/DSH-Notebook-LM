import { createHash } from "node:crypto";
import { spawn } from "node:child_process";
import { createRequire } from "node:module";
import { existsSync } from "node:fs";
import { mkdir, mkdtemp, readFile, rename, rm, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { bundle } from "@remotion/bundler";
import { openBrowser, renderStill, selectComposition } from "@remotion/renderer";

const req = createRequire(import.meta.url);
const entry = fileURLToPath(new URL("./index.tsx", import.meta.url));
const voiceScript = fileURLToPath(new URL("./Voice.ps1", import.meta.url));
const fps = 25;
const compositor = process.platform === "win32"
  ? "@remotion/compositor-win32-x64-msvc"
  : "@remotion/compositor-" + process.platform + "-" + process.arch + (process.platform === "linux" ? "-gnu" : "");
const binary = (name) => process.env[name.toUpperCase() + "_PATH"] ||
  path.join(path.dirname(req.resolve(compositor + "/package.json")), name + (process.platform === "win32" ? ".exe" : ""));

function processOutput(file, args) {
  return new Promise((resolve, reject) => {
    const child = spawn(file, args, { windowsHide: true, stdio: ["ignore", "pipe", "pipe"] });
    let stdout = "";
    let stderr = "";
    child.stdout.setEncoding("utf8").on("data", (data) => { stdout += data; });
    child.stderr.setEncoding("utf8").on("data", (data) => { stderr = (stderr + data).slice(-3000); });
    child.once("error", reject);
    child.once("close", (code) => code === 0 ? resolve(stdout) : reject(new Error(stderr || "Renderer process exited " + code)));
  });
}

const encode = (args) => processOutput(binary("ffmpeg"), ["-hide_banner", "-loglevel", "error", "-y", ...args]);
const concatLine = (file) => "file '" + file.replaceAll("\\", "/").replaceAll("'", "'\\''") + "'\n";
const duration = async (file) => {
  const value = Number(await processOutput(binary("ffprobe"), ["-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", file]));
  if (!Number.isFinite(value) || value <= 0) throw new Error("Invalid audio duration");
  return value;
};
const browserPath = process.env.STUDIO_BROWSER || [
  process.env["ProgramFiles(x86)"], process.env.ProgramFiles,
].filter(Boolean).map((folder) => path.join(folder, "Microsoft", "Edge", "Application", "msedge.exe")).find(existsSync);

async function render({ scenes, language, cacheRoot, output }) {
  await mkdir(cacheRoot, { recursive: true });
  const rendererVersion = createHash("sha256").update(await readFile(entry)).update(await readFile(voiceScript))
    .update(await readFile(fileURLToPath(import.meta.url))).digest("hex");
  const keys = scenes.map((scene) => createHash("sha256").update(JSON.stringify({ rendererVersion, language, scene })).digest("hex"));
  const temp = await mkdtemp(path.join(cacheRoot, "render-"));
  let browser;
  try {
    const parts = keys.map((key) => path.join(cacheRoot, key + ".mp4"));
    const missing = [...new Set(keys.map((key, index) => existsSync(parts[index]) ? -1 : keys.indexOf(key)))].filter((index) => index >= 0);
    if (missing.length) {
      const inputs = missing.flatMap((index) => scenes[index].lines.map((text, line) => ({ text, file: path.join(temp, `${index}-${line}.wav`) })));
      const manifest = path.join(temp, "speech.json");
      await writeFile(manifest, JSON.stringify(inputs), "utf8");
      await processOutput("powershell.exe", ["-NoProfile", "-NonInteractive", "-File", voiceScript, manifest, language]);
      const serveUrl = await bundle({ entryPoint: entry, outDir: path.join(temp, "bundle"), onProgress: () => {} });
      browser = await openBrowser("chrome", { browserExecutable: browserPath ?? null, chromeMode: "chrome-for-testing", logLevel: "error" });
      const composition = await selectComposition({ serveUrl, id: "TeachingFrame", puppeteerInstance: browser, logLevel: "error" });
      for (const index of missing) {
        const { title, visual, lines, source } = scenes[index];
        const clips = [];
        for (const [line, caption] of lines.entries()) {
          const wav = path.join(temp, `${index}-${line}.wav`);
          const jpg = path.join(temp, `${index}-${line}.jpeg`);
          const clip = path.join(temp, `${index}-${line}.mp4`);
          const seconds = Math.ceil((await duration(wav) + .28) * fps) / fps;
          const props = { title, visual, caption, source };
          await renderStill({ composition: { ...composition, props }, serveUrl, puppeteerInstance: browser, output: jpg,
            imageFormat: "jpeg", inputProps: props, logLevel: "error" });
          await encode(["-loop", "1", "-framerate", String(fps), "-i", jpg, "-i", wav, "-af", "apad",
            "-c:v", "libx264", "-preset", "ultrafast", "-crf", "22", "-pix_fmt", "yuv420p",
            "-c:a", "aac", "-ar", "48000", "-ac", "1", "-t", seconds.toFixed(2), "-threads", "2", clip]);
          clips.push(clip);
        }
        const list = path.join(temp, `scene-${index}.txt`);
        const sceneFile = path.join(temp, `scene-${index}.mp4`);
        await writeFile(list, clips.map(concatLine).join(""));
        await encode(["-f", "concat", "-safe", "0", "-i", list, "-c", "copy", sceneFile]);
        await rename(sceneFile, parts[index]);
      }
    }
    const list = path.join(temp, "film.txt");
    await writeFile(list, parts.map(concatLine).join(""));
    await encode(["-f", "concat", "-safe", "0", "-i", list, "-c", "copy", "-movflags", "+faststart", output]);
    return { seconds: await duration(output), reused: scenes.length - missing.length };
  } finally {
    await browser?.close({ silent: true }).catch(() => {});
    await rm(temp, { recursive: true, force: true }).catch(() => {});
  }
}

try {
  const input = JSON.parse(await readFile(process.argv[2], "utf8"));
  console.log(JSON.stringify(await render(input)));
} catch (error) {
  console.error(error instanceof Error ? error.message : String(error));
  process.exitCode = 1;
}
