import { existsSync } from "node:fs";
import { deepSeekJson } from "../lib/deepseek.ts";
import { providerStatus, runDshJson } from "../lib/dsh.ts";

if (existsSync(".env.local")) process.loadEnvFile(".env.local");
const status = providerStatus();
console.log(`DeepSeek API Key：${status.key ? "已配置" : "未配置"}`);
console.log(`DSH：${status.dsh ? "已找到" : "未找到"}`);

const prompt = 'An infinitive can express purpose, as in “I left to catch the train.” Return only the JSON object {"ok":true}.';
for (const [name, check] of [
  ["DeepSeek API", () => deepSeekJson([{ role: "user", content: prompt }])],
  ["DSH headless", () => runDshJson(prompt)],
]) {
  try {
    const result = await check();
    if (result?.ok !== true) throw new Error("返回值与预期 JSON 不一致。");
    console.log(name + "：通过");
  } catch (error) {
    process.exitCode = 1;
    console.error(name + "：" + (error instanceof Error ? error.message : "验证失败"));
  }
}
