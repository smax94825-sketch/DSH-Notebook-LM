import { existsSync } from "node:fs";
if (existsSync(".env.local")) process.loadEnvFile(".env.local");
const { database } = await import("../lib/store.ts");
console.table(database().prepare(`
  SELECT feedback.createdAt, accounts.name, accounts.qq, feedback.message
  FROM feedback LEFT JOIN accounts ON accounts.id = feedback.ownerId ORDER BY feedback.createdAt DESC
`).all());
