import { existsSync } from "node:fs";
import { createInterface } from "node:readline/promises";
import { Writable } from "node:stream";

if (existsSync(".env.local")) process.loadEnvFile(".env.local");
const { setDeveloperPassword } = await import("../lib/developer-auth.ts");

if (!process.stdin.isTTY) {
  console.error("请在 PowerShell 或终端中直接运行 npm run developer:password。");
  process.exitCode = 1;
} else {
  const silent = new Writable({ write(_chunk, _encoding, done) { done(); } });
  const readline = createInterface({ input: process.stdin, output: silent, terminal: true });
  const abort = new AbortController();
  readline.on("SIGINT", () => abort.abort());
  readline.on("close", () => abort.abort());

  async function readPassword(prompt) {
    process.stdout.write(prompt);
    try { return await readline.question("", { signal: abort.signal }); }
    finally { process.stdout.write("\n"); }
  }

  try {
    const password = await readPassword("输入开发者密码 / Enter developer password (10–128): ");
    const confirmation = await readPassword("确认密码 / Confirm password: ");
    if (password !== confirmation) throw new Error("两次输入的密码不一致。 / Passwords do not match.");
    await setDeveloperPassword(password);
    console.log("开发者密码已保存，现有解锁会话已失效。 / Developer password saved. Existing sessions were locked.");
  } catch (error) {
    console.error(abort.signal.aborted ? "已取消。 / Cancelled." : error.message);
    process.exitCode = 1;
  } finally {
    readline.close();
  }
}
