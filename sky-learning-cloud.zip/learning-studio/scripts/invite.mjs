import { existsSync } from "node:fs";
if (existsSync(".env.local")) process.loadEnvFile(".env.local");
const { createInvite, createPublicInvite } = await import("../lib/accounts.ts");
try {
  const [first, second, ...extra] = process.argv.slice(2);
  const asLink = first === "--link";
  const isPublic = first === "--public";
  if (extra.length || (!isPublic && second !== undefined) || (!asLink && !isPublic && first !== undefined)) {
    throw new Error("用法：npm run invite [-- --link | -- --public [公开码]]");
  }
  const code = isPublic ? createPublicInvite(second) : createInvite();
  const origin = process.env.STUDIO_PUBLIC_ORIGIN || "http://127.0.0.1:3101";
  console.log(asLink ? new URL("/#invite=" + code, origin).href : code);
} catch (error) {
  console.error(error.message);
  process.exitCode = 1;
}
