import path from "node:path";

export const localRoot = path.resolve(process.env.STUDIO_DATA_DIR || ".local");
export const maxPdfPages = 700;
export const dshTimeout = 240_000;
