import type { Kit } from "./contracts.ts";
import type { Outline, Scene, Slide, VideoLanguage } from "./production-contracts.ts";

const clean = (value: string, max: number) => {
  const flat = value.replace(/\s+/gu, " ").trim();
  const chars = Array.from(flat);
  return chars.length > max ? chars.slice(0, max - 1).join("") + "…" : flat;
};
const sentences = (value: string) => value.match(/[^。！？.!?\n]+[。！？.!?]?/gu)?.map((line) => line.trim()).filter(Boolean) ?? [];

export function draftSlides(kit: Kit): Outline[] {
  const concepts = kit.concepts.map(({ id }) => id);
  const exercises = Math.min(3, kit.questions.length);
  const lessonCount = Math.min(10 - exercises, kit.concepts.length);
  const chosen = Array.from({ length: lessonCount }, (_, index) =>
    kit.concepts[Math.floor(index * kit.concepts.length / lessonCount)]);
  const lessons = chosen.map((concept): Outline => ({
      title: clean(concept.title, 48),
      objective: clean(concept.explanation, 95),
      layout: "lesson", seconds: 90, conceptIds: [concept.id],
  }));
  return [
    { title: clean(kit.title, 48), objective: clean(kit.route[0].action, 90), layout: "cover", seconds: 50, conceptIds: concepts.slice(0, 4) },
    ...lessons,
    ...kit.questions.slice(0, exercises).map((question, index): Outline => ({
      title: "课堂练习 " + (index + 1), objective: clean(question.prompt, 100), layout: "exercise",
      seconds: 110, conceptIds: question.conceptIds.slice(0, 4),
    })),
    { title: "回顾与自检", objective: "用自己的话复述本课要点，并用例句说明判断依据。", layout: "lesson", seconds: 70, conceptIds: concepts.slice(0, 4) },
  ];
}

export function writeSlides(outline: Outline[], kit: Kit): Slide[] {
  let exerciseIndex = 0;
  return outline.map((page) => {
    const concepts = kit.concepts.filter(({ id }) => page.conceptIds.includes(id));
    const concept = concepts[0];
    if (page.layout === "cover") {
      return { title: page.title, points: [page.objective], example: "", notes: "开场后说明本课目标。\n" + page.objective };
    }
    if (page.layout === "exercise") {
      const matching = kit.questions.filter(({ conceptIds }) => conceptIds.some((id) => page.conceptIds.includes(id)));
      const exercise = kit.questions.find(({ prompt }) => clean(prompt, 100) === page.objective) ??
        matching[exerciseIndex++ % Math.max(1, matching.length)];
      return {
        title: page.title, points: [page.objective], example: "",
        notes: exercise
          ? "留出独立作答时间。\n参考答案：" + clean(exercise.answer, 670) + "\n讲解：" + clean(exercise.explanation, 670)
          : "请学生先独立作答，再说明判断依据。教师可在审核时补充参考答案。",
      };
    }
    const points = concepts.length > 1 ? [page.objective, ...concepts.slice(0, 2).map(({ title }) => clean(title, 72))]
      : [page.objective];
    return { title: page.title, points, example: clean(concept.refs[0].quote, 132), notes: clean(concepts.map(({ title, explanation }) => title + "。" + explanation).join(" "), 1500) };
  });
}

export function draftScenes(kit: Kit, language: VideoLanguage): Scene[] {
  const en = language === "en-US";
  return kit.concepts.slice(0, 10).map((concept, index) => {
    const references = [...new Set(concept.refs.map(({ quote }) => quote))];
    const lines = (en ? [
      "Read this excerpt and identify the grammatical pattern.",
      ...references,
      "Find the expression in the example. Then explain its function aloud.",
    ] : [concept.title + "。", ...sentences(concept.explanation).slice(0, 6), references[0]])
      .filter(Boolean).map((line) => clean(line, 155)).slice(0, 10);
    return {
      title: en ? "Example " + (index + 1) : clean(concept.title, 48),
      visual: clean(references[0], 165), lines, conceptIds: [concept.id],
    };
  });
}
