import { createHash } from "node:crypto";
import { platformConnection } from "./api-settings.ts";
import { validateKit } from "./content.ts";
import type { Chunk, Kit, KitRequest } from "./contracts.ts";
import { supportsPdfVision } from "./deepseek.ts";
import { runLearningKitTask } from "./dsh.ts";
import { AppError } from "./errors.ts";
import { isPdfCatalogue } from "./pdf-text.ts";
import { prepareSourceText, prepareVisualPdfRange } from "./sources.ts";
import {
  claimJob, failJob, finishJob, getChunks, getNotebook, getSource, hasReadableChunks, listSources, renewStudyJob, savedJobBatch, updateJobProgress,
} from "./store.ts";

const batchCharacters = 20_000;

export function kitRanges(notebookId: string, request: KitRequest, visualAvailable: boolean) {
  const unique = new Set(request.sources.map(({ sourceId }) => sourceId));
  if (unique.size !== request.sources.length) throw new AppError("每份资料只需选择一次。");
  const sources = new Map(listSources(notebookId).map((source) => [source.id, source]));
  return request.sources.map(({ sourceId, start = 1, end }) => {
    const source = sources.get(sourceId);
    if (!source) throw new AppError("所选资料已移除，请重新选择生成范围。 / A source was removed. Select a new range.", 404);
    const last = end ?? source.positions;
    if (start > last || last > source.positions) throw new AppError(`「${source.title}」的范围超出 1–${source.positions}。`);
    if (!source.textPending && !(visualAvailable && source.kind === "pdf") && !hasReadableChunks(source, start, last)) {
      throw noStudyText(source, visualAvailable);
    }
    return { sourceId, title: source.title, kind: source.kind, start, end: last };
  });
}

function noStudyText(source: { title: string; kind: "pdf" | "text" }, visualAvailable: boolean) {
  const reason = source.kind === "text"
    ? "选定范围内没有可读文字。 / The selected range has no readable text."
    : visualAvailable
      ? "所选页码没有可读正文。请选择清晰的正文页，或粘贴文字。 / Select clear pages with body text, or paste text."
      : "所选页码没有可读正文。扫描页可用官方 DeepSeek Flash 视觉读取，也可以粘贴原文。 / Use official DeepSeek Flash for scanned pages, or paste the source text.";
  return new AppError(`「${source.title}」${reason}`, 422);
}

type Material = ReturnType<typeof kitRanges>[number] & { chunks: Chunk[] };

function materialBatches(materials: Material[]) {
  const size = (chunk: Chunk) => chunk.text.length + 130;
  if (materials.reduce((total, material) => total + material.chunks.reduce((sum, chunk) => sum + size(chunk), 0), 0)
      <= batchCharacters) return [materials];

  const batches: Material[][] = [];
  for (const material of materials) {
    let chunks: Chunk[] = [];
    let characters = 0;
    function closeBatch() {
      if (!chunks.length) return;
      batches.push([{ ...material, start: chunks[0].position, end: chunks[chunks.length - 1].position, chunks }]);
      chunks = [];
      characters = 0;
    }
    for (const chunk of material.chunks) {
      // Prefer a page or paragraph break when a batch is already mostly full.
      if (characters + size(chunk) > batchCharacters ||
          (characters >= batchCharacters * 0.75 && chunks.at(-1)?.position !== chunk.position)) closeBatch();
      chunks.push(chunk);
      characters += size(chunk);
    }
    closeBatch();
  }
  return batches;
}

function mergeKits(title: string, kits: Kit[]): Kit {
  const examOverview = kits.flatMap((kit, index) => kit.examOverview
    ? [`${index + 1}. ${kit.title}\n${kit.examOverview}`] : []).join("\n\n");
  const reviews = kits.flatMap((kit, index) => kit.review
    ? [{ ...kit.review, overview: `${index + 1}. ${kit.title}\n${kit.review.overview}` }] : []);
  return {
    title,
    concepts: [...new Map(kits.flatMap((kit) => kit.concepts.map((concept) => [concept.id, concept] as const))).values()],
    route: kits.flatMap((kit) => kit.route),
    questions: kits.flatMap((kit) => kit.questions),
    ...(examOverview ? { examOverview } : {}),
    ...(reviews.length ? { review: {
      overview: reviews.map(({ overview }) => overview).join("\n\n"),
      cards: reviews.flatMap(({ cards }) => cards),
      relations: reviews.flatMap(({ relations }) => relations),
    } } : {}),
  };
}

const worker = globalThis as typeof globalThis & { learningStudioJobDrain?: Promise<void> };

export function kickJobs() {
  if (worker.learningStudioJobDrain) return;
  worker.learningStudioJobDrain = drainJobs().catch(() => {
    console.error("Learning Studio could not process its local queue.");
  }).finally(() => { delete worker.learningStudioJobDrain; });
}

async function drainJobs() {
  jobs: for (let job = claimJob(); job; job = claimJob()) {
    try {
      const connection = platformConnection();
      const visualAvailable = supportsPdfVision(connection);
      const ranges = kitRanges(job.notebookId, job.request, visualAvailable);
      const materials: Material[] = [];
      for (const range of ranges) {
        const source = getSource(job.notebookId, range.sourceId);
        if (!renewStudyJob(job)) continue jobs;
        await prepareSourceText(source);
        const loadChunks = () => getChunks(source.id, range.start, range.end)
          .filter(({ text }) => source.kind !== "pdf" || !isPdfCatalogue(text));
        let chunks = loadChunks();
        if (visualAvailable && source.kind === "pdf") {
          const readable = new Set(chunks.map(({ position }) => position));
          await prepareVisualPdfRange(source.id, range.start, range.end, readable, connection, () => renewStudyJob(job));
          chunks = loadChunks();
        }
        if (!renewStudyJob(job)) continue jobs;
        if (!chunks.length) throw noStudyText(source, visualAvailable);
        materials.push({ ...range, chunks });
      }
      const skill = job.request.skill ?? "standard";
      const batches = materialBatches(materials);
      const kits: Kit[] = [];
      if (!updateJobProgress(job, 0, batches.length)) continue;
      for (const batch of batches) {
        const chunks = batch.flatMap((material) => material.chunks);
        const key = createHash("sha256").update(JSON.stringify(batch)).digest("hex");
        const saved = savedJobBatch(job.id, key);
        const kit = saved ?? await runLearningKitTask({
          focus: job.request.scope, materials: batch,
          ...(batches.length > 1 ? { batch: { index: kits.length + 1, total: batches.length } } : {}),
        }, connection, skill, (value) => validateKit(value, chunks, skill));
        kits.push(kit);
        if (!updateJobProgress(job, kits.length, batches.length, saved ? undefined : { key, kit })) continue jobs;
      }
      const kit = kits.length === 1 ? kits[0] : mergeKits(
        materials.length === 1 ? materials[0].title : getNotebook(job.notebookId).title, kits,
      );
      // Keep the existing artifact field so previously saved results remain readable.
      kit.examCoverage = materials.map(({ sourceId, chunks }) => ({
        sourceId, readable: new Set(chunks.map(({ position }) => position)).size,
      }));
      finishJob(job, kit);
    } catch (error) {
      failJob(job, error instanceof AppError ? error.message : "生成学习资料失败，可以重试。");
    }
  }
}
