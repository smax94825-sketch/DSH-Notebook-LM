import { randomUUID } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, open, readFile, readdir, rename, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import type { ReadableStream as NodeReadableStream } from "node:stream/web";
import { pipeline } from "node:stream/promises";
import { localRoot } from "./config.ts";
import { AppError } from "./errors.ts";
import { addPdf } from "./sources.ts";
import { getSource } from "./store.ts";
import { maxPdfBytes, pdfPartBytes, pdfSizeMessage } from "./upload-limit.ts";

type Manifest = { name: string; size: number };
const root = path.join(localRoot, "pdf-uploads");
const lifetime = 24 * 60 * 60 * 1000;
const directory = (notebook: string, upload: string) => path.join(root, notebook, upload);
const part = (dir: string, index: number) => path.join(dir, String(index) + ".part");
const count = ({ size }: Manifest) => Math.ceil(size / pdfPartBytes);
const partSize = ({ size }: Manifest, index: number) => Math.min(pdfPartBytes, size - index * pdfPartBytes);

async function manifest(dir: string) {
  const bytes = await readFile(path.join(dir, "manifest.json"), "utf8").catch(() => {
    throw new AppError("上传会话已失效，请重新上传。 / Upload session expired. Try again.", 404);
  });
  return JSON.parse(bytes) as Manifest;
}

export async function beginPdfUpload(notebook: string, input: Manifest) {
  if (!input.name.toLowerCase().endsWith(".pdf") || input.size < 1) throw new AppError("请选择 PDF 文件。 / Choose a PDF file.");
  if (input.size > maxPdfBytes) throw new AppError(pdfSizeMessage, 413);
  const parent = path.join(root, notebook);
  await mkdir(parent, { recursive: true });
  const sessions = await readdir(parent, { withFileTypes: true });
  await Promise.all(sessions.filter((entry) => entry.isDirectory()).map(async ({ name }) => {
    const folder = path.join(parent, name);
    const info = await stat(folder).catch(() => null);
    if (info && Date.now() - info.mtimeMs > lifetime) await rm(folder, { recursive: true, force: true }).catch(() => {});
  }));
  const uploadId = randomUUID();
  const dir = directory(notebook, uploadId);
  await mkdir(dir);
  await writeFile(path.join(dir, "manifest.json"), JSON.stringify(input));
  return { uploadId };
}

export async function receivePdfPart(notebook: string, upload: string, index: number, body: ReadableStream<Uint8Array> | null) {
  const dir = directory(notebook, upload);
  const input = await manifest(dir);
  if (!body || !Number.isInteger(index) || index < 0 || index >= count(input)) throw new AppError("无效的上传分片。 / Invalid upload part.");
  const expected = partSize(input, index);
  const temp = path.join(dir, randomUUID() + ".tmp");
  let received = 0;
  try {
    await pipeline(Readable.fromWeb(body as NodeReadableStream<Uint8Array>), async function* (chunks: AsyncIterable<Uint8Array>) {
      for await (const chunk of chunks) {
        received += chunk.byteLength;
        if (received > expected) throw new AppError("上传分片大小不符。 / Incorrect upload part size.", 413);
        yield chunk;
      }
    }, createWriteStream(temp, { flags: "wx" }));
    if (received !== expected) throw new AppError("上传分片不完整。 / Incomplete upload part.");
    await rename(temp, part(dir, index));
  } finally {
    await rm(temp, { force: true }).catch(() => {});
  }
}

export async function completePdfUpload(notebook: string, upload: string) {
  // If the browser lost a successful response, return the same source.
  try { return getSource(notebook, upload); }
  catch (error) { if (!(error instanceof AppError) || error.status !== 404) throw error; }
  const dir = directory(notebook, upload);
  const input = await manifest(dir);
  const indexes = Array.from({ length: count(input) }, (_, index) => index);
  const sizes = await Promise.all(indexes.map((index) => stat(part(dir, index)).then((info) => info.size, () => 0)));
  if (sizes.some((size, index) => size !== partSize(input, index))) throw new AppError("还有上传分片未完成。 / Upload parts are missing.", 409);
  const lockPath = path.join(dir, "completing");
  const lock = await open(lockPath, "wx").catch((error: NodeJS.ErrnoException) => {
    if (error.code === "EEXIST") throw new AppError("PDF 正在保存。 / The PDF is being saved.", 409);
    throw error;
  });
  await lock.close();
  async function* pieces() {
    for (const index of indexes) yield* createReadStream(part(dir, index));
  }
  try {
    const stream = Readable.toWeb(Readable.from(pieces())) as unknown as ReadableStream<Uint8Array>;
    const source = await addPdf(notebook, input.name, stream, upload);
    await rm(dir, { recursive: true, force: true }).catch(() => {});
    return source;
  } finally {
    await rm(lockPath, { force: true }).catch(() => {});
  }
}

export async function discardPdfUpload(notebook: string, upload: string) {
  const dir = directory(notebook, upload);
  // A completed upload has already moved to the permanent source directory.
  if (await stat(path.join(dir, "completing")).then(() => true, () => false)) return;
  await rm(dir, { recursive: true, force: true });
}
