import { ZodError } from "zod";

export class AppError extends Error {
  readonly status: number;

  constructor(message: string, status = 400) {
    super(message);
    this.status = status;
  }
}

export function apiError(error: unknown) {
  if (error instanceof AppError) {
    return Response.json({ error: error.message }, { status: error.status });
  }
  if (error instanceof ZodError || error instanceof SyntaxError) {
    return Response.json({ error: "请检查提交的内容和范围。" }, { status: 400 });
  }
  console.error("Learning Studio request failed:", error instanceof Error ? error.name : "unknown");
  return Response.json({ error: "本地工作台遇到了错误，请重试。" }, { status: 500 });
}
