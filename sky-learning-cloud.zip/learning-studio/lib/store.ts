import { randomUUID } from "node:crypto";
import { mkdirSync } from "node:fs";
import path from "node:path";
import { DatabaseSync } from "node:sqlite";
import { dshTimeout, localRoot } from "./config.ts";
import type {
  Answer, Artifact, ArtifactSummary, Chunk, Exchange, Job, Kit, KitRequest, Notebook, Source, Workspace,
} from "./contracts.ts";
import { AppError } from "./errors.ts";
import { isPdfCatalogue } from "./pdf-text.ts";

const globalStore = globalThis as typeof globalThis & { learningStudioDb?: DatabaseSync };

export function database() {
  if (globalStore.learningStudioDb) return globalStore.learningStudioDb;
  mkdirSync(localRoot, { recursive: true });
  const db = new DatabaseSync(path.join(localRoot, "studio.sqlite"));
  db.exec(`
    PRAGMA journal_mode = WAL;
    PRAGMA busy_timeout = 5000;
    PRAGMA foreign_keys = ON;
    CREATE TABLE IF NOT EXISTS notebooks (
      id TEXT PRIMARY KEY, title TEXT NOT NULL, createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS sources (
      id TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id),
      title TEXT NOT NULL, kind TEXT NOT NULL, positions INTEGER NOT NULL,
      readable INTEGER NOT NULL, selected INTEGER NOT NULL DEFAULT 1
    );
    CREATE TABLE IF NOT EXISTS chunks (
      id TEXT PRIMARY KEY, sourceId TEXT NOT NULL REFERENCES sources(id),
      position INTEGER NOT NULL, part INTEGER NOT NULL, text TEXT NOT NULL
    );
    CREATE INDEX IF NOT EXISTS chunks_position ON chunks(sourceId, position, part);
    CREATE TABLE IF NOT EXISTS pdf_visual_pages (
      sourceId TEXT NOT NULL REFERENCES sources(id), position INTEGER NOT NULL,
      PRIMARY KEY (sourceId, position)
    );
    CREATE TABLE IF NOT EXISTS exchanges (
      id TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id),
      question TEXT NOT NULL, answer TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS artifacts (
      id TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id),
      title TEXT NOT NULL, version INTEGER NOT NULL, createdAt TEXT NOT NULL,
      kit TEXT NOT NULL, request TEXT NOT NULL, UNIQUE (notebookId, version)
    );
    CREATE TABLE IF NOT EXISTS jobs (
      id TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id),
      status TEXT NOT NULL, request TEXT NOT NULL, error TEXT, artifactId TEXT REFERENCES artifacts(id),
      createdAt TEXT NOT NULL, leaseUntil INTEGER
    );
    CREATE INDEX IF NOT EXISTS jobs_status ON jobs(status, createdAt);
    CREATE TABLE IF NOT EXISTS job_batches (
      jobId TEXT NOT NULL REFERENCES jobs(id), batchKey TEXT NOT NULL, kit TEXT NOT NULL,
      PRIMARY KEY (jobId, batchKey)
    );
    CREATE TABLE IF NOT EXISTS accounts (
      id TEXT PRIMARY KEY, qq TEXT NOT NULL UNIQUE, password TEXT NOT NULL, name TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS samples (
      ownerId TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id)
    );
    CREATE TABLE IF NOT EXISTS api_connections (
      ownerId TEXT PRIMARY KEY, baseUrl TEXT NOT NULL, model TEXT NOT NULL, key TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS invites (
      tokenHash TEXT PRIMARY KEY, expiresAt INTEGER NOT NULL, usedAt INTEGER,
      reusable INTEGER NOT NULL DEFAULT 0
    );
    CREATE TABLE IF NOT EXISTS sessions (
      tokenHash TEXT PRIMARY KEY, accountId TEXT NOT NULL REFERENCES accounts(id), expiresAt INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS developer_password (
      id INTEGER PRIMARY KEY CHECK (id = 1), salt TEXT NOT NULL, digest TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS developer_sessions (
      tokenHash TEXT PRIMARY KEY, expiresAt INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS feedback (
      id TEXT PRIMARY KEY, ownerId TEXT NOT NULL, message TEXT NOT NULL, createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS productions (
      id TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id),
      artifactId TEXT NOT NULL REFERENCES artifacts(id), kind TEXT NOT NULL, title TEXT NOT NULL,
      revision INTEGER NOT NULL, stage TEXT NOT NULL, content TEXT NOT NULL, error TEXT, updatedAt INTEGER NOT NULL
    );
    CREATE TABLE IF NOT EXISTS study_plans (
      notebookId TEXT PRIMARY KEY REFERENCES notebooks(id), artifactId TEXT NOT NULL REFERENCES artifacts(id),
      minutes INTEGER NOT NULL, goal TEXT NOT NULL, focus TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS study_events (
      id TEXT PRIMARY KEY, notebookId TEXT NOT NULL REFERENCES notebooks(id),
      conceptId TEXT NOT NULL, title TEXT NOT NULL, seconds INTEGER NOT NULL, outcome TEXT NOT NULL, createdAt TEXT NOT NULL
    );
    CREATE TABLE IF NOT EXISTS knowledge_links (
      id TEXT PRIMARY KEY, ownerId TEXT NOT NULL, fromNotebook TEXT NOT NULL REFERENCES notebooks(id),
      fromArtifact TEXT NOT NULL REFERENCES artifacts(id), fromConcept TEXT NOT NULL,
      toNotebook TEXT NOT NULL REFERENCES notebooks(id), toArtifact TEXT NOT NULL REFERENCES artifacts(id),
      toConcept TEXT NOT NULL, relation TEXT NOT NULL, UNIQUE (fromArtifact, fromConcept, toArtifact, toConcept)
    );
  `);
  const columns = db.prepare("PRAGMA table_info(notebooks)").all();
  if (!columns.some((column) => column.name === "ownerId")) {
    db.exec("BEGIN IMMEDIATE");
    try {
      if (!db.prepare("PRAGMA table_info(notebooks)").all().some((column) => column.name === "ownerId")) {
        db.exec("ALTER TABLE notebooks ADD COLUMN ownerId TEXT NOT NULL DEFAULT 'local'");
      }
      db.exec("COMMIT");
    } catch (error) {
      db.exec("ROLLBACK");
      throw error;
    }
  }
  db.exec("CREATE INDEX IF NOT EXISTS notebooks_owner ON notebooks(ownerId, createdAt)");
  db.exec("BEGIN IMMEDIATE");
  try {
    if (!db.prepare("PRAGMA table_info(invites)").all().some((column) => column.name === "accountId")) {
      db.exec("ALTER TABLE invites ADD COLUMN accountId TEXT REFERENCES accounts(id)");
    }
    if (!db.prepare("PRAGMA table_info(invites)").all().some((column) => column.name === "reusable")) {
      db.exec("ALTER TABLE invites ADD COLUMN reusable INTEGER NOT NULL DEFAULT 0");
    }
    for (const table of ["notebooks", "sources"]) {
      if (!db.prepare(`PRAGMA table_info(${table})`).all().some((column) => column.name === "deletedAt")) {
        db.exec(`ALTER TABLE ${table} ADD COLUMN deletedAt TEXT`);
      }
    }
    if (!db.prepare("PRAGMA table_info(sources)").all().some((column) => column.name === "textPending")) {
      db.exec("ALTER TABLE sources ADD COLUMN textPending INTEGER NOT NULL DEFAULT 0");
    }
    if (!db.prepare("PRAGMA table_info(jobs)").all().some((column) => column.name === "batchesTotal")) {
      db.exec("ALTER TABLE jobs ADD COLUMN batchesTotal INTEGER");
      db.exec("ALTER TABLE jobs ADD COLUMN batchesCompleted INTEGER NOT NULL DEFAULT 0");
    }
    if (!db.prepare("PRAGMA table_info(accounts)").all().some((column) => column.name === "lastLoginAt")) {
      db.exec("ALTER TABLE accounts ADD COLUMN lastLoginAt INTEGER");
      db.exec(`UPDATE accounts SET lastLoginAt = (
        SELECT MAX(expiresAt) - 1209600000 FROM sessions WHERE accountId = accounts.id
      )`);
    }
    if (!db.prepare("PRAGMA table_info(sources)").all().some((column) => column.name === "isExample")) {
      db.exec("ALTER TABLE sources ADD COLUMN isExample INTEGER NOT NULL DEFAULT 0");
      db.exec(`UPDATE sources SET isExample = 1 WHERE id IN (
        SELECT json_extract(artifacts.request, '$.sources[0].sourceId') FROM artifacts
        JOIN samples ON samples.notebookId = artifacts.notebookId WHERE artifacts.version = 1
      )`);
    }
    if (!db.prepare("PRAGMA table_info(artifacts)").all().some((column) => column.name === "invalidEvidence")) {
      db.exec("ALTER TABLE artifacts ADD COLUMN invalidEvidence INTEGER NOT NULL DEFAULT 0");
      const references = db.prepare(`
        SELECT DISTINCT artifacts.id, chunks.text, sources.kind
        FROM artifacts, json_each(artifacts.kit, '$.concepts') AS concept,
          json_each(concept.value, '$.refs') AS ref
        JOIN chunks ON chunks.id = json_extract(ref.value, '$.chunkId')
        JOIN sources ON sources.id = chunks.sourceId
      `).all() as { id: string; text: string; kind: string }[];
      const valid = new Set(references.filter((ref) => ref.kind !== "pdf" || !isPdfCatalogue(ref.text)).map((ref) => ref.id));
      const mark = db.prepare("UPDATE artifacts SET invalidEvidence = 1 WHERE id = ?");
      for (const id of new Set(references.map((ref) => ref.id))) if (!valid.has(id)) mark.run(id);
      const scanned = db.prepare(`SELECT chunks.sourceId, chunks.text FROM chunks JOIN sources ON sources.id = chunks.sourceId
        WHERE sources.kind = 'pdf' AND chunks.text LIKE '%General%Information%'`).all() as { sourceId: string; text: string }[];
      const indexed = db.prepare("SELECT position, text FROM chunks WHERE sourceId = ?");
      const recalculate = db.prepare("UPDATE sources SET readable = ? WHERE id = ?");
      for (const sourceId of new Set(scanned.filter(({ text }) => isPdfCatalogue(text)).map(({ sourceId }) => sourceId))) {
        const body = (indexed.all(sourceId) as { position: number; text: string }[]).filter(({ text }) => !isPdfCatalogue(text));
        recalculate.run(new Set(body.map(({ position }) => position)).size, sourceId);
      }
    }
    db.exec("COMMIT");
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
  return globalStore.learningStudioDb = db;
}

export function transaction<T>(work: (db: DatabaseSync) => T) {
  const db = database();
  db.exec("BEGIN IMMEDIATE");
  try {
    const result = work(db);
    db.exec("COMMIT");
    return result;
  } catch (error) {
    db.exec("ROLLBACK");
    throw error;
  }
}

export function listNotebooks(ownerId = "local") {
  return database().prepare("SELECT id, title, createdAt FROM notebooks WHERE ownerId = ? AND deletedAt IS NULL ORDER BY createdAt DESC").all(ownerId) as Notebook[];
}

export function createNotebook(title: string, ownerId = "local") {
  const notebook = { id: randomUUID(), title, createdAt: new Date().toISOString() };
  database().prepare("INSERT INTO notebooks (id, title, createdAt, ownerId) VALUES (?, ?, ?, ?)").run(notebook.id, title, notebook.createdAt, ownerId);
  return notebook;
}

export function getNotebook(notebookId: string, ownerId?: string) {
  const notebook = database().prepare(
    "SELECT id, title, createdAt FROM notebooks WHERE id = ? AND deletedAt IS NULL AND (? IS NULL OR ownerId = ?)"
  ).get(notebookId, ownerId ?? null, ownerId ?? null) as Notebook | undefined;
  if (!notebook) throw new AppError("找不到这个笔记本。", 404);
  return notebook;
}

export function deleteNotebook(notebookId: string, ownerId: string) {
  transaction((db) => {
    getNotebook(notebookId, ownerId);
    db.prepare("UPDATE notebooks SET deletedAt = ? WHERE id = ?").run(new Date().toISOString(), notebookId);
    db.prepare("UPDATE jobs SET status = 'failed', leaseUntil = NULL WHERE notebookId = ? AND status IN ('queued', 'running')")
      .run(notebookId);
  });
}

type SourceRow = Omit<Source, "selected" | "textPending"> & { selected: number; textPending: number };
const toSource = (row: SourceRow): Source => ({ ...row, selected: !!row.selected, textPending: !!row.textPending });

export function listSources(notebookId: string, includeDeleted = false) {
  const rows = database().prepare(
    "SELECT id, title, kind, positions, readable, selected, textPending FROM sources WHERE notebookId = ? AND (? OR deletedAt IS NULL) ORDER BY rowid"
  ).all(notebookId, Number(includeDeleted)) as SourceRow[];
  return rows.map(toSource);
}

export function getSource(notebookId: string, sourceId: string, includeDeleted = false) {
  const source = database().prepare(
    "SELECT id, title, kind, positions, readable, selected, textPending FROM sources WHERE notebookId = ? AND id = ? AND (? OR deletedAt IS NULL)"
  ).get(notebookId, sourceId, Number(includeDeleted)) as SourceRow | undefined;
  if (!source) throw new AppError("找不到这份资料。", 404);
  return toSource(source);
}

export function deleteSource(notebookId: string, sourceId: string) {
  const result = database().prepare("UPDATE sources SET deletedAt = ?, selected = 0 WHERE notebookId = ? AND id = ? AND deletedAt IS NULL")
    .run(new Date().toISOString(), notebookId, sourceId);
  if (!result.changes) throw new AppError("找不到这份资料。 / Source not found.", 404);
}

export function saveSource(notebookId: string, source: Source, chunks: Chunk[]) {
  transaction((db) => {
    getNotebook(notebookId);
    db.prepare("INSERT INTO sources (id, notebookId, title, kind, positions, readable, selected, textPending) VALUES (?, ?, ?, ?, ?, ?, 1, ?)").run(
      source.id, notebookId, source.title, source.kind, source.positions, source.readable, Number(source.textPending ?? false)
    );
    const insert = db.prepare("INSERT INTO chunks VALUES (?, ?, ?, ?, ?)");
    for (const chunk of chunks) insert.run(chunk.id, source.id, chunk.position, chunk.part, chunk.text);
  });
}

export function savePdfText(sourceId: string, readable: number, chunks: Chunk[]) {
  transaction((db) => {
    const result = db.prepare("UPDATE sources SET readable = ?, textPending = 0 WHERE id = ? AND textPending = 1 AND deletedAt IS NULL")
      .run(readable, sourceId);
    if (!result.changes) return;
    const insert = db.prepare("INSERT INTO chunks VALUES (?, ?, ?, ?, ?)");
    for (const chunk of chunks) insert.run(chunk.id, sourceId, chunk.position, chunk.part, chunk.text);
  });
}

export function setSourceSelected(notebookId: string, sourceId: string, selected: boolean) {
  getSource(notebookId, sourceId);
  database().prepare("UPDATE sources SET selected = ? WHERE id = ?").run(Number(selected), sourceId);
}

export function getChunks(sourceId: string, start: number, end: number) {
  const rows = database().prepare(`
    SELECT c.*, p.position IS NOT NULL AS visual FROM chunks c
    LEFT JOIN pdf_visual_pages p ON p.sourceId = c.sourceId AND p.position = c.position
    WHERE c.sourceId = ? AND c.position BETWEEN ? AND ? ORDER BY c.position, c.part
  `).all(sourceId, start, end) as (Omit<Chunk, "visual"> & { visual: number })[];
  return rows.map(({ visual, ...chunk }) => ({ ...chunk, ...(visual ? { visual: true } : {}) }));
}

export function hasReadableChunks(source: Source, start: number, end: number) {
  const rows = database().prepare("SELECT text FROM chunks WHERE sourceId = ? AND position BETWEEN ? AND ?")
    .iterate(source.id, start, end);
  for (const { text } of rows) if (source.kind !== "pdf" || !isPdfCatalogue(String(text))) return true;
  return false;
}

export function visualPdfPages(sourceId: string, start: number, end: number) {
  const rows = database().prepare("SELECT position FROM pdf_visual_pages WHERE sourceId = ? AND position BETWEEN ? AND ?")
    .all(sourceId, start, end);
  return new Set(rows.map(({ position }) => Number(position)));
}

export function savePdfVisualPage(sourceId: string, position: number, chunks: Chunk[]) {
  transaction((db) => {
    const source = db.prepare("SELECT 1 FROM sources WHERE id = ? AND deletedAt IS NULL").get(sourceId);
    if (!source) throw new AppError("所选 PDF 已移除。 / The selected PDF was removed.", 404);
    const page = db.prepare("INSERT OR IGNORE INTO pdf_visual_pages VALUES (?, ?)").run(sourceId, position);
    if (!page.changes || !chunks.length) return;
    const previous = db.prepare("SELECT COALESCE(MAX(part), 0) AS last FROM chunks WHERE sourceId = ? AND position = ?").get(sourceId, position);
    const insert = db.prepare("INSERT INTO chunks VALUES (?, ?, ?, ?, ?)");
    for (const chunk of chunks) insert.run(chunk.id, sourceId, position, Number(previous?.last ?? 0) + chunk.part, chunk.text);
    db.prepare("UPDATE sources SET readable = readable + 1 WHERE id = ?").run(sourceId);
  });
}

export function renewStudyJob(job: ClaimedJob) {
  const now = Date.now();
  const lease = now + dshTimeout + 30_000;
  const active = database().prepare(`UPDATE jobs SET leaseUntil = ?
    WHERE id = ? AND status = 'running' AND leaseUntil = ? AND leaseUntil > ?`).run(lease, job.id, job.lease, now);
  if (active.changes) job.lease = lease;
  return Boolean(active.changes);
}

export function saveExchange(notebookId: string, question: string, answer: Answer): Exchange {
  const id = randomUUID();
  database().prepare("INSERT INTO exchanges VALUES (?, ?, ?, ?)").run(id, notebookId, question, JSON.stringify(answer));
  return { id, question, answer };
}

export function directChatHistory(notebookId: string) {
  return (database().prepare(`
    SELECT question, json_extract(answer, '$.text') AS text FROM exchanges
    WHERE notebookId = ? AND json_extract(answer, '$.status') = 'direct'
    ORDER BY rowid DESC LIMIT 6
  `).all(notebookId) as { question: string; text: string }[]).reverse();
}

type JobRow = Omit<Job, "scope" | "skill" | "progress"> & {
  notebookId: string; request: string; leaseUntil: number | null; batchesTotal: number | null; batchesCompleted: number;
};

function toJob(row: JobRow): Job {
  const { scope, skill } = JSON.parse(row.request) as KitRequest;
  return {
    id: row.id, status: row.status, scope, skill,
    error: row.error, artifactId: row.artifactId, createdAt: row.createdAt,
    ...(row.batchesTotal === null ? {} : { progress: { completed: row.batchesCompleted, total: row.batchesTotal } }),
  };
}

export function workspace(notebookId: string): Workspace {
  const notebook = getNotebook(notebookId);
  const db = database();
  const exchanges = db.prepare("SELECT id, question, answer FROM exchanges WHERE notebookId = ? ORDER BY rowid")
    .all(notebookId) as { id: string; question: string; answer: string }[];
  const jobs = db.prepare("SELECT * FROM jobs WHERE notebookId = ? ORDER BY rowid DESC").all(notebookId) as JobRow[];
  const artifacts = db.prepare("SELECT id, title, version, createdAt FROM artifacts WHERE notebookId = ? AND invalidEvidence = 0 ORDER BY version DESC")
    .all(notebookId) as ArtifactSummary[];
  return {
    notebook, sources: listSources(notebookId), jobs: jobs.map(toJob), artifacts,
    exchanges: exchanges.map((row) => ({ ...row, answer: JSON.parse(row.answer) as Answer })),
  };
}

export function getArtifact(notebookId: string, artifactId: string): Artifact {
  const row = database().prepare(
    "SELECT id, title, version, createdAt, kit, request FROM artifacts WHERE notebookId = ? AND id = ? AND invalidEvidence = 0"
  ).get(notebookId, artifactId) as (ArtifactSummary & { kit: string; request: string }) | undefined;
  if (!row) throw new AppError("找不到这份学习资料。", 404);
  return { ...row, kit: JSON.parse(row.kit) as Kit, request: JSON.parse(row.request) as KitRequest };
}

export function queueJob(notebookId: string, request: KitRequest) {
  return transaction((db) => {
    getNotebook(notebookId);
    const input = JSON.stringify(request);
    const existing = db.prepare("SELECT * FROM jobs WHERE notebookId = ? AND request = ? AND status IN ('queued', 'running')")
      .get(notebookId, input) as JobRow | undefined;
    if (existing) return toJob(existing);
    const id = randomUUID();
    const createdAt = new Date().toISOString();
    db.prepare("INSERT INTO jobs (id, notebookId, request, status, createdAt) VALUES (?, ?, ?, 'queued', ?)")
      .run(id, notebookId, input, createdAt);
    return { id, status: "queued", scope: request.scope, skill: request.skill, error: null, artifactId: null, createdAt } satisfies Job;
  });
}

export function retryJob(notebookId: string, jobId: string) {
  const result = database().prepare(
    "UPDATE jobs SET status = 'queued', error = NULL, leaseUntil = NULL WHERE notebookId = ? AND id = ? AND status = 'failed'"
  ).run(notebookId, jobId);
  if (!result.changes) throw new AppError("只有失败的任务可以重试。", 409);
}

export function claimJob() {
  return transaction((db) => {
    db.prepare("UPDATE jobs SET status = 'failed', error = ?, leaseUntil = NULL WHERE status = 'running' AND leaseUntil <= ?")
      .run("上一次生成已中断，可以重试。", Date.now());
    if (db.prepare("SELECT 1 FROM jobs WHERE status = 'running' LIMIT 1").get()) return;
    const row = db.prepare(`SELECT jobs.* FROM jobs JOIN notebooks ON notebooks.id = jobs.notebookId
      WHERE jobs.status = 'queued' AND notebooks.deletedAt IS NULL ORDER BY jobs.rowid LIMIT 1`).get() as JobRow | undefined;
    if (!row) return;
    const lease = Date.now() + dshTimeout + 30_000;
    db.prepare("UPDATE jobs SET status = 'running', leaseUntil = ? WHERE id = ?").run(lease, row.id);
    return { id: row.id, notebookId: row.notebookId, request: JSON.parse(row.request) as KitRequest, lease };
  });
}

type ClaimedJob = NonNullable<ReturnType<typeof claimJob>>;

export function updateJobProgress(job: ClaimedJob, completed: number, total: number, batch?: { key: string; kit: Kit }) {
  return transaction((db) => {
    const now = Date.now();
    const lease = now + dshTimeout + 30_000;
    const result = db.prepare(`UPDATE jobs SET batchesCompleted = ?, batchesTotal = ?, leaseUntil = ?
      WHERE id = ? AND status = 'running' AND leaseUntil = ? AND leaseUntil > ?`)
      .run(completed, total, lease, job.id, job.lease, now);
    if (!result.changes) return false;
    if (batch) db.prepare("INSERT INTO job_batches VALUES (?, ?, ?)").run(job.id, batch.key, JSON.stringify(batch.kit));
    job.lease = lease;
    return true;
  });
}

export function savedJobBatch(jobId: string, key: string) {
  const row = database().prepare("SELECT kit FROM job_batches WHERE jobId = ? AND batchKey = ?").get(jobId, key);
  return row ? JSON.parse(String(row.kit)) as Kit : undefined;
}

export function finishJob(job: ClaimedJob, kit: Kit) {
  transaction((db) => {
    const artifactId = randomUUID();
    const active = db.prepare("SELECT 1 FROM jobs WHERE id = ? AND status = 'running' AND leaseUntil = ?").get(job.id, job.lease);
    if (!active) return;
    db.prepare(`INSERT INTO artifacts (id, notebookId, title, version, createdAt, kit, request)
      SELECT ?, ?, ?, COALESCE(MAX(version), 0) + 1, ?, ?, ?
      FROM artifacts WHERE notebookId = ?`).run(
      artifactId, job.notebookId, kit.title, new Date().toISOString(), JSON.stringify(kit), JSON.stringify(job.request), job.notebookId
    );
    db.prepare("UPDATE jobs SET status = 'succeeded', artifactId = ?, leaseUntil = NULL WHERE id = ?").run(artifactId, job.id);
    db.prepare("DELETE FROM job_batches WHERE jobId = ?").run(job.id);
  });
}

export function failJob(job: ClaimedJob, error: string) {
  database().prepare("UPDATE jobs SET status = 'failed', error = ?, leaseUntil = NULL WHERE id = ? AND status = 'running' AND leaseUntil = ?")
    .run(error, job.id, job.lease);
}
