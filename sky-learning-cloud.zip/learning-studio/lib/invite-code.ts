export const inviteCodePattern = /^(?:[\w-]{43}|SKY-[0-9A-Fa-f]{10})$/;
export const inviteCodeHtmlPattern = "(?:[A-Za-z0-9_\\-]{43}|SKY-[0-9A-Fa-f]{10})";
