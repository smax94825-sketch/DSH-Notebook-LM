import { spawn } from "node:child_process";
import { randomUUID } from "node:crypto";
import { createReadStream } from "node:fs";
import { mkdir, rm, stat, writeFile } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { localRoot } from "./config.ts";
import { AppError } from "./errors.ts";
import { draftScenes, draftSlides, writeSlides } from "./production-content.ts";
import { newProduction, productionEdit } from "./production-contracts.ts";
import type { Production, ProductionSummary } from "./production-contracts.ts";
import { database, getArtifact, listSources } from "./store.ts";
import { sampleScenes } from "./sample.ts";

type Row = Omit<Production, "content"> & { content: string; notebookId: string };
const decode = (row: Row) => ({ ...row, content: JSON.parse(row.content) }) as Production & { notebookId: string };
const mediaRoot = path.join(localRoot, "media");
const mediaPath = (id: string, revision: number) => path.join(mediaRoot, id, revision + ".mp4");
const timeout = 20 * 60_000;

export function productions(notebookId: string) {
  return database().prepare(`SELECT p.id, p.kind, p.title, p.revision, p.stage, p.error, p.artifactId
    FROM productions p JOIN artifacts a ON a.id = p.artifactId WHERE p.notebookId = ? AND a.invalidEvidence = 0 ORDER BY p.rowid DESC`)
    .all(notebookId) as (ProductionSummary & { kind: Production["kind"] })[];
}

export function production(notebookId: string, id: string) {
  const row = database().prepare(`SELECT p.* FROM productions p JOIN artifacts a ON a.id = p.artifactId
    WHERE p.notebookId = ? AND p.id = ? AND a.invalidEvidence = 0`).get(notebookId, id) as Row | undefined;
  if (!row) throw new AppError("找不到这个创作项目。", 404);
  return decode(row);
}

export function createProduction(notebookId: string, body: unknown) {
  const { artifactId, kind, language } = newProduction.parse(body);
  const { kit } = getArtifact(notebookId, artifactId);
  const id = randomUUID();
  const content = kind === "slides" ? { outline: draftSlides(kit) } : {
    language, scenes: (language === "en-US" ? sampleScenes(kit) : undefined) ?? draftScenes(kit, language),
  };
  database().prepare("INSERT INTO productions VALUES (?, ?, ?, ?, ?, 1, ?, ?, NULL, ?)")
    .run(id, notebookId, artifactId, kind, kit.title, kind === "slides" ? "outline" : "storyboard", JSON.stringify(content), Date.now());
  return production(notebookId, id);
}

export function editProduction(notebookId: string, id: string, action: string | undefined, body: unknown) {
  const input = productionEdit.parse(body);
  const current = production(notebookId, id);
  if (current.revision !== input.revision) throw new AppError("已有新版本，请刷新项目后再修改。", 409);
  const { kit } = getArtifact(notebookId, current.artifactId);
  const allowed = new Set(kit.concepts.map(({ id }) => id));
  let stage: Production["stage"];
  let content: Production["content"];
  if (current.kind === "slides" && action === "approve-outline" && current.stage === "outline" && input.outline) {
    stage = "script";
    content = { outline: input.outline, slides: writeSlides(input.outline, kit) };
  } else if (current.kind === "slides" && action === "approve-script" && current.stage === "script" && input.slides?.length === current.content.outline.length) {
    stage = "ready";
    content = { outline: current.content.outline, slides: input.slides };
  } else if (current.kind === "slides" && action === "outline" && ["outline", "script", "ready"].includes(current.stage) && input.outline) {
    stage = "outline";
    content = { outline: input.outline };
  } else if (current.kind === "slides" && action === "script" && current.stage === "script" && input.slides?.length === current.content.outline.length) {
    stage = "script";
    content = { outline: current.content.outline, slides: input.slides };
  } else if (current.kind === "video" && ["storyboard", "ready", "failed"].includes(current.stage) && input.scenes && (action === "render" || !action)) {
    stage = action === "render" ? "queued" : "storyboard";
    content = { language: current.content.language, scenes: input.scenes };
  } else {
    throw new AppError("当前版本不支持此操作。", 409);
  }
  const referenced = "outline" in content ? content.outline : content.scenes;
  if (referenced.some((entry) => entry.conceptIds.some((id) => !allowed.has(id)))) throw new AppError("引用的知识点不在这份学习资料中。");
  const result = database().prepare(`
    UPDATE productions SET revision = revision + 1, stage = ?, content = ?, error = NULL, updatedAt = ?
    WHERE notebookId = ? AND id = ? AND revision = ? AND stage = ?
  `).run(stage, JSON.stringify(content), Date.now(), notebookId, id, input.revision, current.stage);
  if (!result.changes) throw new AppError("已有新版本，请刷新项目。", 409);
  if (stage === "queued") kickVideo();
  return production(notebookId, id);
}

async function runVideo(item: Production & { notebookId: string }) {
  if (item.kind !== "video") return;
  const { kit } = getArtifact(item.notebookId, item.artifactId);
  const sources = new Map(listSources(item.notebookId, true).map((source) => [source.id, source]));
  const scenes = item.content.scenes.map((scene) => {
    const refs = kit.concepts.filter(({ id }) => scene.conceptIds.includes(id)).flatMap(({ refs }) => refs);
    return { ...scene, source: [...new Set(refs.map((ref) => {
      const source = sources.get(ref.sourceId);
      return (source?.title ?? "资料") + " · " + (source?.kind === "pdf" ? "PDF " : "段 ") + ref.position;
    }))].join("   ") };
  });
  const folder = path.join(mediaRoot, item.id);
  const output = mediaPath(item.id, item.revision);
  const manifest = path.join(folder, item.revision + ".json");
  try {
    await mkdir(folder, { recursive: true });
    await writeFile(manifest, JSON.stringify({ scenes, language: item.content.language, cacheRoot: path.join(folder, "scenes"), output }));
    const metadata = await new Promise<{ seconds: number; reused: number }>((resolve, reject) => {
      const child = spawn(process.execPath, [path.resolve("video/render.mjs"), manifest], {
        stdio: ["ignore", "pipe", "pipe"], windowsHide: true,
      });
      let stdout = "";
      let stderr = "";
      const timer = setTimeout(() => { child.kill(); reject(new AppError("视频渲染超时，请减少分镜或旁白。")); }, timeout);
      child.stdout.setEncoding("utf8").on("data", (data: string) => { stdout = (stdout + data).slice(-4000); });
      child.stderr.setEncoding("utf8").on("data", (data: string) => { stderr = (stderr + data).slice(-4000); });
      child.on("error", () => { clearTimeout(timer); reject(new AppError("无法启动视频渲染器。")); });
      child.on("close", (code) => {
        clearTimeout(timer);
        if (code !== 0) {
          if (stderr.includes("VOICE_UNAVAILABLE")) return reject(new AppError("Windows 没有对应语言的朗读语音，请安装语音或选择其他语言。"));
          console.error("Video render failed:", stderr);
          return reject(new AppError("视频渲染失败，请检查 Windows 语音和 Edge 后重试。"));
        }
        try {
          const data = JSON.parse(stdout.trim().split("\n").at(-1) ?? "");
          if (!Number.isFinite(data.seconds) || data.seconds <= 0 || !Number.isInteger(data.reused)) throw new Error();
          resolve(data);
        } catch { reject(new AppError("渲染器未返回有效的视频信息。")); }
      });
    });
    database().prepare("UPDATE productions SET stage = 'ready', content = ?, updatedAt = ? WHERE id = ? AND revision = ? AND stage = 'rendering'")
      .run(JSON.stringify({ ...item.content, ...metadata }), Date.now(), item.id, item.revision);
  } catch (error) {
    await rm(output, { force: true }).catch(() => {});
    database().prepare("UPDATE productions SET stage = 'failed', error = ?, updatedAt = ? WHERE id = ? AND revision = ? AND stage = 'rendering'")
      .run(error instanceof AppError ? error.message : "视频渲染失败，可以重试。", Date.now(), item.id, item.revision);
  } finally {
    await rm(manifest, { force: true }).catch(() => {});
  }
}

const processState = globalThis as typeof globalThis & { studioVideoWorker?: Promise<void> };
export function kickVideo() {
  if (processState.studioVideoWorker) return;
  processState.studioVideoWorker = (async () => {
    const db = database();
    db.prepare("UPDATE productions SET stage = 'failed', error = ? WHERE stage = 'rendering' AND updatedAt < ?")
      .run("渲染已中断，可以重试。", Date.now() - timeout - 30_000);
    for (;;) {
      const row = db.prepare(`
        UPDATE productions SET stage = 'rendering', updatedAt = ? WHERE id = (
          SELECT id FROM productions WHERE stage = 'queued'
            AND NOT EXISTS (SELECT 1 FROM productions WHERE stage = 'rendering')
          ORDER BY updatedAt LIMIT 1
        ) AND stage = 'queued' RETURNING *
      `).get(Date.now()) as Row | undefined;
      if (!row) break;
      await runVideo(decode(row));
    }
  })().catch(() => console.error("Video queue could not start."))
    .finally(() => { delete processState.studioVideoWorker; });
}

export async function streamVideo(request: Request, item: Production) {
  const file = mediaPath(item.id, item.revision);
  const size = (await stat(file).catch(() => { throw new AppError("找不到生成的视频。", 404); })).size;
  const headers = new Headers({ "Content-Type": "video/mp4", "Accept-Ranges": "bytes", "Cache-Control": "private, no-store" });
  if (new URL(request.url).searchParams.has("download")) headers.set("Content-Disposition", "attachment; filename=lesson.mp4");
  let start = 0;
  let end = size - 1;
  const requested = request.headers.get("range");
  if (requested) {
    const match = /^bytes=(\d*)-(\d*)$/.exec(requested);
    if (match?.[1]) {
      start = Number(match[1]);
      if (match[2]) end = Math.min(end, Number(match[2]));
    } else if (match?.[2]) start = Math.max(0, size - Number(match[2]));
    if (!match || (!match[1] && !match[2]) || start > end || start >= size) {
      return new Response(null, { status: 416, headers: { "Content-Range": "bytes */" + size } });
    }
    headers.set("Content-Range", `bytes ${start}-${end}/${size}`);
  }
  headers.set("Content-Length", String(end - start + 1));
  return new Response(Readable.toWeb(createReadStream(file, { start, end })) as ReadableStream<Uint8Array>, { status: requested ? 206 : 200, headers });
}
