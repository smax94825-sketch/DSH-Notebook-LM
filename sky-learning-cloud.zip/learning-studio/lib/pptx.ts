import PptxGenJS from "pptxgenjs";
import type { Kit, Source } from "./contracts.ts";
import type { Outline, Slide } from "./production-contracts.ts";

export async function renderSlides(outline: Outline[], slides: Slide[], kit: Kit, sources: Source[]) {
  const deck = new PptxGenJS();
  deck.layout = "LAYOUT_WIDE";
  deck.author = "sky learning";
  deck.title = slides[0].title;
  const colors = { paper: "F7F6EE", ink: "1F2A24", accent: "245941", muted: "586659", line: "A8B8A8" };
  const fontFace = "Microsoft YaHei";
  slides.forEach((page, index) => {
    const info = outline[index];
    const slide = deck.addSlide();
    slide.background = { color: colors.paper };
    const text = (value: string, x: number, y: number, w: number, h: number, fontSize: number, extra: Parameters<typeof slide.addText>[1] = {}) =>
      slide.addText(value, { x, y, w, h, fontSize, fontFace, color: colors.ink, valign: "middle", margin: 0, fit: "shrink", ...extra });
    const cover = info.layout === "cover";
    text(page.title, .85, cover ? 1.55 : .65, 11.65, cover ? 1.8 : 1.28, cover ? 44 : 34, { bold: true });
    slide.addShape(deck.ShapeType.line, { x: .85, y: cover ? 3.52 : 2.08, w: cover ? 1.3 : 11.55, h: 0, line: { color: colors.accent, width: 1.5 } });
    page.points.forEach((point, i) => {
      const y = cover ? 3.82 + i * .68 : 2.33 + i * .85;
      if (!cover && info.layout !== "exercise") text("•", .9, y, .35, .7, 20, { color: colors.accent });
      text(point, cover ? .85 : 1.28, y, 10.95, .72, cover ? 24 : 21);
    });
    if (page.example) text(page.example, 1.28, 5.22, 10.8, 1.03, 21, { color: colors.accent, italic: true });
    const refs = [...new Set(kit.concepts.filter(({ id }) => info.conceptIds.includes(id)).flatMap((concept) =>
      concept.refs.map((ref) => {
        const source = sources.find(({ id }) => id === ref.sourceId);
        return (source?.title ?? "资料") + " " + (source?.kind === "pdf" ? "PDF 页 " : "段 ") + ref.position;
      })))];
    if (!cover) text(refs.slice(0, 3).join("  ·  "), .85, 6.82, 10.65, .3, 11, { color: colors.muted });
    text(String(index + 1), 11.83, 6.82, .57, .3, 11, { color: colors.muted, align: "right" });
    slide.addNotes(page.notes + (refs.length ? "\n\n来源\n" + refs.join("\n") : ""));
  });
  return new Uint8Array(await deck.write({ outputType: "arraybuffer" }) as ArrayBuffer);
}
