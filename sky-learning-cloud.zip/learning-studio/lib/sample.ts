import { randomUUID } from "node:crypto";
import type { Chunk, Kit, Notebook } from "./contracts.ts";
import type { Scene } from "./production-contracts.ts";
import { database, transaction } from "./store.ts";

export const sampleTitle = "英语语法 · 非谓语动词";
const passages = [
  "A to-infinitive can express purpose. I walked to the station to catch the train.",
  "An -ing form can act as the subject. Reading the instructions takes a minute.",
  "A past participle can modify a noun. We replaced the broken window.",
  "A non-finite form does not express tense on its own. The main verb locates the action in time.",
  "The same sentence may contain more than one verb form. We stopped to watch the birds.",
];

const examples = [
  ["先找谓语", "在 I walked to the station to catch the train 中，walked 是过去时谓语，to catch 给出步行的目的。", 0],
  ["带 to 的不定式表目的", "用 Why did I walk to the station? 提问。to catch the train 是这个问题的答案。", 0],
  ["-ing 形式作主语", "在 Reading the instructions takes a minute 中，Reading the instructions 是主语，takes 是谓语。", 1],
  ["过去分词修饰名词", "在 We replaced the broken window 中，broken 修饰 window，replaced 是谓语。", 2],
  ["时态线索", "先从谓语找时态。非谓语形式可以表达动作或状态，但单独看该形式无法确定句子的时态。", 3],
  ["同一句里的两个动词形式", "在 We stopped to watch the birds 中，stopped 承担谓语功能，to watch 解释停下的目的。", 4],
  ["句中功能", "用三个问题检查句中作用：为什么做？什么事花时间？哪一个物体被描述？分别对应三个例句中的目的、主语和修饰语。", 4],
] as const;

const narration = [
  ["Finding the main verb", "I walked to the station to catch the train.", [
    "Read this sentence aloud. I walked to the station to catch the train.",
    "There are two verb forms: walked and to catch. Walked is the main verb. It places the walk in the past.",
    "To catch the train explains the purpose of the walk. Ask why the speaker walked to the station.",
    "Pause and say both parts aloud: the action was walking, and the purpose was catching the train.",
  ]],
  ["An infinitive of purpose", "Why did I walk to the station? To catch the train.", [
    "A to infinitive can express purpose. The example answers a question beginning with why.",
    "Ask, why did I walk to the station? The answer is, to catch the train.",
    "Notice which words travel together. To catch is the infinitive, and the train is what the speaker hoped to catch.",
    "Say the purpose phrase once on its own. Then put it back into the full sentence.",
  ]],
  ["An ing form as subject", "Reading the instructions takes a minute.", [
    "Now read this example. Reading the instructions takes a minute.",
    "What takes a minute? Reading the instructions. The whole group is the subject of the sentence.",
    "Takes is the main verb. Reading names the activity, and the instructions tells you what is being read.",
    "Repeat the question, what takes a minute? Try to answer with the complete subject.",
  ]],
  ["A participle modifying a noun", "We replaced the broken window.", [
    "Listen to this example. We replaced the broken window.",
    "The main verb is replaced. The word broken is a past participle that describes the window.",
    "Ask which window we replaced. It was the broken window. The participle helps identify the thing being described.",
    "Say the noun and its modifier together. Then name the main verb separately.",
  ]],
  ["Finding the tense", "The main verb locates the action in time.", [
    "Return to the sentence about the station. Walked gives you the clue that the walk happened in the past.",
    "To catch explains a purpose. The form by itself does not tell you when the speaker walked.",
    "Use the same procedure with the window sentence. Replaced gives the time clue, while broken describes the window.",
    "For each example, name the verb that gives the time clue and explain what the other form does.",
  ]],
  ["A second purpose example", "We stopped to watch the birds.", [
    "Try a new sentence. We stopped to watch the birds. Which verb places the action in the past?",
    "Stopped is the main verb. The words to watch the birds answer the question, why did we stop?",
    "Compare this with walking to the station to catch the train. Both purpose phrases answer the same kind of question.",
    "Pause here and explain how you found the main verb and the purpose phrase.",
  ]],
  ["A three question check", "Why? What activity? Which noun?", [
    "Finish by matching the form with its job in the sentence.",
    "Ask why to identify a purpose. Ask what takes a minute to identify the activity that acts as subject.",
    "Ask which window to find the noun described by the past participle.",
    "Choose one example, point to the main verb, and explain the job of the nonfinite form without looking at the answer.",
  ]],
] as const;

export function sampleScenes(kit: Kit): Scene[] | undefined {
  if (kit.concepts.length !== narration.length || kit.concepts.some(({ id }, index) => id !== "K-sample-" + (index + 1))) return;
  return narration.map(([title, visual, lines], index) => ({ title, visual, lines: [...lines], conceptIds: [kit.concepts[index].id] }));
}

function makeKit(chunks: Chunk[]): Kit {
  const ref = (position: number) => {
    const chunk = chunks[position];
    return { sourceId: chunk.sourceId, chunkId: chunk.id, position: chunk.position, part: chunk.part, quote: chunk.text };
  };
  const concepts = examples.map(([title, explanation, position], index) => ({
    id: "K-sample-" + (index + 1), title, explanation, refs: (index === 6 ? [0, 1, 2] : [position]).map(ref),
  }));
  const question = (prompt: string, answer: string, explanation: string, concept: number) => ({
    prompt, answer, explanation, conceptIds: [concepts[concept].id], refs: concepts[concept].refs,
  });
  return {
    title: "非谓语动词入门", concepts,
    route: concepts.map((concept, index) => ({
      title: concept.title,
      action: index === 0 ? "圈出谓语和非谓语形式，用一句话解释它们在原句里的作用。"
        : "读原句，指出相关词组，再用自己的话解释它在句中的作用。",
      conceptIds: [concept.id],
    })),
    questions: [
      question("I walked to the station to catch the train 中，哪个词给出时态？", "walked。", "walked 是一般过去时谓语。to catch the train 说明目的。", 0),
      question("Reading the instructions takes a minute 的主语是什么？", "Reading the instructions。", "问「什么事花一分钟」即可找到整个主语。", 2),
      question("在 the broken window 中，broken 修饰哪个词？", "window。", "broken 说明窗户的状态。", 3),
    ],
  };
}

export function createSample(ownerId: string) {
  return transaction((db) => {
    const existing = db.prepare(`
      SELECT notebooks.id, title, createdAt FROM samples JOIN notebooks ON notebooks.id = samples.notebookId
      WHERE samples.ownerId = ? AND notebooks.deletedAt IS NULL
    `).get(ownerId) as Notebook | undefined;
    if (existing) return existing;
    const notebook = { id: randomUUID(), title: sampleTitle, createdAt: new Date().toISOString() };
    const sourceId = randomUUID();
    const chunks = passages.map((text, index): Chunk => ({ id: randomUUID(), sourceId, position: index + 1, part: 1, text }));
    const insert = db.prepare("INSERT INTO chunks VALUES (?, ?, ?, ?, ?)");
    db.prepare("INSERT INTO notebooks (id, title, createdAt, ownerId) VALUES (?, ?, ?, ?)").run(notebook.id, notebook.title, notebook.createdAt, ownerId);
    db.prepare("INSERT INTO sources (id, notebookId, title, kind, positions, readable, selected, isExample) VALUES (?, ?, ?, 'text', ?, ?, 1, 1)")
      .run(sourceId, notebook.id, "自编示例 · 非谓语动词", chunks.length, chunks.length);
    for (const chunk of chunks) insert.run(chunk.id, sourceId, chunk.position, chunk.part, chunk.text);
    const kit = makeKit(chunks);
    db.prepare("INSERT INTO artifacts (id, notebookId, title, version, createdAt, kit, request) VALUES (?, ?, ?, 1, ?, ?, ?)").run(
      randomUUID(), notebook.id, kit.title, notebook.createdAt, JSON.stringify(kit),
      JSON.stringify({ scope: "自编语法示例", sources: [{ sourceId, start: 1, end: chunks.length }] }),
    );
    db.prepare("INSERT INTO samples VALUES (?, ?) ON CONFLICT(ownerId) DO UPDATE SET notebookId = excluded.notebookId").run(ownerId, notebook.id);
    return notebook;
  });
}
