// Catalogue sheets added by some scanned-book archives are not textbook content.
export function isPdfCatalogue(text: string) {
  const value = text.replace(/\s+/gu, " ").trim();
  return /^\[\s*General\s+Information\s*\]/i.test(value) &&
    /(?:书名|SS\s*号)\s*[=:：]/iu.test(value);
}

