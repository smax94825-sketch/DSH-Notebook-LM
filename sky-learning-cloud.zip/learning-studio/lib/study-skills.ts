export const studySkillIds = ["review-learning-kit", "study-review-workbench", "standard", "examlearning"] as const;
export type StudySkill = typeof studySkillIds[number];

export const studySkills = {
  standard: {
    label: "材料学习教练 / Material Learning Coach",
    description: "按材料定学法 · 命题蓝图 · 答题纠错 / Study methods tailored to the material · Assessment blueprint · Error correction",
  },
  examlearning: {
    label: "期末自学 / Exam review (examlearning)",
    description: "教材逐章核读 · 分层练习 · 按需 PDF / Chapter-by-chapter review · Tiered practice · PDF on request",
  },
  "review-learning-kit": {
    label: "系统复习资料包（推荐） / Review Learning Kit (Recommended)",
    description: "知识图谱 · 闪卡 · 可打印 PDF · 交互 HTML · Obsidian · Anki / Knowledge graph · Flashcards · Printable PDF · Interactive HTML · Obsidian · Anki",
  },
  "study-review-workbench": {
    label: "复习资料工作台（全能融合版） / Study Review Workbench (All-in-one)",
    description: "融合逐章自学、系统复习和材料学习教练。可在学习重点指定整章自学、按考纲练习或错题诊断。 / Combines chapter review, structured revision, and study coaching. Use the focus field to request chapter review, syllabus-based practice, or error analysis.",
  },
} satisfies Record<StudySkill, { label: string; description: string }>;

export const examLevels = ["foundation", "understanding", "application"] as const;
export type ExamLevel = typeof examLevels[number];
export const examLevelLabels: Record<ExamLevel, string> = {
  foundation: "基础 / Foundation",
  understanding: "理解 / Understanding",
  application: "应用 / Application",
};

export const reviewRelationLabels = {
  prerequisite: "先修 / Prerequisite", contrast: "对比 / Contrast", applies: "应用 / Application",
  contains: "包含 / Contains", cause: "因果 / Cause", sequence: "步骤 / Sequence",
} as const;
