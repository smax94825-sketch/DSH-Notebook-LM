import { z } from "zod";
import { id } from "./contracts.ts";

const short = (max: number) => z.string().trim().min(1).max(max);
const conceptIds = z.array(short(80)).min(1).max(4);

export const slideOutline = z.object({
  title: short(60), objective: short(120), layout: z.enum(["cover", "lesson", "exercise"]),
  seconds: z.number().int().min(10).max(600), conceptIds,
});
export const slideScript = z.object({
  title: short(60), points: z.array(short(120)).min(1).max(3),
  example: z.string().trim().max(140), notes: short(1600),
});
export const sceneSchema = z.object({
  title: short(58), visual: short(180),
  lines: z.array(short(160)).min(1).max(10), conceptIds,
});
export const newProduction = z.object({
  artifactId: id, kind: z.enum(["slides", "video"]), language: z.enum(["en-US", "zh-CN"]).default("en-US"),
});
export const productionEdit = z.object({
  revision: z.number().int().positive(),
  outline: z.array(slideOutline).min(1).max(30).optional(),
  slides: z.array(slideScript).min(1).max(30).optional(),
  scenes: z.array(sceneSchema).min(1).max(16).optional(),
});
export type Outline = z.infer<typeof slideOutline>;
export type Slide = z.infer<typeof slideScript>;
export type Scene = z.infer<typeof sceneSchema>;
export type VideoLanguage = z.infer<typeof newProduction>["language"];
export type SlideContent = { outline: Outline[]; slides?: Slide[] };
export type VideoContent = { scenes: Scene[]; language: VideoLanguage; seconds?: number; reused?: number };
export type ProductionSummary = {
  id: string; artifactId: string; title: string; revision: number; error: string | null;
  stage: "outline" | "script" | "storyboard" | "queued" | "rendering" | "ready" | "failed";
};
export type Production = ProductionSummary & (
  { kind: "slides"; content: SlideContent } | { kind: "video"; content: VideoContent }
);
