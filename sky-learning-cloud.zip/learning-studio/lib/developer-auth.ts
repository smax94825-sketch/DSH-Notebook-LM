import { createHash, randomBytes, scrypt, timingSafeEqual } from "node:crypto";
import { promisify } from "node:util";
import { z } from "zod";
import { limit } from "./accounts.ts";
import { AppError } from "./errors.ts";
import { database, transaction } from "./store.ts";

const derive = promisify(scrypt);
const passwordInput = z.string().min(10).max(128);
const ttl = 30 * 60;
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const cookieToken = (request: Request) => request.headers.get("cookie")?.match(/(?:^|;\s*)studio_developer=([\w-]{43})(?:;|$)/)?.[1];

export type DeveloperSession =
  | { configured: boolean; expiresAt: null }
  | { configured: boolean; expiresAt: number; remainingMs: number };

function passwordRecord() {
  return database().prepare("SELECT salt, digest FROM developer_password WHERE id = 1").get() as
    { salt: string; digest: string } | undefined;
}

export async function setDeveloperPassword(password: string) {
  if (!passwordInput.safeParse(password).success) throw new AppError("请输入 10–128 个字符。 / Use 10–128 characters.");
  const salt = randomBytes(16).toString("hex");
  const digest = (await derive(password, salt, 64) as Buffer).toString("hex");
  transaction((db) => {
    db.prepare(`INSERT INTO developer_password VALUES (1, ?, ?)
      ON CONFLICT(id) DO UPDATE SET salt = excluded.salt, digest = excluded.digest`).run(salt, digest);
    db.prepare("DELETE FROM developer_sessions").run();
  });
}

export function developerSession(request: Request): DeveloperSession {
  const value = cookieToken(request);
  const now = Date.now();
  const expiresAt = value ? database().prepare(
    "SELECT expiresAt FROM developer_sessions WHERE tokenHash = ? AND expiresAt > ?"
  ).get(hash(value), now)?.expiresAt : undefined;
  const configured = !!passwordRecord();
  return typeof expiresAt === "number"
    ? { configured, expiresAt, remainingMs: expiresAt - now }
    : { configured, expiresAt: null };
}

export function requireDeveloperUnlock(request: Request) {
  if (!developerSession(request).expiresAt) {
    throw new AppError("请先解锁开发者设置。 / Unlock developer settings first.", 401);
  }
}

export async function unlockDeveloper(request: Request) {
  const record = passwordRecord();
  if (!record) throw new AppError("请先在本机设置开发者密码。 / Set a developer password on this computer first.", 409);
  limit("developer-unlock", 6);
  const parsed = z.object({ password: passwordInput }).safeParse(await request.json());
  if (!parsed.success) throw new AppError("开发者密码不正确。 / Incorrect developer password.", 401);
  const actual = await derive(parsed.data.password, record.salt, 64) as Buffer;
  if (!timingSafeEqual(actual, Buffer.from(record.digest, "hex"))) {
    throw new AppError("开发者密码不正确。 / Incorrect developer password.", 401);
  }

  const value = randomBytes(32).toString("base64url");
  const previous = cookieToken(request);
  const expiresAt = Date.now() + ttl * 1000;
  transaction((db) => {
    if (passwordRecord()?.salt !== record.salt) throw new AppError("开发者密码已更改，请重新输入。 / The developer password has changed.", 401);
    db.prepare("DELETE FROM developer_sessions WHERE expiresAt <= ?").run(Date.now());
    if (previous) db.prepare("DELETE FROM developer_sessions WHERE tokenHash = ?").run(hash(previous));
    db.prepare("INSERT INTO developer_sessions VALUES (?, ?)").run(hash(value), expiresAt);
  });
  return sessionResponse(request, { configured: true, expiresAt, remainingMs: ttl * 1000 }, value, ttl);
}

export function lockDeveloper(request: Request) {
  const value = cookieToken(request);
  if (value) database().prepare("DELETE FROM developer_sessions WHERE tokenHash = ?").run(hash(value));
  return sessionResponse(request, { configured: !!passwordRecord(), expiresAt: null }, "", 0);
}

function sessionResponse(request: Request, state: DeveloperSession, value: string, maxAge: number) {
  const secure = new URL(request.url).protocol === "https:" ? "; Secure" : "";
  return Response.json(state, { headers: {
    "Cache-Control": "no-store",
    "Set-Cookie": `studio_developer=${value}; HttpOnly; SameSite=Strict; Path=/api/developer; Max-Age=${maxAge}${secure}`,
  } });
}
