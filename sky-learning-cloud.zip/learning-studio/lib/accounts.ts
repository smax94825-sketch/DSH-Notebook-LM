import { createHash, randomBytes, randomUUID } from "node:crypto";
import { z } from "zod";
import { AppError } from "./errors.ts";
import { inviteCodePattern } from "./invite-code.ts";
import { database, transaction } from "./store.ts";

const ttl = 14 * 86400;
const hash = (value: string) => createHash("sha256").update(value).digest("hex");
const token = () => randomBytes(32).toString("base64url");
export const inviteMode = () => process.env.STUDIO_MODE === "invite";
export const developerMode = () => process.env.STUDIO_DEVELOPER_MODE === "1" && !inviteMode();
export const feedbackEmail = () => z.email().safeParse(process.env.STUDIO_FEEDBACK_EMAIL).data ?? null;
const qqNumber = z.string().trim().regex(/^[1-9]\d{4,11}$/);
const credentials = z.object({ qq: qqNumber });
const registration = credentials.extend({ name: z.string().trim().max(60).optional(), invite: z.string().trim().regex(inviteCodePattern) });
const cookieToken = (request: Request) => request.headers.get("cookie")?.match(/(?:^|;\s*)studio_session=([\w-]{43})(?:;|$)/)?.[1];
type Account = { id: string; name: string };

export function account(request: Request) {
  if (!inviteMode()) return { id: "local", name: "本机用户" };
  const value = cookieToken(request);
  if (!value) return null;
  return database().prepare(`
    SELECT accounts.id, accounts.name FROM sessions JOIN accounts ON accounts.id = sessions.accountId
    WHERE sessions.tokenHash = ? AND sessions.expiresAt > ?
  `).get(hash(value), Date.now()) as Account | undefined ?? null;
}

export function createInvite() {
  const value = token();
  database().prepare("INSERT INTO invites (tokenHash, expiresAt) VALUES (?, ?)").run(hash(value), Date.now() + 7 * 86400000);
  return value;
}

export function createPublicInvite(existingCode?: string) {
  const code = existingCode?.trim().toUpperCase() ?? "SKY-" + randomBytes(5).toString("hex").toUpperCase();
  if (!/^SKY-[0-9A-F]{10}$/.test(code)) throw new AppError("公开内测码格式为 SKY- 加 10 位十六进制字符。");
  const expiresAt = Date.now() + 30 * 86400 * 1000;
  database().prepare("INSERT INTO invites (tokenHash, expiresAt, reusable) VALUES (?, ?, 1)").run(hash(code), expiresAt);
  return code;
}

const attempts = new Map<string, { until: number; count: number }>();
export function limit(key: string, max: number) {
  const now = Date.now();
  for (const [id, entry] of attempts) if (entry.until <= now) attempts.delete(id);
  const entry = attempts.get(key) ?? { until: now + 60_000, count: 0 };
  if (entry.count >= max) throw new AppError("请求太频繁，请一分钟后再试。", 429);
  entry.count++;
  attempts.set(key, entry);
}

function redeemInvite(body: unknown, now: number): Account {
  const { qq, name, invite } = registration.parse(body);
  const db = database();
  const existing = db.prepare("SELECT id, name FROM accounts WHERE qq = ?").get(qq) as Account | undefined;
  if (existing) return existing;
  const digest = hash(invite.length === 43 ? invite : invite.toUpperCase());
  const invitation = db.prepare(`SELECT reusable FROM invites
    WHERE tokenHash = ? AND accountId IS NULL AND expiresAt > ? AND (reusable = 1 OR usedAt IS NULL)`).get(digest, now);
  if (!invitation) throw new AppError("邀请码无效、已使用或已过期。 / Invalid, used or expired invite.", 403);
  if (!invitation.reusable) db.prepare("UPDATE invites SET usedAt = ? WHERE tokenHash = ?").run(now, digest);
  const user = { id: randomUUID(), name: name || qq };
  db.prepare("INSERT INTO accounts (id, qq, password, name) VALUES (?, ?, '', ?)").run(user.id, qq, user.name);
  return user;
}

function registeredAccount(body: unknown): Account {
  const { qq } = credentials.parse(body);
  const user = database().prepare("SELECT id, name FROM accounts WHERE qq = ?").get(qq) as Account | undefined;
  if (!user) throw new AppError("该 QQ 号首次使用需要邀请码。 / Enter an invite code to register this QQ ID.", 404);
  return user;
}

function setCookie(headers: Headers, name: string, value: string, maxAge: number) {
  const secure = process.env.STUDIO_PUBLIC_ORIGIN ? "; Secure" : "";
  headers.append("Set-Cookie", `${name}=${value}; HttpOnly; SameSite=Lax; Path=/; Max-Age=${maxAge}${secure}`);
}

export async function authAction(request: Request, action: string) {
  if (!inviteMode()) throw new AppError("当前使用本地模式。", 404);
  const headers = new Headers({ "Cache-Control": "no-store" });
  if (action === "logout") {
    const value = cookieToken(request);
    if (value) database().prepare("DELETE FROM sessions WHERE tokenHash = ?").run(hash(value));
    setCookie(headers, "studio_session", "", 0);
    return Response.json({ ok: true }, { headers });
  }
  if (action !== "login" && action !== "register") throw new AppError("找不到这个接口。", 404);
  const register = action === "register";
  limit(action, register ? 12 : 30);
  const body: unknown = await request.json();
  const value = token();
  const now = Date.now();
  const previous = cookieToken(request);
  const user = transaction((db) => {
    const user = register ? redeemInvite(body, now) : registeredAccount(body);
    db.prepare("DELETE FROM sessions WHERE accountId = ? AND expiresAt <= ?").run(user.id, now);
    if (previous) db.prepare("DELETE FROM sessions WHERE tokenHash = ?").run(hash(previous));
    db.prepare("INSERT INTO sessions VALUES (?, ?, ?)").run(hash(value), user.id, now + ttl * 1000);
    db.prepare("UPDATE accounts SET lastLoginAt = MAX(COALESCE(lastLoginAt, 0), ?) WHERE id = ?").run(now, user.id);
    return user;
  });
  setCookie(headers, "studio_session", value, ttl);
  return Response.json(user, { headers });
}

export function saveFeedback(ownerId: string, message: string) {
  limit("feedback:" + ownerId, 10);
  database().prepare("INSERT INTO feedback VALUES (?, ?, ?, ?)").run(randomUUID(), ownerId, message, new Date().toISOString());
}
