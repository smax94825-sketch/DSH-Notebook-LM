import type { Source } from "./contracts.ts";
import { AppError } from "./errors.ts";
import { database } from "./store.ts";

export type DeveloperUser = {
  id: string;
  qq: string;
  name: string;
  lastLoginAt: number | null;
  activeSessions: number;
};
export type DeveloperSource = Pick<Source, "id" | "title" | "kind" | "positions"> & { notebook: string };

const uploadedSources = `
  FROM sources JOIN notebooks ON notebooks.id = sources.notebookId
  WHERE notebooks.ownerId = ? AND notebooks.deletedAt IS NULL AND sources.deletedAt IS NULL
    AND sources.isExample = 0
`;

export function developerUsers() {
  return database().prepare(`
    SELECT a.id, a.qq, a.name, a.lastLoginAt, COUNT(s.tokenHash) AS activeSessions
    FROM accounts a LEFT JOIN sessions s ON s.accountId = a.id AND s.expiresAt > ?
    GROUP BY a.id ORDER BY activeSessions DESC, a.lastLoginAt DESC, a.id
  `).all(Date.now()) as DeveloperUser[];
}

export function developerSources(userId: string) {
  return database().prepare(`
    SELECT sources.id, sources.title, sources.kind, sources.positions, notebooks.title AS notebook
    ${uploadedSources} ORDER BY sources.rowid DESC
  `).all(userId) as DeveloperSource[];
}

export function developerSource(userId: string, sourceId: string) {
  const source = database().prepare(`
    SELECT sources.id, sources.title, sources.kind, sources.positions, notebooks.title AS notebook
    ${uploadedSources} AND sources.id = ?
  `).get(userId, sourceId) as DeveloperSource | undefined;
  if (!source) throw new AppError("找不到这份上传资料。 / Uploaded source not found.", 404);
  return source;
}
