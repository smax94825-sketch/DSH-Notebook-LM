import { z } from "zod";
import { AppError } from "./errors.ts";
import { database } from "./store.ts";

export const deepSeekBaseUrl = "https://api.deepseek.com";
const defaultModel = "deepseek-flash";

export type ApiConnection = { baseUrl: string; model: string; key: string };
export type ApiSettings = { baseUrl: string; model: string; hasKey: boolean; saved: boolean };

const inputSchema = z.object({
  baseUrl: z.string().trim().min(1).max(300),
  model: z.string().trim().min(1).max(128),
  key: z.string().trim().max(2048).optional(),
});

export function defaultConnection(): ApiConnection {
  return { baseUrl: deepSeekBaseUrl, model: process.env.DEEPSEEK_MODEL?.trim() || defaultModel, key: process.env.DEEPSEEK_API_KEY?.trim() ?? "" };
}

function storedConnection() {
  // The original local developer row is the platform configuration.
  return database().prepare("SELECT baseUrl, model, key FROM api_connections WHERE ownerId = 'local'").get() as ApiConnection | undefined;
}

export function platformConnection() {
  return storedConnection() ?? defaultConnection();
}

export function publicSettings(): ApiSettings {
  const stored = storedConnection();
  const { baseUrl, model, key } = stored ?? defaultConnection();
  return { baseUrl, model, hasKey: !!key, saved: !!stored };
}

export function connectionFromInput(input: unknown): ApiConnection {
  const parsed = inputSchema.safeParse(input);
  if (!parsed.success) throw new AppError("请检查接口地址、模型 ID 和密钥。 / Check the API URL, model ID, and key.");
  const { baseUrl, model, key } = parsed.data;
  const previous = platformConnection();
  let address: URL;
  try { address = new URL(baseUrl); }
  catch { throw new AppError("请输入有效的 API 地址。 / Enter a valid API URL."); }
  const local = ["localhost", "127.0.0.1", "[::1]"].includes(address.hostname);
  if ((address.protocol !== "https:" && !(local && address.protocol === "http:")) ||
      address.username || address.password || address.search || address.hash) {
    throw new AppError("请输入 HTTPS 地址，或使用本机 HTTP 地址。 / Use HTTPS or a loopback HTTP URL.");
  }
  const normalized = address.origin + address.pathname.replace(/\/+$/, "").replace(/\/chat\/completions$/, "");
  const resolvedKey = key || (previous.baseUrl === normalized ? previous.key : "");
  if (!resolvedKey) throw new AppError("请填写此接口的 API Key。 / Enter an API key for this endpoint.");
  if (!/^[\x21-\x7e]+$/.test(resolvedKey)) throw new AppError("API Key 含有无效字符。 / The API key contains invalid characters.");
  return { baseUrl: normalized, model, key: resolvedKey };
}

export function saveConnection(connection: ApiConnection) {
  database().prepare(`INSERT INTO api_connections (ownerId, baseUrl, model, key) VALUES ('local', ?, ?, ?)
    ON CONFLICT(ownerId) DO UPDATE SET baseUrl = excluded.baseUrl, model = excluded.model, key = excluded.key`)
    .run(connection.baseUrl, connection.model, connection.key);
  return publicSettings();
}

export function resetConnection() {
  database().prepare("DELETE FROM api_connections WHERE ownerId = 'local'").run();
  return publicSettings();
}
