export const maxPdfMb = 500;
export const maxPdfBytes = maxPdfMb * 1024 * 1024;
export const pdfPartBytes = 8 * 1024 * 1024;
export const pdfUploadWorkers = 4;
export const pdfSizeMessage = `请选择 ${maxPdfMb} MB 以内的 PDF 文件。 / Choose a PDF up to ${maxPdfMb} MB.`;
