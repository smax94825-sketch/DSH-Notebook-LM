import { createHash } from "node:crypto";
import { answerOutput, kitOutput } from "./contracts.ts";
import type { Answer, Chunk, Citation, Kit } from "./contracts.ts";
import { AppError } from "./errors.ts";
import type { StudySkill } from "./study-skills.ts";

export const normalize = (value: string) => value.replace(/\s+/gu, " ").trim();

export function splitPosition(text: string) {
  const normalized = normalize(text);
  const pieces: string[] = [];
  let remaining = normalized;
  while (remaining.length > 1150) {
    const window = remaining.slice(650, 1150);
    const boundaries = [...window.matchAll(/[。！？.!?；;]\s*|\s+/gu)];
    const last = boundaries.at(-1);
    const end = last ? 650 + last.index + last[0].length : 1150;
    const cut = /[\uD800-\uDBFF]/u.test(remaining[end - 1]) ? end - 1 : end;
    pieces.push(remaining.slice(0, cut).trim());
    remaining = remaining.slice(cut).trim();
  }
  if (remaining) pieces.push(remaining);
  return pieces;
}

function terms(value: string) {
  const runs = value.toLowerCase().match(/[a-z0-9]+|\p{Script=Han}+/gu) ?? [];
  return new Set(runs.flatMap((run) => {
    if (!/^\p{Script=Han}/u.test(run) || run.length < 2) return [run];
    return Array.from({ length: run.length - 1 }, (_, index) => run.slice(index, index + 2));
  }));
}

export const asksAboutChapters = (question: string) =>
  /目录|目次|有几章|章节.{0,8}(几|多少|数)|(?:多少|几)(?:个)?章节|(?:多少|几)(?:章|篇)|table of contents|how many chapters|number of chapters|list (?:the )?chapters/i.test(question);

function contentsEvidence(chunks: Chunk[]) {
  const sources = new Map<string, Chunk[]>();
  for (const chunk of chunks) {
    if (chunk.position > 40) continue;
    const head = sources.get(chunk.sourceId) ?? [];
    head.push(chunk);
    sources.set(chunk.sourceId, head);
  }
  const evidence: Chunk[][] = [];
  for (const head of sources.values()) {
    const ordered = head.sort((a, b) => a.position - b.position || a.part - b.part);
    const chapter = /第\s*[一二三四五六七八九十百千零〇两\d]+\s*[章篇讲]|\bchapter\s+(?:\d+|[ivxlcdm]+)\b/gi;
    const candidates = ordered.filter(({ text }) => /目\s*[录錄次]|(?:^|\s)(?:table of )?contents\b/i.test(text.slice(0, 200)));
    const directory = candidates.map((start) => {
      const nearby = ordered.filter((chunk) => chunk.position >= start.position && chunk.position <= start.position + 12);
      const chapterPositions = nearby.filter(({ text }) => (text.match(chapter)?.length ?? 0) > 0);
      const score = chapterPositions.reduce((sum, { text }) => sum + (text.match(chapter)?.length ?? 0), 0);
      const last = Math.max(start.position, ...chapterPositions.map(({ position }) => position));
      return { score, chunks: nearby.filter(({ position }) => position <= last) };
    }).sort((a, b) => b.score - a.score)[0];
    if (directory?.score >= 2) evidence.push(directory.chunks);
  }
  // Split the evidence budget across selected sources, keeping each directory in page order.
  return evidence.flatMap((entries) => entries.slice(0, Math.floor(36 / evidence.length)));
}

export function retrieve(question: string, chunks: Chunk[]) {
  if (chunks.length <= 12) return chunks;
  const keys = [...terms(question)].filter((term) => term.length > 1);
  const frequencies = new Map(keys.map((term) => [term, 0]));
  const matches = chunks.map((chunk) => {
    const available = terms(chunk.text);
    const hit = keys.filter((term) => available.has(term));
    for (const term of hit) frequencies.set(term, (frequencies.get(term) ?? 0) + 1);
    return { chunk, hit };
  });
  const ranked = matches.map(({ chunk, hit }) => ({
    chunk,
    score: hit.reduce((sum, term) => sum + Math.log((chunks.length + 1) / (1 + frequencies.get(term)!)), 0),
  })).sort((a, b) => b.score - a.score);
  const relevant = ranked.slice(0, 12).map(({ chunk }) => chunk);
  if (!asksAboutChapters(question)) return relevant;
  const contents = contentsEvidence(chunks);
  return [...new Map([...contents, ...relevant].map((chunk) => [chunk.id, chunk])).values()];
}

function citationResolver(chunks: Chunk[]) {
  const allowed = new Map(chunks.map((chunk) => [chunk.id, chunk]));
  return ({ chunkId, quote }: { chunkId: string; quote: string }): Citation => {
    const chunk = allowed.get(chunkId);
    const excerpt = normalize(quote);
    if (!chunk || !excerpt || !chunk.text.includes(excerpt)) {
      throw new AppError("模型给出的引用无法在选定资料中核对，请重试。", 502);
    }
    return { sourceId: chunk.sourceId, chunkId, position: chunk.position, part: chunk.part, quote: excerpt,
      ...(chunk.visual ? { visual: true } : {}) };
  };
}

export function validateAnswer(value: unknown, chunks: Chunk[]): Answer {
  const parsed = answerOutput.safeParse(value);
  if (!parsed.success) throw new AppError("模型返回的回答格式无效，请重试。", 502);
  if (parsed.data.status === "insufficient") return parsed.data;
  const resolve = citationResolver(chunks);
  return { status: "answered", sections: parsed.data.sections.map(({ text, refs }) => ({ text, refs: refs.map(resolve) })) };
}

export function validateKit(value: unknown, chunks: Chunk[], skill: StudySkill = "standard"): Kit {
  const parsed = kitOutput.safeParse(value);
  if (!parsed.success) throw new AppError("模型返回的学习资料 JSON 不完整或格式无效，可以重试。", 502);
  const resolve = citationResolver(chunks);
  const { title, concepts, route, questions, examOverview, review } = parsed.data;
  const workbench = skill === "study-review-workbench";
  if (skill === "examlearning" && (!examOverview || questions.some(({ level }) => !level))) {
    throw new AppError("期末自学资料缺少知识地图或题目层次，可以重试。", 502);
  }
  if ((skill === "review-learning-kit" || workbench) && !review) {
    throw new AppError("复习资料缺少大纲、闪卡或关联记录，可以重试。", 502);
  }
  const ids = new Map<string, string>();
  const items = concepts.map(({ key, title, explanation, refs }) => {
    if (ids.has(key)) throw new AppError("模型返回了重复的知识点编号，可以重试。", 502);
    const citations = refs.map(resolve);
    const identity = [normalize(title).toLowerCase(), ...new Set(citations.map((ref) => ref.chunkId).sort())].join("\n");
    const id = "K" + createHash("sha256").update(identity).digest("hex").slice(0, 16);
    if ([...ids.values()].includes(id)) throw new AppError("模型返回了重复的知识点，可以重试。", 502);
    ids.set(key, id);
    return { id, title, explanation, refs: citations };
  });
  function conceptIds(keys: string[]) {
    return [...new Set(keys.map((key) => {
      const id = ids.get(key);
      if (!id) throw new AppError("模型引用了未定义的知识点，可以重试。", 502);
      return id;
    }))];
  }
  const reviewKit = (skill === "review-learning-kit" || workbench) && review ? {
    overview: review.overview,
    cards: review.cards.map(({ conceptKeys, refs, front, back }) => {
      const concepts = conceptIds(conceptKeys);
      const identity = JSON.stringify([normalize(front), [...concepts].sort()]);
      return { id: "C" + createHash("sha256").update(identity).digest("hex").slice(0, 16),
        front, back, conceptIds: concepts, refs: refs.map(resolve) };
    }),
    relations: review.relations.map(({ from, to, refs, ...relation }) => {
      if (from === to) throw new AppError("知识关联须连接两个不同的知识点，可以重试。", 502);
      return { ...relation, from: conceptIds([from])[0], to: conceptIds([to])[0], refs: refs.map(resolve) };
    }),
  } : undefined;
  return {
    title,
    ...(reviewKit ? { review: reviewKit } : {}),
    ...((skill === "examlearning" || workbench) && examOverview ? { examOverview } : {}),
    concepts: items,
    route: route.map(({ conceptKeys, ...step }) => ({ ...step, conceptIds: conceptIds(conceptKeys) })),
    questions: questions.map(({ conceptKeys, refs, level, ...question }) => ({
      ...question, ...((skill === "examlearning" || workbench) && level ? { level } : {}),
      conceptIds: conceptIds(conceptKeys), refs: refs.map(resolve),
    })),
  };
}
