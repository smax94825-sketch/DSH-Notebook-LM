import { existsSync } from "node:fs";
import path from "node:path";
import PDFDocument from "pdfkit";
import type { Artifact, Source } from "./contracts.ts";
import { AppError } from "./errors.ts";
import { kitMarkdown } from "./markdown.ts";

function studyFont() {
  if (process.env.STUDIO_PDF_FONT) {
    return { file: process.env.STUDIO_PDF_FONT, face: process.env.STUDIO_PDF_FONT_FACE };
  }
  const windows = path.join(process.env.WINDIR ?? "C:/Windows", "Fonts");
  const candidates = [
    { file: path.join(windows, "NotoSansSC-Regular.ttf") },
    { file: path.join(windows, "msyh.ttc"), face: "MicrosoftYaHei" },
    { file: "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc", face: "NotoSansCJKsc-Regular" },
  ];
  const font = candidates.find(({ file }) => existsSync(file));
  if (!font) throw new AppError("服务器缺少 PDF 中文字体。 / The server needs a CJK font for PDF exports.", 503);
  return font;
}

export async function studyPdf(artifact: Artifact, sources: Source[]) {
  const font = studyFont();
  const doc = new PDFDocument({
    size: "A4", margins: { top: 52, bottom: 55, left: 53, right: 53 }, bufferPages: true,
    info: { Title: artifact.title, Creator: "Sky Learning" },
  });
  try {
    if (font.face) doc.font(font.file, font.face);
    else doc.font(font.file);
  }
  catch { throw new AppError("服务器的 PDF 中文字体无法读取。 / The PDF font could not be loaded.", 503); }
  const chunks: Buffer[] = [];
  const done = new Promise<Buffer>((resolve, reject) => {
    doc.on("data", (chunk: Buffer) => chunks.push(chunk));
    doc.once("end", () => resolve(Buffer.concat(chunks)));
    doc.once("error", reject);
  });
  doc.fillColor("#4659a7").fontSize(10).text("SKY LEARNING  /  学习资料").moveDown(1);
  for (const block of kitMarkdown(artifact, sources).trim().split(/\n{2,}/)) {
    const heading = /^(#{1,3}) (.+)$/.exec(block);
    if (heading) {
      const level = heading[1].length;
      const title = heading[2];
      doc.fontSize([24, 16, 12][level - 1]).fillColor(level === 3 ? "#20232b" : "#334686");
      const height = doc.heightOfString(title, { lineGap: 3 });
      if (doc.y + height + 30 > doc.page.height - doc.page.margins.bottom) doc.addPage();
      if (level === 2) doc.outline.addItem(title);
      doc.text(title, { lineGap: 3 }).moveDown(level === 1 ? 0.8 : 0.45);
      continue;
    }
    const quote = block.startsWith("> ");
    doc.fillColor(quote ? "#535d76" : "#20232b").fontSize(quote ? 9 : 11);
    doc.text(quote ? block.replace(/^> ?/gm, "") : block, { lineGap: 4, indent: quote ? 10 : 0 }).moveDown(0.65);
  }
  const pages = doc.bufferedPageRange();
  for (let i = pages.start; i < pages.start + pages.count; i++) {
    doc.switchToPage(i);
    const { width, height, margins } = doc.page;
    const label = `${i + 1} / ${pages.count}`;
    doc.fontSize(9).fillColor("#5b6273");
    doc.text(label, width - margins.right - doc.widthOfString(label), height - 32, { lineBreak: false });
  }
  doc.end();
  return done;
}
