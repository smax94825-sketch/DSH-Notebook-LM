import { z } from "zod";
import { examLevels, reviewRelationLabels, studySkillIds } from "./study-skills.ts";
import type { ExamLevel } from "./study-skills.ts";

export const id = z.uuid();
export const title = z.string().trim().min(1).max(120);
export const chatInput = z.object({
  question: z.string().trim().min(1).max(2000),
});
export const textInput = z.object({ title, text: z.string().trim().min(1).max(400_000) });
export const kitInput = z.object({
  scope: z.string().trim().max(160).default(""),
  skill: z.enum(studySkillIds).optional(),
  sources: z.array(z.object({
    sourceId: id,
    start: z.number().int().positive().optional(),
    end: z.number().int().positive().optional(),
  })).min(1).max(40),
});

const prose = z.string().trim().min(1).max(5000);
const quoteRef = z.object({ chunkId: id, quote: z.string().trim().min(1).max(500) });
const refs = z.array(quoteRef).min(1).max(5);
const concepts = z.array(z.string().min(1).max(80)).min(1).max(15);
const reviewRelation = z.enum(["prerequisite", "contrast", "applies", "contains", "cause", "sequence"] satisfies (keyof typeof reviewRelationLabels)[]);

export const answerOutput = z.discriminatedUnion("status", [
  z.object({ status: z.literal("insufficient") }),
  z.object({
    status: z.literal("answered"),
    sections: z.array(z.object({ text: prose, refs })).min(1).max(8),
  }),
]);

export const kitOutput = z.object({
  title,
  examOverview: prose.optional(),
  review: z.object({
    overview: prose,
    cards: z.array(z.object({ front: prose, back: prose, conceptKeys: concepts, refs })).min(1).max(12),
    relations: z.array(z.object({
      from: z.string().min(1).max(80), to: z.string().min(1).max(80), kind: reviewRelation,
      explanation: prose, suggested: z.boolean(), refs,
    })).max(18),
  }).optional(),
  concepts: z.array(z.object({ key: z.string().min(1).max(80), title, explanation: prose, refs })).min(1).max(24),
  route: z.array(z.object({ title, action: prose, conceptKeys: concepts })).min(1).max(12),
  questions: z.array(z.object({
    prompt: prose, answer: prose, explanation: prose, conceptKeys: concepts, refs, level: z.enum(examLevels).optional(),
  })).min(1).max(15),
});

export type Citation = {
  sourceId: string;
  chunkId: string;
  position: number;
  part: number;
  quote: string;
  visual?: boolean;
};
export type Chunk = { id: string; sourceId: string; position: number; part: number; text: string; visual?: boolean };
export type Source = {
  id: string;
  title: string;
  kind: "pdf" | "text";
  positions: number;
  readable: number;
  textPending?: boolean;
  selected: boolean;
};
export type Notebook = { id: string; title: string; createdAt: string };
export type Answer = { status: "insufficient" } | { status: "direct"; text: string } | {
  status: "answered";
  sections: { text: string; refs: Citation[] }[];
};
export type Exchange = { id: string; question: string; answer: Answer };
export type KitRequest = z.infer<typeof kitInput>;
export type Job = {
  id: string;
  status: "queued" | "running" | "succeeded" | "failed";
  scope: string;
  skill?: KitRequest["skill"];
  error: string | null;
  artifactId: string | null;
  createdAt: string;
  progress?: { completed: number; total: number };
};
export type ArtifactSummary = { id: string; title: string; version: number; createdAt: string };
export type Kit = {
  title: string;
  concepts: { id: string; title: string; explanation: string; refs: Citation[] }[];
  route: { title: string; action: string; conceptIds: string[] }[];
  questions: { prompt: string; answer: string; explanation: string; conceptIds: string[]; refs: Citation[]; level?: ExamLevel }[];
  examOverview?: string;
  review?: {
    overview: string;
    cards: { id: string; front: string; back: string; conceptIds: string[]; refs: Citation[] }[];
    relations: {
      from: string; to: string; kind: keyof typeof reviewRelationLabels; explanation: string; suggested: boolean; refs: Citation[];
    }[];
  };
  examCoverage?: { sourceId: string; readable: number }[];
};
export type Artifact = ArtifactSummary & { kit: Kit; request: KitRequest };
export type Workspace = { notebook: Notebook; sources: Source[]; exchanges: Exchange[]; jobs: Job[]; artifacts: ArtifactSummary[] };
