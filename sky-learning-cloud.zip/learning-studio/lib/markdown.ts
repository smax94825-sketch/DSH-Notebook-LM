import type { Artifact, Citation, Source } from "./contracts.ts";
import { examLevelLabels, reviewRelationLabels } from "./study-skills.ts";

export function kitMarkdown(artifact: Artifact, sources: Source[]) {
  const label = (ref: Citation) => {
    const source = sources.find(({ id }) => id === ref.sourceId);
    return `> ${source?.title ?? "资料"} · ${source?.kind === "pdf" ? "PDF 页" : "段落"} ${ref.position} · 片段 ${ref.part}${ref.visual ? " · 视觉读取，请核对原页" : ""}\n> ${ref.quote}`;
  };
  const names = new Map(artifact.kit.concepts.map(({ id, title }) => [id, title]));
  const review = artifact.kit.review;
  const scope = artifact.request.sources.map(({ sourceId, start, end }) => {
    const source = sources.find(({ id }) => id === sourceId);
    const last = end ?? source?.positions;
    const readable = artifact.kit.examCoverage?.find((item) => item.sourceId === sourceId)?.readable;
    const coverage = readable === undefined || last === undefined ? "" : ` · 正文 ${readable}/${last - (start ?? 1) + 1}`;
    return `${source?.title ?? "资料"} · ${source?.kind === "pdf" ? "PDF 页" : "段落"} ${start ?? 1}–${last ?? "?"}${coverage}`;
  });
  return [
    `# ${artifact.title}\n\n版本 ${artifact.version}${artifact.request.skill ? " · " + artifact.request.skill : ""}`,
    `## 材料范围\n\n${artifact.request.scope ? artifact.request.scope + "\n\n" : ""}${scope.map((item) => "- " + item).join("\n")}`,
    ...(artifact.kit.examOverview ? [`## 知识地图\n\n${artifact.kit.examOverview}`] : []),
    ...(review ? [`## 复习大纲\n\n${review.overview}`] : []),
    "## 学习路线",
    ...artifact.kit.route.map((item, index) => `### ${index + 1}. ${item.title}\n\n${item.action}\n\n知识点 · ${item.conceptIds.map((id) => names.get(id)).join("、")}`),
    "## 讲义",
    ...artifact.kit.concepts.map((item) => `### ${item.title}\n\n${item.explanation}\n\n${item.refs.map(label).join("\n\n")}`),
    ...(review ? [
      "## 知识关联",
      ...(review.relations.length ? review.relations.map((item) =>
        `### ${names.get(item.from)} · ${reviewRelationLabels[item.kind]} · ${names.get(item.to)}${item.suggested ? "（编排建议）" : ""}\n\n${item.explanation}\n\n${item.refs.map(label).join("\n\n")}`) : ["未找到有依据的关联。"]),
      "## 闪卡",
      ...review.cards.map((item, index) => `### ${index + 1}. ${item.front}\n\n${item.back}\n\n${item.refs.map(label).join("\n\n")}`),
    ] : []),
    "## 自测",
    ...artifact.kit.questions.map((item, index) => `### 第 ${index + 1} 题${item.level ? " · " + examLevelLabels[item.level] : ""}\n\n${item.prompt}`),
    "## 答案与解析",
    ...artifact.kit.questions.map((item, index) => `### 第 ${index + 1} 题\n\n${item.answer}\n\n${item.explanation}\n\n${item.refs.map(label).join("\n\n")}`),
    "",
  ].join("\n\n");
}
