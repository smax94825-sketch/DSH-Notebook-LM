import { randomUUID } from "node:crypto";
import { z } from "zod";
import { id } from "./contracts.ts";
import { AppError } from "./errors.ts";
import { database, getArtifact } from "./store.ts";

const conceptId = z.string().min(1).max(80);
const planInput = z.object({
  artifactId: id, minutes: z.number().int().min(5).max(180),
  goal: z.enum(["understand", "practice"]), focus: z.array(conceptId).max(24),
});
const eventInput = z.object({
  artifactId: id, conceptId, seconds: z.number().int().min(1).max(14400),
  outcome: z.enum(["reviewed", "mastered"]),
});
const linkInput = z.object({
  artifactId: id, conceptId, targetArtifactId: id, targetConceptId: conceptId,
  relation: z.enum(["related", "prerequisite", "contrast"]),
});

function validateConcept(notebookId: string, artifactId: string, conceptId: string) {
  const concept = getArtifact(notebookId, artifactId).kit.concepts.find(({ id }) => id === conceptId);
  if (!concept) throw new AppError("找不到这个知识点。", 404);
  return concept;
}

export function studyData(notebookId: string, ownerId: string) {
  const db = database();
  const plan = db.prepare(`SELECT artifactId, minutes, goal, focus FROM study_plans
    JOIN artifacts ON artifacts.id = study_plans.artifactId WHERE study_plans.notebookId = ? AND artifacts.invalidEvidence = 0`).get(notebookId) as
    (Omit<z.infer<typeof planInput>, "focus"> & { focus: string }) | undefined;
  const history = db.prepare("SELECT * FROM study_events WHERE notebookId = ? ORDER BY rowid DESC LIMIT 60").all(notebookId) as {
    id: string; conceptId: string; title: string; seconds: number; outcome: "reviewed" | "mastered"; createdAt: string;
  }[];
  const outcomes = new Map<string, "reviewed" | "mastered">();
  const latest = db.prepare(`SELECT conceptId, outcome FROM study_events WHERE notebookId = ? AND rowid IN (
    SELECT MAX(rowid) FROM study_events WHERE notebookId = ? GROUP BY conceptId
  )`).all(notebookId, notebookId) as { conceptId: string; outcome: "reviewed" | "mastered" }[];
  for (const event of latest) outcomes.set(event.conceptId, event.outcome);
  const path = plan ? (() => {
    const { kit } = getArtifact(notebookId, plan.artifactId);
    const focus = new Set(JSON.parse(plan.focus) as string[]);
    const ordered = [...new Set([...kit.route.flatMap((step) => step.conceptIds), ...kit.concepts.map(({ id }) => id)])];
    const pending = ordered.filter((id) => outcomes.get(id) !== "mastered");
    const priority = [...pending.filter((id) => focus.has(id)), ...pending.filter((id) => !focus.has(id))];
    const slice = priority.slice(0, Math.floor(plan.minutes / 5));
    const steps = slice.map((id) => {
      const concept = kit.concepts.find((item) => item.id === id)!;
      const task = kit.route.find((item) => item.conceptIds.includes(id));
      const question = kit.questions.find((item) => item.conceptIds.includes(id));
      return { id, title: concept.title, minutes: Math.floor(plan.minutes / slice.length),
        reviewed: outcomes.get(id) === "reviewed",
        action: plan.goal === "practice" && question ? question.prompt : task?.action ?? "阅读讲义后复述知识点。", refs: concept.refs };
    });
    return { steps, progress: { mastered: ordered.length - pending.length, total: ordered.length } };
  })() : { steps: [], progress: null };
  const links = knowledgeLinks(ownerId).filter((link) => link.fromNotebook === notebookId || link.toNotebook === notebookId);
  const graph = links.map((link) => ({
    id: link.id, relation: link.relation,
    from: { notebookId: link.fromNotebook, artifactId: link.fromArtifact, id: link.fromConcept,
      title: validateConcept(link.fromNotebook, link.fromArtifact, link.fromConcept).title, notebook: link.fromTitle },
    to: { notebookId: link.toNotebook, artifactId: link.toArtifact, id: link.toConcept,
      title: validateConcept(link.toNotebook, link.toArtifact, link.toConcept).title, notebook: link.toTitle },
  }));
  return {
    plan: plan ? { ...plan, focus: JSON.parse(plan.focus) as string[] } : null, ...path, history, graph,
    totalSeconds: Number(db.prepare("SELECT COALESCE(SUM(seconds), 0) AS total FROM study_events WHERE notebookId = ?").get(notebookId)?.total),
  };
}

export function knowledgeLinks(ownerId: string) {
  return database().prepare(`
    SELECT l.*, a.title AS fromTitle, b.title AS toTitle FROM knowledge_links l
    JOIN notebooks a ON a.id = l.fromNotebook
    JOIN notebooks b ON b.id = l.toNotebook
    JOIN artifacts first ON first.id = l.fromArtifact AND first.invalidEvidence = 0
    JOIN artifacts second ON second.id = l.toArtifact AND second.invalidEvidence = 0
    WHERE l.ownerId = ? AND a.ownerId = l.ownerId AND b.ownerId = l.ownerId
      AND a.deletedAt IS NULL AND b.deletedAt IS NULL ORDER BY l.rowid DESC
  `).all(ownerId) as {
      id: string; fromNotebook: string; fromArtifact: string; fromConcept: string;
      toNotebook: string; toArtifact: string; toConcept: string; relation: z.infer<typeof linkInput>["relation"];
      fromTitle: string; toTitle: string;
    }[];
}

export function conceptLibrary(ownerId: string) {
  const rows = database().prepare(`
    SELECT artifacts.id, artifacts.notebookId, artifacts.title, artifacts.version, artifacts.kit, notebooks.title AS notebook
    FROM artifacts JOIN notebooks ON notebooks.id = artifacts.notebookId
    WHERE notebooks.ownerId = ? AND notebooks.deletedAt IS NULL AND artifacts.invalidEvidence = 0 ORDER BY artifacts.rowid DESC
  `).all(ownerId) as { id: string; notebookId: string; title: string; version: number; notebook: string; kit: string }[];
  return rows.map(({ kit, ...row }) => ({
    ...row, concepts: (JSON.parse(kit) as { concepts: { id: string; title: string }[] }).concepts.map(({ id, title }) => ({ id, title })),
  }));
}

export function studyAction(notebookId: string, ownerId: string, action: string, body: unknown) {
  const db = database();
  if (action === "plan") {
    const { artifactId, minutes, goal, focus } = planInput.parse(body);
    const { kit } = getArtifact(notebookId, artifactId);
    if (focus.some((id) => !kit.concepts.some((concept) => concept.id === id))) throw new AppError("重点必须来自所选学习资料。");
    db.prepare(`INSERT INTO study_plans VALUES (?, ?, ?, ?, ?) ON CONFLICT(notebookId) DO UPDATE SET
      artifactId = excluded.artifactId, minutes = excluded.minutes, goal = excluded.goal, focus = excluded.focus`)
      .run(notebookId, artifactId, minutes, goal, JSON.stringify([...new Set(focus)]));
  } else if (action === "events") {
    const { artifactId, conceptId, seconds, outcome } = eventInput.parse(body);
    const concept = validateConcept(notebookId, artifactId, conceptId);
    db.prepare("INSERT INTO study_events VALUES (?, ?, ?, ?, ?, ?, ?)")
      .run(randomUUID(), notebookId, conceptId, concept.title, seconds, outcome, new Date().toISOString());
  } else if (action === "links") {
    const { artifactId, conceptId, targetArtifactId, targetConceptId, relation } = linkInput.parse(body);
    validateConcept(notebookId, artifactId, conceptId);
    const target = db.prepare(`SELECT artifacts.notebookId FROM artifacts JOIN notebooks ON notebooks.id = artifacts.notebookId
      WHERE artifacts.id = ? AND notebooks.ownerId = ? AND notebooks.deletedAt IS NULL`).get(targetArtifactId, ownerId);
    if (!target || target.notebookId === notebookId) throw new AppError("请选择另一个笔记本中的知识点。");
    const targetNotebook = String(target.notebookId);
    validateConcept(targetNotebook, targetArtifactId, targetConceptId);
    db.prepare(`INSERT INTO knowledge_links VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
      ON CONFLICT(fromArtifact, fromConcept, toArtifact, toConcept) DO UPDATE SET relation = excluded.relation`)
      .run(randomUUID(), ownerId, notebookId, artifactId, conceptId, targetNotebook, targetArtifactId, targetConceptId, relation);
  } else throw new AppError("找不到这个接口。", 404);
  return studyData(notebookId, ownerId);
}
