import { randomUUID } from "node:crypto";
import { createReadStream, createWriteStream } from "node:fs";
import { mkdir, open, stat, unlink } from "node:fs/promises";
import path from "node:path";
import { Readable } from "node:stream";
import { pipeline } from "node:stream/promises";
import type { ReadableStream as NodeReadableStream } from "node:stream/web";
import { pathToFileURL } from "node:url";
import { localRoot, maxPdfPages } from "./config.ts";
import { splitPosition } from "./content.ts";
import type { Chunk, Source } from "./contracts.ts";
import { AppError } from "./errors.ts";
import { isPdfCatalogue } from "./pdf-text.ts";
import { readPdfPageImage } from "./deepseek.ts";
import type { ApiConnection } from "./api-settings.ts";
import { getNotebook, savePdfText, savePdfVisualPage, saveSource, visualPdfPages } from "./store.ts";
import { maxPdfBytes, pdfSizeMessage } from "./upload-limit.ts";

export function pdfPath(sourceId: string) {
  return path.join(localRoot, "pdf", sourceId + ".pdf");
}

function indexPositions(sourceId: string, positions: string[], start = 1) {
  return positions.flatMap((text, index) => splitPosition(text).map((piece, part): Chunk => ({
    id: randomUUID(), sourceId, position: index + start, part: part + 1, text: piece,
  })));
}

export function addText(notebookId: string, title: string, text: string) {
  getNotebook(notebookId);
  const sourceId = randomUUID();
  const paragraphs = text.split(/\r?\n\s*\r?\n/u).filter((paragraph) => paragraph.trim());
  const source: Source = {
    id: sourceId, title, kind: "text", positions: paragraphs.length, readable: paragraphs.length, selected: true,
  };
  saveSource(notebookId, source, indexPositions(sourceId, paragraphs));
  return source;
}

export async function addPdf(notebookId: string, name: string, body: ReadableStream<Uint8Array> | null, id: string = randomUUID()) {
  getNotebook(notebookId);
  if (!body || !name.toLowerCase().endsWith(".pdf")) throw new AppError("请选择 PDF 文件。 / Choose a PDF file.");
  const filename = pdfPath(id);
  await mkdir(path.dirname(filename), { recursive: true });
  let created = false;
  try {
    const input = Readable.fromWeb(body as NodeReadableStream<Uint8Array>);
    const output = createWriteStream(filename, { flags: "wx" }).once("open", () => { created = true; });
    await pipeline(input, async function* (chunks: AsyncIterable<Uint8Array>) {
      let total = 0;
      for await (const chunk of chunks) {
        total += chunk.byteLength;
        if (total > maxPdfBytes) throw new AppError(pdfSizeMessage, 413);
        yield chunk;
      }
    }, output);
    const handle = await open(filename, "r");
    try {
      const prefix = Buffer.alloc(1024);
      const { bytesRead } = await handle.read(prefix, 0, prefix.length, 0);
      if (!prefix.subarray(0, bytesRead).includes("%PDF-")) throw new AppError("文件内容不是有效的 PDF。");
    } finally {
      await handle.close();
    }
    const positions = await openPdf(filename, async (doc) => doc.numPages);
    const source: Source = {
      id, title: name.replace(/\.pdf$/i, "").slice(0, 120) || "PDF 资料",
      kind: "pdf", positions, readable: 0, selected: true, textPending: true,
    };
    saveSource(notebookId, source, []);
    return source;
  } catch (error) {
    if (created) await unlink(filename).catch(() => {});
    throw error;
  }
}

async function openPdf<T>(filename: string, read: (doc: import("pdfjs-dist").PDFDocumentProxy) => Promise<T>) {
  const { getDocument } = await import("pdfjs-dist/legacy/build/pdf.mjs");
  const pdfRoot = path.join(process.cwd(), "node_modules", "pdfjs-dist");
  const resource = (name: string) => path.join(pdfRoot, name).replaceAll("\\", "/") + "/";
  const pdf = getDocument({
    url: pathToFileURL(filename), disableStream: true, disableAutoFetch: true, disableFontFace: true, useSystemFonts: false,
    cMapUrl: resource("cmaps"), cMapPacked: true, standardFontDataUrl: resource("standard_fonts"),
    wasmUrl: resource("wasm"),
  });
  try {
    const doc = await pdf.promise;
    if (doc.numPages > maxPdfPages) throw new AppError("首版支持最多 700 页的 PDF，请上传所需章节。");
    return await read(doc);
  } catch (error) {
    if (error instanceof AppError) throw error;
    if (error instanceof Error && error.name === "PasswordException") throw new AppError("请先解除 PDF 的密码保护。");
    throw new AppError("无法读取 PDF，请检查文件是否损坏。");
  } finally {
    await pdf.destroy();
  }
}

const readingText = new Map<string, Promise<void>>();

export async function prepareSourceText(source: Source) {
  if (source.kind !== "pdf" || !source.textPending) return;
  const existing = readingText.get(source.id);
  if (existing) return existing;
  const reading = openPdf(pdfPath(source.id), async (doc) => {
    const positions: string[] = [];
    for (let number = 1; number <= doc.numPages; number++) {
      const page = await doc.getPage(number);
      const { items } = await page.getTextContent();
      positions.push(items.flatMap((item) => "str" in item ? [item.str] : []).join(" "));
      page.cleanup();
    }
    return positions;
  }).then((positions) => {
    const readable = positions.filter((text) => text.trim() && !isPdfCatalogue(text)).length;
    savePdfText(source.id, readable, indexPositions(source.id, positions));
  }).finally(() => { readingText.delete(source.id); });
  readingText.set(source.id, reading);
  return reading;
}
export async function prepareVisualPdfRange(
  sourceId: string, start: number, end: number, readable: Set<number>, connection: ApiConnection, active: () => boolean,
) {
  const finished = visualPdfPages(sourceId, start, end);
  const missing: number[] = [];
  for (let position = start; position <= end; position++) {
    if (!finished.has(position) && !readable.has(position)) missing.push(position);
  }
  if (!missing.length) return;
  await openPdf(pdfPath(sourceId), async (doc) => {
    const factory = doc.canvasFactory as {
      create(width: number, height: number): { canvas: { toBuffer(type: "image/png"): Buffer } };
      destroy(bundle: { canvas: { toBuffer(type: "image/png"): Buffer } }): void;
    };
    for (const position of missing) {
      if (!active()) return;
      const page = await doc.getPage(position);
      const original = page.getViewport({ scale: 1 });
      const viewport = page.getViewport({ scale: 2300 / Math.max(original.width, original.height) });
      let image: Buffer;
      try {
        const surface = factory.create(Math.max(1, Math.ceil(viewport.width)), Math.max(1, Math.ceil(viewport.height)));
        try {
          await page.render({ canvas: surface.canvas as unknown as HTMLCanvasElement, viewport }).promise;
          image = surface.canvas.toBuffer("image/png");
        } finally { factory.destroy(surface); }
      } catch {
        throw new AppError("服务器无法打开扫描页图像。 / The server could not render a scanned page.", 502);
      } finally { page.cleanup(); }
      const text = await readPdfPageImage(image, connection);
      if (!active()) return;
      savePdfVisualPage(sourceId, position, isPdfCatalogue(text) ? [] : indexPositions(sourceId, [text], position));
    }
  });
}

export async function pdfResponse(sourceId: string) {
  const filename = pdfPath(sourceId);
  const { size } = await stat(filename).catch(() => { throw new AppError("找不到保存的原始 PDF。", 404); });
  const stream = Readable.toWeb(createReadStream(filename)) as unknown as ReadableStream<Uint8Array>;
  return new Response(stream, { headers: {
    "Content-Type": "application/pdf",
    "Content-Length": String(size),
    "Content-Disposition": "inline",
    "X-Content-Type-Options": "nosniff",
    "Cache-Control": "private, no-store",
  } });
}
