import { listNotebooks } from "./store.ts";
import { conceptLibrary, knowledgeLinks } from "./study.ts";

export type GraphNode = {
  id: string;
  label: string;
  notebookId: string;
  notebookTitle: string;
  kind: "notebook" | "concept";
  href: string;
};

export type GraphEdge = {
  id: string;
  source: string;
  target: string;
  relation: "contains" | "related" | "prerequisite" | "contrast";
};

export type GraphData = { nodes: GraphNode[]; edges: GraphEdge[] };

const conceptKey = (notebook: string, concept: string) => notebook + ":" + concept;

export function knowledgeGraph(ownerId: string): GraphData {
  const nodes = new Map<string, GraphNode>();
  const edges: GraphEdge[] = [];
  for (const notebook of listNotebooks(ownerId)) {
    nodes.set(notebook.id, {
      id: notebook.id, label: notebook.title, notebookId: notebook.id, notebookTitle: notebook.title,
      kind: "notebook", href: "/notebooks/" + notebook.id,
    });
  }
  for (const artifact of conceptLibrary(ownerId)) {
    for (const concept of artifact.concepts) {
      const id = conceptKey(artifact.notebookId, concept.id);
      if (nodes.has(id)) continue;
      const query = new URLSearchParams({ artifact: artifact.id, concept: concept.id });
      nodes.set(id, {
        id, label: concept.title, notebookId: artifact.notebookId, notebookTitle: artifact.notebook,
        kind: "concept", href: "/notebooks/" + artifact.notebookId + "?" + query,
      });
      edges.push({ id, source: artifact.notebookId, target: id, relation: "contains" });
    }
  }
  const relations = new Set<string>();
  for (const link of knowledgeLinks(ownerId)) {
    const source = conceptKey(link.fromNotebook, link.fromConcept);
    const target = conceptKey(link.toNotebook, link.toConcept);
    const pair = link.relation === "prerequisite" ? [source, target] : [source, target].sort();
    const key = JSON.stringify([...pair, link.relation]);
    if (relations.has(key) || !nodes.has(source) || !nodes.has(target)) continue;
    relations.add(key);
    edges.push({ id: link.id, source, target, relation: link.relation });
  }
  return { nodes: [...nodes.values()], edges };
}
