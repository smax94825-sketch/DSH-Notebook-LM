"use client";

import { CircleAlert, X } from "lucide-react";
import { useEffect, useRef } from "react";
import type { ReactNode } from "react";

export class ApiRequestError extends Error {
  constructor(message: string, readonly status: number) { super(message); }
}

export async function api<T>(url: string, options?: RequestInit): Promise<T> {
  const response = await fetch(url, { cache: "no-store", ...options });
  const value = await response.json().catch(() => null);
  if (!response.ok) throw new ApiRequestError(value?.error || "无法连接工作台，请重试。", response.status);
  return value as T;
}
export const jsonBody = (body: unknown, method = "POST"): RequestInit => ({
  method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(body),
});
export const message = (error: unknown) => error instanceof Error ? error.message : "发生错误，请重试。";

export function Notice({ children }: { children: ReactNode }) {
  return <div className="notice" role="alert"><CircleAlert size={16} /> <span>{children}</span></div>;
}

export function Modal({ title, onClose, children, wide = false }: {
  title: string; onClose: () => void; children: ReactNode; wide?: boolean;
}) {
  const dialog = useRef<HTMLDialogElement>(null);
  useEffect(() => {
    const element = dialog.current;
    element?.showModal();
    return () => element?.close();
  }, []);
  return <dialog ref={dialog} className={wide ? "modal modal-wide" : "modal"} aria-label={title}
    onCancel={(event) => { event.preventDefault(); onClose(); }}>
    <header className="modal-head"><h2>{title}</h2>
      <button type="button" className="icon-button" aria-label="关闭 / Close" onClick={onClose}><X size={19} /></button>
    </header>
    {children}
  </dialog>;
}
