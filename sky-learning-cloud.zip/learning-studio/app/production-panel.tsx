"use client";

import { ChevronLeft, ChevronRight, Download, Film, FolderOpen, Presentation } from "lucide-react";
import { useCallback, useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import type { ArtifactSummary } from "../lib/contracts";
import type { Production, ProductionSummary, VideoLanguage } from "../lib/production-contracts";
import { api, jsonBody, message, Modal, Notice } from "./ui";

type Entry = ProductionSummary & { kind: Production["kind"] };
const stages = { outline: "提纲待审核 / Review outline", script: "文稿待审核 / Review script", storyboard: "分镜待审核 / Review storyboard", queued: "排队中 / Queued", rendering: "渲染中 / Rendering", ready: "已完成 / Ready", failed: "渲染失败 / Render failed" };
const labels = { slides: "教学课件", video: "教学视频" };
const englishLabels = { slides: "Slide Deck", video: "Video Overview" };

export function ProductionPanel({ base, artifacts, learning, study, hasStudyResults, children }: {
  base: string; artifacts: ArtifactSummary[]; learning: ReactNode; study: ReactNode; hasStudyResults: boolean; children: ReactNode;
}) {
  const endpoint = base + "/productions";
  const [items, setItems] = useState<Entry[]>([]);
  const [editor, setEditor] = useState<Production>();
  const [create, setCreate] = useState<Production["kind"]>();
  const [artifact, setArtifact] = useState("");
  const [language, setLanguage] = useState<VideoLanguage>("en-US");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const refresh = useCallback(async () => {
    try { setItems(await api<Entry[]>(endpoint)); }
    catch (error) { setError(message(error)); }
  }, [endpoint]);
  useEffect(() => { void refresh(); }, [refresh]);
  const waiting = items.some(({ stage }) => stage === "queued" || stage === "rendering");
  useEffect(() => {
    if (!waiting) return;
    const timer = window.setInterval(() => void refresh(), 1800);
    return () => window.clearInterval(timer);
  }, [waiting, refresh]);

  async function start(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError("");
    try {
      setEditor(await api<Production>(endpoint, jsonBody({ artifactId: artifact, kind: create, language })));
      setCreate(undefined);
      await refresh();
    } catch (error) { setError(message(error)); }
    finally { setBusy(false); }
  }

  async function open(id: string) {
    setError("");
    try { setEditor(await api<Production>(endpoint + "/" + id)); }
    catch (error) { setError(message(error)); }
  }

  return <div className="productions">
    {learning}
    {error && !create && <Notice>{error}</Notice>}
    <div className="tool-grid">
      {(["slides", "video"] as const).map((kind) => <button key={kind} className="tool-tile" disabled={!artifacts.length} onClick={() => {
        setArtifact(artifacts[0].id); setError(""); setCreate(kind);
      }}>{kind === "slides" ? <Presentation size={18} /> : <Film size={18} />}<span>{englishLabels[kind]} <small>{labels[kind]}</small></span></button>)}
      {study}
    </div>
    <h3 className="section-label">学习成果 / Outputs</h3>
    {!hasStudyResults && !items.length && <div className="empty small"><FolderOpen size={24} /><p>暂无成果 / No outputs yet</p></div>}
    {children}
    {items.map((item) => <button className="artifact-row" key={item.id} onClick={() => void open(item.id)}>
      <span className="source-icon">{item.kind === "slides" ? <Presentation size={16} /> : <Film size={16} />}</span>
      <span className="source-name"><strong>{item.title}</strong><small>{labels[item.kind]} · {stages[item.stage]}</small></span>
      <ChevronRight size={16} />
    </button>)}
    {create && <Modal title={"新建" + labels[create] + " / New " + englishLabels[create]} onClose={() => { if (!busy) setCreate(undefined); }}>
      <form className="modal-form" onSubmit={start}>
        {error && <Notice>{error}</Notice>}
        <label>学习资料 / Study materials<select value={artifact} onChange={(event) => setArtifact(event.target.value)}>
          {artifacts.map((item) => <option value={item.id} key={item.id}>{item.title} · 版本 {item.version}</option>)}
        </select></label>
        {create === "video" && <label>旁白语音 / Narration voice<select value={language} onChange={(event) => setLanguage(event.target.value as VideoLanguage)}>
          <option value="en-US">英文 / English</option><option value="zh-CN">中文 / Chinese (Windows voice required)</option>
        </select></label>}
        <footer><button className="button primary" disabled={busy}>{create === "slides" ? "创建提纲 / Create outline" : "创建分镜 / Create storyboard"}</button></footer>
      </form>
    </Modal>}
    {editor && <ProductionEditor key={editor.id} endpoint={endpoint + "/" + editor.id} initial={editor}
      close={() => { setEditor(undefined); void refresh(); }} onSaved={refresh} />}
  </div>;
}

function ProductionEditor({ endpoint, initial, close, onSaved }: {
  endpoint: string; initial: Production; close: () => void; onSaved: () => Promise<void>;
}) {
  const [item, setItem] = useState(initial);
  const [index, setIndex] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [editingVideo, setEditingVideo] = useState(false);
  const waiting = item.stage === "queued" || item.stage === "rendering";
  useEffect(() => {
    if (!waiting) return;
    let active = true;
    const timer = window.setInterval(() => {
      void api<Production>(endpoint).then((value) => {
        if (active) {
          setItem(value);
          if (value.stage !== "queued" && value.stage !== "rendering") void onSaved();
        }
      }).catch((error) => { if (active) setError(message(error)); });
    }, 1600);
    return () => { active = false; window.clearInterval(timer); };
  }, [endpoint, onSaved, waiting]);

  async function save(action: string, data: object) {
    setBusy(true); setError("");
    try {
      setItem(await api<Production>(endpoint + (action ? "/" + action : ""), jsonBody({ revision: item.revision, ...data }, "PATCH")));
      setEditingVideo(false);
      await onSaved();
    } catch (error) { setError(message(error)); }
    finally { setBusy(false); }
  }

  const count = item.kind === "slides" ? item.content.outline.length : item.content.scenes.length;
  const pager = <div className="production-pager">
    <button className="icon-button" aria-label="上一页" disabled={index === 0} onClick={() => setIndex(index - 1)}><ChevronLeft size={18} /></button>
    <label><select aria-label={"选择" + (item.kind === "slides" ? "页" : "分镜")} value={index} onChange={(event) => setIndex(Number(event.target.value))}>
      {Array.from({ length: count }, (_, i) => <option value={i} key={i}>{i + 1} / {count}</option>)}
    </select></label>
    <button className="icon-button" aria-label="下一页" disabled={index === count - 1} onClick={() => setIndex(index + 1)}><ChevronRight size={18} /></button>
  </div>;

  let content;
  if (item.kind === "slides") {
    const { outline, slides } = item.content;
    const page = outline[index];
    const slide = slides?.[index];
    function changeOutline(values: Partial<typeof page>) {
      setItem({ ...item, content: { outline: outline.map((entry, i) => i === index ? { ...entry, ...values } : entry) } } as Production);
    }
    function changeSlide(values: Partial<NonNullable<typeof slide>>) {
      if (slides) setItem({ ...item, content: { outline, slides: slides.map((entry, i) => i === index ? { ...entry, ...values } : entry) } } as Production);
    }
    content = <>
      {pager}
      {item.stage === "outline" ? <>
        <label>本页标题 / Slide title<input value={page.title} maxLength={60} onChange={(e) => changeOutline({ title: e.target.value })} /></label>
        <label>教学目标与屏显重点 / Teaching goals and key points<textarea rows={3} value={page.objective} maxLength={120} onChange={(e) => changeOutline({ objective: e.target.value })} /></label>
        <div className="inline-fields"><label>布局 / Layout<select value={page.layout} onChange={(e) => changeOutline({ layout: e.target.value as typeof page.layout })}>
          <option value="cover">封面 / Cover</option><option value="lesson">讲解 / Lesson</option><option value="exercise">练习 / Exercise</option>
        </select></label><label>建议用时（秒） / Duration (s)<input type="number" min={10} max={600} value={page.seconds} onChange={(e) => changeOutline({ seconds: Number(e.target.value) })} /></label></div>
        <footer><button className="button outline" disabled={busy} onClick={() => void save("outline", { outline })}>保存提纲 / Save outline</button>
          <button className="button primary" disabled={busy} onClick={() => void save("approve-outline", { outline })}>确认提纲并生成文稿 / Approve and draft</button></footer>
      </> : slide && <>
        <div className={"slide-preview " + (page.layout === "cover" ? "cover" : "")}>
          <h3>{slide.title}</h3><div className="slide-rule" />
          {slide.points.map((point, i) => <p key={i}>{point}</p>)}
          {slide.example && <em>{slide.example}</em>}
        </div>
        {item.stage === "script" ? <>
          <label>标题 / Title<input value={slide.title} maxLength={60} onChange={(e) => changeSlide({ title: e.target.value })} /></label>
          <label>屏显内容（最多三行） / On-screen text (up to three lines)<textarea value={slide.points.join("\n")} rows={3} onChange={(e) => changeSlide({ points: e.target.value.split("\n") })} /></label>
          <label>例句 / Example<input value={slide.example} maxLength={140} onChange={(e) => changeSlide({ example: e.target.value })} /></label>
          <label>演讲者备注 / Speaker notes<textarea value={slide.notes} maxLength={1600} rows={4} onChange={(e) => changeSlide({ notes: e.target.value })} /></label>
          <footer><button className="button quiet" disabled={busy} onClick={() => void save("outline", { outline })}>返回提纲</button>
            <button className="button outline" disabled={busy} onClick={() => void save("script", { slides })}>保存文稿</button>
            <button className="button primary" disabled={busy} onClick={() => void save("approve-script", { slides })}>确认文稿</button></footer>
        </> : <>
          <p className="speaker-notes">{slide.notes}</p>
          <footer><button className="button outline" disabled={busy} onClick={() => void save("outline", { outline })}>修订提纲</button>
            <a className="button primary" href={endpoint + "/pptx"}><Download size={16} /> 下载可编辑 PPTX</a></footer>
        </>}
      </>}
    </>;
  } else {
    const { scenes, seconds, reused } = item.content;
    const scene = scenes[index];
    function changeScene(values: Partial<typeof scene>) {
      setItem({ ...item, content: { ...item.content, scenes: scenes.map((entry, i) => i === index ? { ...entry, ...values } : entry) } } as Production);
    }
    content = waiting ? <p role="status">{stages[item.stage]}。可以关闭此窗口，稍后回来查看。</p>
      : item.stage === "ready" && !editingVideo ? <>
        <video controls preload="auto" className="video-preview" src={endpoint + "/mp4?v=" + item.revision} />
        <p>时长 {Math.round(seconds ?? 0)} 秒{reused ? "，复用 " + reused + " 个分镜" : ""}</p>
        <footer><button className="button outline" onClick={() => setEditingVideo(true)}>修改分镜</button>
          <a className="button primary" href={endpoint + "/mp4?download"}><Download size={16} /> 下载 MP4</a></footer>
      </> : <>
        {pager}
        <label>分镜标题 / Scene title<input value={scene.title} maxLength={58} onChange={(e) => changeScene({ title: e.target.value })} /></label>
        <label>画面文字 / On-screen text<textarea value={scene.visual} maxLength={180} rows={2} onChange={(e) => changeScene({ visual: e.target.value })} /></label>
        <label>旁白与字幕（每行一句） / Narration and captions (one line each)<textarea value={scene.lines.join("\n")} rows={7} onChange={(e) => changeScene({ lines: e.target.value.split("\n") })} /></label>
        <footer><button className="button outline" disabled={busy} onClick={() => void save("", { scenes })}>保存分镜</button>
          <button className="button primary" disabled={busy} onClick={() => void save("render", { scenes })}>{item.stage === "failed" ? "重新渲染" : "确认分镜并渲染"}</button></footer>
      </>;
  }
  return <Modal title={labels[item.kind] + " · " + item.title} wide onClose={() => { if (!busy) close(); }}>
    <div className="modal-form production-editor">
      <p className="editor-stage">版本 {item.revision} · {stages[item.stage]}</p>
      {(error || item.error) && <Notice>{error || item.error}</Notice>}
      {content}
    </div>
  </Modal>;
}
