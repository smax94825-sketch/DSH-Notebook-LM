import Image from "next/image";
import Link from "next/link";

export function Brand({ home = true }: { home?: boolean }) {
  const logo = <Image className="brand-logo" src="/sky-learning-logo.png" alt="Sky Learning" width={2172} height={724} unoptimized />;
  return home ? <Link className="brand" href="/" aria-label="首页 / Sky Learning home">{logo}</Link> : logo;
}
