"use client";

import { Monitor, Moon, Sun } from "lucide-react";
import { useSyncExternalStore } from "react";
import { themeStorageKey } from "./theme-preference";

const themeChangeEvent = "studio-theme-change";
const choices = [
  { value: "system", label: "系统 / System", icon: Monitor },
  { value: "light", label: "浅色 / Light", icon: Sun },
  { value: "dark", label: "深色 / Dark", icon: Moon },
] as const;

function applyTheme(value: string | null) {
  const { dataset } = document.documentElement;
  if (value === "light" || value === "dark") dataset.theme = value;
  else delete dataset.theme;
}

function subscribe(onChange: () => void) {
  function syncPreference(event: StorageEvent) {
    if (event.storageArea === window.localStorage && (event.key === themeStorageKey || event.key === null)) {
      applyTheme(event.newValue);
      onChange();
    }
  }
  window.addEventListener("storage", syncPreference);
  window.addEventListener(themeChangeEvent, onChange);
  return () => {
    window.removeEventListener("storage", syncPreference);
    window.removeEventListener(themeChangeEvent, onChange);
  };
}

function currentTheme() {
  return document.documentElement.dataset.theme ?? "system";
}

export function ThemeSwitch() {
  const theme = useSyncExternalStore(subscribe, currentTheme, () => "system");
  const Icon = choices.find(({ value }) => value === theme)?.icon ?? Monitor;
  return <label className="theme-switch">
    <Icon size={16} aria-hidden="true" />
    <select aria-label="配色模式 / Appearance" value={theme} onChange={(event) => {
      const { value } = event.currentTarget;
      applyTheme(value);
      try {
        if (value === "system") localStorage.removeItem(themeStorageKey);
        else localStorage.setItem(themeStorageKey, value);
      } catch { /* The current page can still switch when storage is unavailable. */ }
      window.dispatchEvent(new Event(themeChangeEvent));
    }}>
      {choices.map(({ value, label }) => <option key={value} value={value}>{label}</option>)}
    </select>
  </label>;
}
