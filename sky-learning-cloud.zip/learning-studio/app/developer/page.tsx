"use client";

import { ArrowLeft, LockKeyhole } from "lucide-react";
import Link from "next/link";
import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import type { DeveloperSession } from "../../lib/developer-auth";
import { ApiSettingsForm } from "../api-settings";
import { Brand } from "../brand";
import { AccountActions, useDeveloperMode } from "../session";
import { api, jsonBody, message, Notice } from "../ui";
import { DeveloperUsers } from "./users";

const endpoint = "/api/developer/session";
const unlockAgain = "开发者解锁已失效，请重新输入密码。 / Developer access ended. Enter your password again.";

export default function DeveloperSettings() {
  const enabled = useDeveloperMode();
  return <>
    <header className="topbar"><Brand /><AccountActions /></header>
    <main className="library developer-page">
      <Link href="/" className="button quiet"><ArrowLeft size={16} /> 笔记本 / Notebooks</Link>
      <h1>开发者后台 / Developer console</h1>
      {enabled ? <DeveloperAccess /> :
        <p>请在本机启用开发者模式。 / Enable developer mode on this computer.</p>}
    </main>
  </>;
}

function DeveloperAccess() {
  const [session, setSession] = useState<DeveloperSession>();
  const [password, setPassword] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [lockNotice, setLockNotice] = useState("");
  const [tab, setTab] = useState<"settings" | "users">("settings");
  const sessionVersion = useRef(0);

  const readSession = useCallback((wasUnlocked = false) => {
    const version = ++sessionVersion.current;
    return api<DeveloperSession>(endpoint).then((value) => {
      if (version !== sessionVersion.current) return;
      setSession(value);
      setError("");
      if (wasUnlocked && !value.expiresAt) setLockNotice(unlockAgain);
    }).catch((error) => {
      if (version === sessionVersion.current) setError(message(error));
    });
  }, []);
  const clearUnlock = useCallback(() => {
    sessionVersion.current++;
    setSession((current) => current && { configured: current.configured, expiresAt: null });
    setError("");
    setLockNotice(unlockAgain);
  }, []);

  useEffect(() => { void readSession(); }, [readSession]);
  useEffect(() => {
    if (!session?.expiresAt) return;
    const timeout = window.setTimeout(() => void readSession(true), session.remainingMs);
    function recheck() {
      if (!busy && document.visibilityState === "visible") void readSession(true);
    }
    document.addEventListener("visibilitychange", recheck);
    return () => {
      clearTimeout(timeout);
      document.removeEventListener("visibilitychange", recheck);
    };
  }, [session, busy, readSession]);

  async function unlock(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    sessionVersion.current++;
    setBusy(true);
    setError("");
    try {
      setSession(await api<DeveloperSession>(endpoint, jsonBody({ password })));
      setLockNotice("");
    }
    catch (error) { setError(message(error)); }
    finally { setPassword(""); setBusy(false); }
  }

  async function lock() {
    sessionVersion.current++;
    setBusy(true);
    setError("");
    try {
      setSession(await api<DeveloperSession>(endpoint, { method: "DELETE" }));
      setLockNotice("");
    }
    catch (error) { setError(message(error)); }
    finally { setBusy(false); }
  }

  return <section className="developer-panel">
    {session?.expiresAt ? <>
      <div className="developer-lockbar">
        <div className="segmented" aria-label="后台板块 / Console sections">
          <button type="button" aria-pressed={tab === "settings"} onClick={() => setTab("settings")}>模型接口 / Model API</button>
          <button type="button" aria-pressed={tab === "users"} onClick={() => setTab("users")}>账号与资料 / Users and sources</button>
        </div>
        <button className="button outline" type="button" disabled={busy} onClick={() => void lock()}>
          <LockKeyhole size={16} /> 锁定 / Lock
        </button>
      </div>
      {error && <div className="modal-form"><Notice>{error}</Notice></div>}
      {tab === "settings" ? <ApiSettingsForm onLocked={clearUnlock} /> : <DeveloperUsers onLocked={clearUnlock} />}
    </> : session?.configured ? <form className="modal-form" onSubmit={unlock}>
      {error && <Notice>{error}</Notice>}
      {!error && lockNotice && <Notice>{lockNotice}</Notice>}
      <label>开发者密码 / Developer password
        <input type="password" required maxLength={128} autoComplete="current-password" value={password}
          onChange={(event) => setPassword(event.target.value)} />
      </label>
      <footer><button className="button primary" disabled={busy || !password}>
        <LockKeyhole size={16} /> 解锁 / Unlock
      </button></footer>
    </form> : <div className="modal-form">
      {error ? <Notice>{error}</Notice> : session ? <>
        <p>请在项目目录的终端中设置开发者密码。 / Set a developer password from a terminal in the project folder.</p>
        <code>npm run developer:password</code>
      </> : <p className="loading">读取锁定状态 / Checking lock status</p>}
      {(error || session) && <footer><button className="button outline" onClick={() => void readSession()}>
        刷新状态 / Refresh
      </button></footer>}
    </div>}
  </section>;
}
