"use client";

import { ChevronLeft, ChevronRight, ExternalLink, RefreshCw } from "lucide-react";
import { useEffect, useState } from "react";
import type { Chunk } from "../../lib/contracts";
import type { DeveloperSource, DeveloperUser } from "../../lib/developer-users";
import { api, ApiRequestError, message, Modal, Notice } from "../ui";

const usersUrl = "/api/developer/users";
const loginTime = new Intl.DateTimeFormat("zh-CN", { dateStyle: "medium", timeStyle: "short" });

function useAdminData<T>(url: string, onLocked: () => void, revision = 0) {
  const [result, setResult] = useState<{ url: string; data?: T; error?: string }>();
  useEffect(() => {
    const controller = new AbortController();
    void api<T>(url, { signal: controller.signal }).then((data) => {
      if (!controller.signal.aborted) setResult({ url, data });
    }).catch((error) => {
      if (controller.signal.aborted) return;
      if (error instanceof ApiRequestError && error.status === 401) onLocked();
      else setResult({ url, error: message(error) });
    });
    return () => controller.abort();
  }, [url, onLocked, revision]);
  return result?.url === url ? result : undefined;
}

export function DeveloperUsers({ onLocked }: { onLocked: () => void }) {
  const [revision, setRevision] = useState(0);
  const [userId, setUserId] = useState("");
  const result = useAdminData<DeveloperUser[]>(usersUrl, onLocked, revision);
  const selected = result?.data?.find(({ id }) => id === userId);
  return <div className="modal-form">
    <div className="admin-users-heading">
      <p>登录状态按有效会话统计。 / Status is based on active sessions.</p>
      <button className="button outline" type="button" onClick={() => setRevision((value) => value + 1)}>
        <RefreshCw size={15} /> 刷新 / Refresh
      </button>
    </div>
    {result?.error && <Notice>{result.error}</Notice>}
    {!result && <p className="loading">正在读取账号 / Loading accounts</p>}
    {result?.data?.length === 0 && <p>暂无 QQ 账号。 / No QQ accounts yet.</p>}
    {!!result?.data?.length && <ul className="admin-list">
      {result.data.map((user) => <li key={user.id}>
        <button className="admin-row" type="button" aria-pressed={selected?.id === user.id}
          onClick={() => setUserId(selected?.id === user.id ? "" : user.id)}>
          <span><strong>{user.name}</strong><small>QQ ID {user.qq}</small></span>
          <span><strong>{user.activeSessions ? "已登录 / Signed in" : "未登录 / Signed out"}</strong>
            <small>{user.lastLoginAt ? loginTime.format(user.lastLoginAt) : "无登录时间记录 / No login time recorded"}</small></span>
          <ChevronRight size={16} />
        </button>
      </li>)}
    </ul>}
    {selected && <UserSources key={selected.id} user={selected} onLocked={onLocked} revision={revision} />}
  </div>;
}

function UserSources({ user, onLocked, revision }: { user: DeveloperUser; onLocked: () => void; revision: number }) {
  const base = `${usersUrl}/${user.id}/sources`;
  const result = useAdminData<DeveloperSource[]>(base, onLocked, revision);
  const [sourceId, setSourceId] = useState("");
  const selected = result?.data?.find(({ id }) => id === sourceId);
  return <section className="admin-sources">
    <h2>上传资料 / Uploaded sources · {user.name}</h2>
    {result?.error && <Notice>{result.error}</Notice>}
    {!result && <p className="loading">正在读取资料 / Loading sources</p>}
    {result?.data?.length === 0 && <p>暂无上传资料。 / No uploaded sources yet.</p>}
    {!!result?.data?.length && <ul className="admin-list">
      {result.data.map((source) => <li key={source.id}>
        <button className="admin-row" type="button" onClick={() => setSourceId(source.id)}>
          <span><strong>{source.title}</strong><small>{source.notebook} · {source.kind === "pdf" ? "PDF" : "文本 / Text"}</small></span>
          <ChevronRight size={16} />
        </button>
      </li>)}
    </ul>}
    {selected && <SourcePreview key={selected.id} endpoint={base + "/" + selected.id} source={selected} onLocked={onLocked} close={() => setSourceId("")} />}
  </section>;
}

function SourcePreview({ endpoint, source, onLocked, close }: {
  endpoint: string; source: DeveloperSource; onLocked: () => void; close: () => void;
}) {
  const [position, setPosition] = useState(1);
  const result = useAdminData<{ chunks: Chunk[] }>(endpoint + "?position=" + position, onLocked);
  return <Modal title={source.title} wide onClose={close}>
    <div className="reader-controls">
      <div className="admin-preview-pager">
        <button className="icon-button" type="button" disabled={position === 1} aria-label="上一处 / Previous" onClick={() => setPosition(position - 1)}><ChevronLeft size={18} /></button>
        <span>{source.kind === "pdf" ? "页 / Page" : "段 / Paragraph"} {position} / {source.positions}</span>
        <button className="icon-button" type="button" disabled={position >= source.positions} aria-label="下一处 / Next" onClick={() => setPosition(position + 1)}><ChevronRight size={18} /></button>
      </div>
      {source.kind === "pdf" && <a className="button outline" href={endpoint + "/pdf#page=" + position} target="_blank" rel="noreferrer">
        打开原始 PDF / Open PDF <ExternalLink size={15} />
      </a>}
    </div>
    <div className="reader-body">
      {result?.error && <Notice>{result.error}</Notice>}
      {!result && <p className="loading">正在读取原文 / Loading text</p>}
      {result?.data?.chunks.map((chunk) => <p key={chunk.id}>{chunk.text}</p>)}
      {result?.data?.chunks.length === 0 && <p>此页没有可提取的文字。 / This page has no extractable text.</p>}
    </div>
  </Modal>;
}
