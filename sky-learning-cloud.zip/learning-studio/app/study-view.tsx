"use client";

import Link from "next/link";
import { ArrowRight, BookOpen, Check, Clock3, GitMerge, Play, Plus } from "lucide-react";
import { useEffect, useId, useState } from "react";
import type { FormEvent } from "react";
import type { ArtifactSummary, Citation } from "../lib/contracts";
import type { conceptLibrary, studyData } from "../lib/study";
import { api, jsonBody, message, Modal, Notice } from "./ui";
import { KnowledgeGraph } from "./knowledge-graph";

type Data = ReturnType<typeof studyData>;
type Library = ReturnType<typeof conceptLibrary>;
const relations = { related: "关联 / Related", prerequisite: "先修 / Prerequisite", contrast: "对比 / Contrast" };
const time = (seconds: number) => seconds >= 60 ? Math.floor(seconds / 60) + " 分 " + seconds % 60 + " 秒" : seconds + " 秒";
const stepStatus = (current: boolean, reviewed: boolean) => current
  ? "学习中 / In progress" : reviewed ? "已复习 / Reviewed" : "待学习 / To study";

export function StudyView({ base, notebookId, artifacts, graph = false, close, onRead }: {
  base: string; notebookId: string; artifacts: ArtifactSummary[]; graph?: boolean; close: () => void;
  onRead: (ref: Citation, trigger?: HTMLElement) => void;
}) {
  const [data, setData] = useState<Data>();
  const [library, setLibrary] = useState<Library>([]);
  const [tab, setTab] = useState<"path" | "history">("path");
  const [artifactId, setArtifact] = useState(artifacts[0]?.id ?? "");
  const [minutes, setMinutes] = useState(30);
  const [goal, setGoal] = useState<"understand" | "practice">("understand");
  const [focus, setFocus] = useState<string[]>([]);
  const [running, setRunning] = useState<{ id: string; started: number }>();
  const [elapsed, setElapsed] = useState(0);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [linking, setLinking] = useState(false);
  const [linkFrom, setLinkFrom] = useState("");
  const [linkTarget, setLinkTarget] = useState("");
  const routeId = useId();
  const stepId = (index: number) => routeId + "-step-" + index;

  useEffect(() => {
    let active = true;
    void Promise.all([api<Data>(base + "/study"), api<Library>("/api/concepts")]).then(([value, items]) => {
      if (!active) return;
      setData(value); setLibrary(items);
      if (value.plan) {
        setArtifact(value.plan.artifactId); setMinutes(value.plan.minutes); setGoal(value.plan.goal); setFocus(value.plan.focus);
      }
    }).catch((error) => { if (active) setError(message(error)); });
    return () => { active = false; };
  }, [base]);

  useEffect(() => {
    if (!running) return;
    const timer = window.setInterval(() => setElapsed(Math.floor((Date.now() - running.started) / 1000)), 1000);
    return () => window.clearInterval(timer);
  }, [running]);

  async function submit(action: string, input: unknown) {
    if (busy) return false;
    setBusy(true); setError("");
    try { setData(await api<Data>(base + "/study/" + action, jsonBody(input))); return true; }
    catch (error) { setError(message(error)); return false; }
    finally { setBusy(false); }
  }

  async function end(outcome: "reviewed" | "mastered") {
    if (!running || !data?.plan) return;
    const seconds = Math.max(1, Math.min(14400, Math.floor((Date.now() - running.started) / 1000)));
    if (await submit("events", { artifactId: data.plan.artifactId, conceptId: running.id, seconds, outcome })) {
      setRunning(undefined); setElapsed(0);
    }
  }

  const local = library.filter((item) => item.notebookId === notebookId);
  const external = library.filter((item) => item.notebookId !== notebookId);
  const picked = library.find((item) => item.id === artifactId);
  const from = local.find((item) => item.id === linkFrom);
  const target = external.find((item) => item.id === linkTarget);
  async function addLink(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const fields = Object.fromEntries(new FormData(event.currentTarget));
    if (await submit("links", { artifactId: linkFrom, targetArtifactId: linkTarget, ...fields })) setLinking(false);
  }
  const endpoint = (node: Data["graph"][number]["from"]) => ({
    href: "/notebooks/" + node.notebookId + "?concept=" + encodeURIComponent(node.id) + "&artifact=" + node.artifactId,
    label: node.title,
  });
  return <Modal title={graph ? "知识图谱 / Knowledge graph" : "学习路径与记录 / Study path and activity"} wide onClose={close}>
    {!graph && <div className="segmented">{([["path", "学习路径 / Study path"], ["history", "时间线 / Timeline"]] as const).map(([value, label]) =>
      <button key={value} aria-pressed={tab === value} onClick={() => setTab(value)}>{label}</button>)}</div>}
    <div className="modal-form">
      {error && <Notice>{error}</Notice>}
      {!data && !error && <p className="loading">读取学习记录 / Loading study activity</p>}
      {running && <div className="study-timer" role="status"><Clock3 size={17} /> 学习计时 {time(elapsed)}
        <button className="button outline" disabled={busy} onClick={() => void end("reviewed")}>记录已复习</button>
        <button className="button primary" disabled={busy} onClick={() => void end("mastered")}>标为已掌握</button></div>}
      {!graph && tab === "path" && data && <>
        {!artifacts.length ? <p>生成学习资料后即可安排学习路径。 / Create study materials to plan your studies.</p> : <>
          {!!data.steps.length && <figure className="study-map" aria-labelledby={routeId}>
            <figcaption>
              <h3 id={routeId}>学习路径图 / Study map</h3>
              <p>{data.steps.length} 步 · 预计 {data.steps.reduce((total, step) => total + step.minutes, 0)} 分钟</p>
            </figcaption>
            <ol className="study-map-nodes" role="list">
              {data.steps.map((step, index) => {
                const current = running?.id === step.id;
                return <li className="study-map-node" key={step.id}>
                  <button type="button" aria-current={current ? "step" : undefined} aria-controls={stepId(index)}
                    onClick={() => {
                      const target = document.getElementById(stepId(index));
                      target?.focus({ preventScroll: true });
                      target?.scrollIntoView({ block: "nearest" });
                    }}>
                    <span className="study-map-meta"><span className="study-map-number">{index + 1}</span>{step.minutes} 分钟</span>
                    <strong>{step.title}</strong>
                    <small>{stepStatus(current, step.reviewed)}</small>
                  </button>
                  {index < data.steps.length - 1 && <ArrowRight size={16} className="study-map-arrow" aria-hidden="true" />}
                </li>;
              })}
            </ol>
          </figure>}
          <form className="study-settings" onSubmit={(event) => { event.preventDefault(); void submit("plan", { artifactId, minutes, goal, focus }); }}>
            <label>学习资料 / Study materials<select value={artifactId} onChange={(e) => { setArtifact(e.target.value); setFocus([]); }}>
              {artifacts.map((item) => <option key={item.id} value={item.id}>{item.title} · 版本 {item.version}</option>)}
            </select></label>
            <div className="inline-fields"><label>可用分钟 / Minutes available<input type="number" min={5} max={180} required value={minutes} onChange={(e) => setMinutes(Number(e.target.value))} /></label>
              <label>目标 / Goal<select value={goal} onChange={(e) => setGoal(e.target.value as typeof goal)}><option value="understand">理解讲义 / Understand</option><option value="practice">自测练习 / Practice</option></select></label></div>
            {!!picked?.concepts.length && <details><summary>指定优先知识点 / Choose priority topics</summary><div className="focus-choices">
              {picked.concepts.map((concept) => <label key={concept.id}><input type="checkbox" checked={focus.includes(concept.id)}
                onChange={(e) => setFocus(e.target.checked ? [...focus, concept.id] : focus.filter((id) => id !== concept.id))} />{concept.title}</label>)}
            </div></details>}
            <footer><button className="button primary" disabled={busy || !!running}>安排学习路径 / Plan study path</button></footer>
          </form>
          {data.plan && data.progress && <section className="study-route" aria-labelledby="study-route-title">
            <header className="study-route-heading">
              <h3 id="study-route-title">本次学习路线 / Session roadmap</h3>
              <p>{data.steps.length} 项 · 预计 {data.steps.reduce((total, step) => total + step.minutes, 0)} 分钟</p>
            </header>
            <div className="study-mastery">
              <span aria-live="polite">知识点掌握进度 {data.progress.mastered} / {data.progress.total}</span>
              <progress aria-label="所选资料的掌握进度" max={Math.max(1, data.progress.total)} value={data.progress.mastered} />
            </div>
            {!data.steps.length && <p>这一份资料的知识点已全部标为掌握。</p>}
            {!!data.steps.length && <ol className="study-route-steps">
              {data.steps.map((step, index) => {
                const current = running?.id === step.id;
                return <li key={step.id} id={stepId(index)} tabIndex={-1} className="study-route-node" data-active={current} aria-current={current ? "step" : undefined}>
                  <span className="study-route-marker" aria-label={`第 ${index + 1} 步`}>{index + 1}</span>
                  <div className="study-step">
                    <div>
                      <small>{stepStatus(current, step.reviewed)} · {step.minutes} 分钟</small>
                      <h4>{step.title}</h4><p>{step.action}</p>
                      {step.refs[0] && <button className="button quiet" aria-haspopup="dialog"
                        onClick={(event) => onRead(step.refs[0], event.currentTarget)}><BookOpen size={14} /> 回看原文</button>}
                    </div>
                    <button className="button outline" disabled={!!running} onClick={() => {
                      setElapsed(0); setRunning({ id: step.id, started: Date.now() });
                    }}><Play size={14} /> 开始学习</button>
                  </div>
                </li>;
              })}
            </ol>}
          </section>}
        </>}
      </>}
      {graph && data && <>
        <KnowledgeGraph notebookId={notebookId} refreshKey={data.graph} onNavigate={close} />
        <button className="button outline" disabled={!local.length || !external.length} onClick={() => {
          setLinkFrom(local[0].id); setLinkTarget(external[0].id); setLinking(!linking);
        }}><Plus size={16} /> 关联另一笔记本 / Link a notebook</button>
        {(!local.length || !external.length) && <p>两个笔记本都需要有学习资料。 / Both notebooks need study materials.</p>}
        {linking && from && target && <form className="study-settings" onSubmit={addLink}>
          <div className="inline-fields">
            <label>当前学习资料<select value={linkFrom} onChange={(e) => setLinkFrom(e.target.value)}>{local.map((item) =>
              <option key={item.id} value={item.id}>{item.title} · 版本 {item.version}</option>)}</select></label>
            <label>关联学习资料<select value={linkTarget} onChange={(e) => setLinkTarget(e.target.value)}>{external.map((item) =>
              <option key={item.id} value={item.id}>{item.notebook} · {item.title} · 版本 {item.version}</option>)}</select></label>
            <label>起点知识点<select key={from.id} name="conceptId">{from.concepts.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
            <label>目标知识点<select key={target.id} name="targetConceptId">{target.concepts.map((item) => <option key={item.id} value={item.id}>{item.title}</option>)}</select></label>
          </div>
          <label>关系<select name="relation" aria-label="关系">{Object.entries(relations).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label>
          <footer><button className="button primary" disabled={busy}>保存关联</button></footer>
        </form>}
        {data.graph.map((edge) => <div className="knowledge-edge" key={edge.id}>
          <Link href={endpoint(edge.from).href} onClick={close}><small>{edge.from.notebook}</small><strong>{edge.from.title}</strong></Link>
          <span><GitMerge size={16} />{relations[edge.relation]}</span>
          <Link href={endpoint(edge.to).href} onClick={close}><small>{edge.to.notebook}</small><strong>{edge.to.title}</strong></Link>
        </div>)}
      </>}
      {!graph && tab === "history" && data && <>
        <p className="study-timer"><Clock3 size={17} /> 累计学习 {time(data.totalSeconds)}</p>
        {!data.history.length && <p>完成一项学习任务后，记录会显示在这里。</p>}
        <ol className="study-history">{data.history.map((event) => <li key={event.id}>
          <span><Check size={15} /></span><div><strong>{event.title}</strong>
            <p>{new Date(event.createdAt).toLocaleString("zh-CN")} · {time(event.seconds)} · {event.outcome === "mastered" ? "已掌握" : "已复习"}</p></div>
        </li>)}</ol>
      </>}
    </div>
  </Modal>;
}
