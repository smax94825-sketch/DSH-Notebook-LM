"use client";

import { Code2, LogOut, MessageCircle } from "lucide-react";
import Link from "next/link";
import { createContext, useContext, useEffect, useState } from "react";
import type { FormEvent, ReactNode } from "react";
import { inviteCodeHtmlPattern, inviteCodePattern } from "../lib/invite-code";
import { api, ApiRequestError, jsonBody, message, Modal, Notice } from "./ui";
import { ThemeSwitch } from "./theme-switch";
import { Brand } from "./brand";

type Session = { invite: boolean; developer: boolean; user: { name: string } | null; email: string | null };
const SessionContext = createContext<{ session: Session; refresh: () => Promise<void> } | null>(null);
export const useDeveloperMode = () => useContext(SessionContext)?.session.developer ?? false;
export const useInviteMode = () => useContext(SessionContext)?.session.invite ?? false;

export function SessionGate({ children }: { children: ReactNode }) {
  const [session, setSession] = useState<Session>();
  const [error, setError] = useState("");
  async function refresh() {
    try { setSession(await api<Session>("/api/session")); setError(""); }
    catch (error) { setError(message(error)); }
  }
  useEffect(() => { void refresh(); }, []);
  if (error) return <main className="library"><Notice>{error}</Notice><button className="button outline" onClick={() => void refresh()}>重试</button></main>;
  if (!session) return <main className="library"><p className="loading">读取工作台 / Loading workspace</p></main>;
  if (!session.user) return <SignIn onSaved={refresh} />;
  return <SessionContext.Provider value={{ session, refresh }}>{children}</SessionContext.Provider>;
}

function SignIn({ onSaved }: { onSaved: () => Promise<void> }) {
  const [register, setRegister] = useState(false);
  const [invitation, setInvitation] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    const invite = new URLSearchParams(window.location.hash.slice(1)).get("invite");
    if (!invite || !inviteCodePattern.test(invite)) return;
    setInvitation(invite);
    setRegister(true);
    const url = new URL(window.location.href);
    url.hash = "";
    window.history.replaceState(window.history.state, "", url);
  }, []);

  async function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const values = Object.fromEntries(new FormData(event.currentTarget));
    setBusy(true);
    setError("");
    try {
      const input = invitation && register ? { ...values, invite: invitation } : values;
      await api("/api/session/" + (register ? "register" : "login"), jsonBody(input));
      await onSaved();
    }
    catch (error) {
      if (!register && error instanceof ApiRequestError && error.status === 404) setRegister(true);
      setError(message(error));
    }
    finally { setBusy(false); }
  }
  return <main className="login-page">
    <section>
      <div className="signin-header">
        <Brand home={false} />
        <ThemeSwitch />
      </div>
      <h1>{register && !invitation ? "使用邀请登记 / Join with an invite" : "登录学习工作台 / Sign in to your workspace"}</h1>
      <form className="modal-form" onSubmit={submit}>
        {error && <Notice>{error}</Notice>}
        <label>QQ 号 / QQ ID<input name="qq" required type="text" inputMode="numeric" pattern="[1-9][0-9]{4,11}" maxLength={12} autoComplete="username" /></label>
        {register && !invitation && <label>邀请码 / Invite code<input name="invite" required pattern={inviteCodeHtmlPattern} maxLength={43} autoComplete="off" /></label>}
        {register && <p className="upload-disclosure">管理员可在后台查看你的 QQ 号、登录状态及上传资料。 / Administrators can view your QQ ID, login status and uploaded materials.</p>}
        <button className="button primary" disabled={busy}>
          {register && !invitation ? "登记并登录 / Register and sign in" : "登录 / Sign in"}
        </button>
      </form>
      {!invitation && <button className="button quiet" disabled={busy} onClick={() => { setRegister(!register); setError(""); }}>
        {register ? "返回登录 / Back to sign in" : "使用邀请码 / Use an invite code"}
      </button>}
    </section>
  </main>;
}

export function AccountActions() {
  const context = useContext(SessionContext);
  const [open, setOpen] = useState(false);
  const [feedback, setFeedback] = useState("");
  const [sent, setSent] = useState(false);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  if (!context) return null;
  const { session, refresh } = context;
  async function submit(event: FormEvent) {
    event.preventDefault();
    setBusy(true); setError("");
    try { await api("/api/feedback", jsonBody({ message: feedback })); setSent(true); setFeedback(""); }
    catch (error) { setError(message(error)); }
    finally { setBusy(false); }
  }
  return <div className="account-actions">
    <ThemeSwitch />
    {session.developer && <Link href="/developer" className="icon-button" title="开发者 / Developer" aria-label="开发者 / Developer"><Code2 size={18} /></Link>}
    <button className="icon-button" title="反馈 / Feedback" aria-label="反馈 / Feedback" onClick={() => { setOpen(true); setSent(false); setError(""); }}><MessageCircle size={18} /></button>
    {session.invite && <button className="icon-button" title="退出登录" aria-label="退出登录" onClick={() => {
      void api("/api/session/logout", jsonBody({})).then(refresh).catch((error) => { setError(message(error)); setOpen(true); });
    }}><LogOut size={18} /></button>}
    {open && <Modal title="反馈 / Feedback" onClose={() => { if (!busy) setOpen(false); }}>
      <form className="modal-form" onSubmit={submit}>
        {error && <Notice>{error}</Notice>}
        {session.email && <a className="contact-email" href={"mailto:" + session.email}>{session.email}</a>}
        {sent ? <p role="status">反馈已提交 / Feedback sent</p> : <>
          <label>反馈内容 / Your feedback<textarea value={feedback} required maxLength={4000} rows={5} onChange={(event) => setFeedback(event.target.value)} /></label>
          <footer><button className="button primary" disabled={busy || !feedback.trim()}>提交反馈 / Send feedback</button></footer>
        </>}
      </form>
    </Modal>}
  </div>;
}
