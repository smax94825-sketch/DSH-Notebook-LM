import { pdfPartBytes, pdfUploadWorkers } from "../lib/upload-limit";
import { api, ApiRequestError, jsonBody } from "./ui";

export async function uploadPdf(base: string, file: File, onProgress: (value: number) => void) {
  if (file.size <= pdfPartBytes) {
    return api(base + "/sources?" + new URLSearchParams({ filename: file.name }), {
      method: "POST", headers: { "Content-Type": "application/pdf" }, body: file,
    });
  }

  const { uploadId } = await api<{ uploadId: string }>(base + "/pdf-uploads", jsonBody({ name: file.name, size: file.size }));
  const endpoint = base + "/pdf-uploads/" + uploadId;
  const totalParts = Math.ceil(file.size / pdfPartBytes);
  let nextPart = 0;
  let sentBytes = 0;
  let failed = false;

  async function worker() {
    while (!failed && nextPart < totalParts) {
      const index = nextPart++;
      const start = index * pdfPartBytes;
      const body = file.slice(start, start + pdfPartBytes);
      try {
        for (let attempt = 0; ; attempt++) {
          try {
            await api(endpoint + "/" + index, { method: "PUT", body });
            break;
          } catch (error) {
            if (attempt >= 2 || (error instanceof ApiRequestError && error.status < 500 && error.status !== 429)) throw error;
            await new Promise((resolve) => setTimeout(resolve, 350 * (attempt + 1)));
          }
        }
        sentBytes += body.size;
        onProgress(Math.floor(sentBytes * 100 / file.size));
      } catch (error) {
        failed = true;
        throw error;
      }
    }
  }

  try {
    onProgress(0);
    const results = await Promise.allSettled(Array.from({ length: Math.min(totalParts, pdfUploadWorkers) }, () => worker()));
    for (const result of results) if (result.status === "rejected") throw result.reason;
    return await api(endpoint, { method: "POST" });
  } catch (error) {
    await api(endpoint, { method: "DELETE" }).catch(() => {});
    throw error;
  }
}
