"use client";

import {
  ArrowDownToLine, ArrowRight, ArrowUpRight, BookOpen, Check, ChevronLeft, ChevronRight,
  CircleAlert, FileText, LoaderCircle, Plus, RotateCcw,
  Send, CalendarCheck, Upload, Network, Sparkles, Trash2,
} from "lucide-react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { useCallback, useEffect, useRef, useState } from "react";
import type { FormEvent } from "react";
import type {
  Artifact, Chunk, Citation, Exchange, Job, Notebook, Source, Workspace,
} from "../lib/contracts.ts";

import { api, jsonBody, message, Modal, Notice } from "./ui";
import { ProductionPanel } from "./production-panel";
import { StudyView } from "./study-view";
import { AccountActions, useDeveloperMode, useInviteMode } from "./session";
import { maxPdfBytes, maxPdfMb, pdfSizeMessage } from "../lib/upload-limit";
import { uploadPdf } from "./pdf-upload";
import { examLevelLabels, reviewRelationLabels, studySkillIds, studySkills } from "../lib/study-skills";
import type { StudySkill } from "../lib/study-skills";
import { Brand } from "./brand";
import { KnowledgeGraph } from "./knowledge-graph";
const date = (iso: string) => new Intl.DateTimeFormat("zh-CN", {
  year: "numeric", month: "short", day: "numeric",
}).format(new Date(iso));
const positionLabel = (source: Source) => source.kind === "pdf" ? "PDF 页" : "段落";

export function NotebookLibrary() {
  const router = useRouter();
  const [notebooks, setNotebooks] = useState<Notebook[]>();
  const [error, setError] = useState("");
  const [create, setCreate] = useState(false);
  const [title, setTitle] = useState("");
  const [busy, setBusy] = useState(false);
  const [graph, setGraph] = useState(false);
  const [removing, setRemoving] = useState<Notebook | null>(null);

  useEffect(() => {
    let active = true;
    api<Notebook[]>("/api/notebooks").then((value) => { if (active) setNotebooks(value); })
      .catch((error) => { if (active) setError(message(error)); });
    return () => { active = false; };
  }, []);

  async function save(event: FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try {
      const notebook = await api<Notebook>("/api/notebooks", jsonBody({ title }));
      router.push("/notebooks/" + notebook.id);
    } catch (error) {
      setError(message(error));
      setBusy(false);
    }
  }

  async function openSample() {
    setError(""); setBusy(true);
    try { router.push("/notebooks/" + (await api<Notebook>("/api/sample", { method: "POST" })).id); }
    catch (error) { setError(message(error)); setBusy(false); }
  }

  return <>
    <header className="topbar"><Brand /><AccountActions /></header>
    <main className="library">
      <div className="library-hero">
        <div><h1>我的笔记本 / My notebooks</h1><p>在同一处阅读资料、问答和制作学习成果。 / Read, ask, and create in one workspace.</p></div>
        <div className="library-actions">
          <button className="button outline" onClick={() => setGraph(true)}><Network size={16} /> 知识图谱 / Knowledge graph</button>
          <button className="button outline" disabled={busy} onClick={() => void openSample()}><BookOpen size={16} /> 语法示例 / Grammar demo</button>
          <button className="button primary" disabled={busy} onClick={() => { setError(""); setCreate(true); }}><Plus size={18} /> 新建笔记本 / New notebook</button></div>
      </div>
      {error && !create && <Notice>{error}</Notice>}
      {!notebooks && !error && <div className="loading"><LoaderCircle size={19} className="spin" /> 读取笔记本 / Loading notebooks</div>}
      {notebooks?.length === 0 && <div className="library-empty">
        <div className="book-illustration" aria-hidden="true"><BookOpen size={38} strokeWidth={1.35} /><span /><i /></div>
        <h2>从一份资料开始 / Start with a source</h2>
        <p>新建笔记本后，可以上传 PDF 或粘贴文字。 / Create a notebook to upload a PDF or paste text.</p>
        <button className="button outline" onClick={() => setCreate(true)}>新建笔记本 / New notebook <ArrowRight size={16} /></button>
      </div>}
      {!!notebooks?.length && <div className="notebook-grid">{notebooks.map((notebook) =>
        <article className="notebook-card" key={notebook.id}>
          <Link className="notebook-card-link" href={"/notebooks/" + notebook.id}>
            <span className="card-icon"><BookOpen size={21} /></span>
            <h2>{notebook.title}</h2><time dateTime={notebook.createdAt}>{date(notebook.createdAt)}</time>
          </Link>
          <button className="icon-button delete-control" onClick={() => setRemoving(notebook)}
            aria-label={`删除笔记本 / Delete notebook: ${notebook.title}`} title="删除笔记本 / Delete notebook"><Trash2 size={16} /></button>
        </article>
      )}</div>}
    </main>
    {graph && <Modal title="全局知识图谱 / Global knowledge graph" wide onClose={() => setGraph(false)}>
      <div className="modal-form"><KnowledgeGraph onNavigate={() => setGraph(false)} /></div>
    </Modal>}
    {removing && <DeleteConfirmation title="删除笔记本 / Delete notebook" name={removing.title} close={() => setRemoving(null)} onDelete={async () => {
      await api("/api/notebooks/" + removing.id, { method: "DELETE" });
      setNotebooks((items) => items?.filter(({ id }) => id !== removing.id));
    }}>此笔记本及其内容将从工作台移除。 / This notebook and its contents will be removed from the workspace.</DeleteConfirmation>}
    {create && <Modal title="新建笔记本 / New notebook" onClose={() => { if (!busy) setCreate(false); }}>
      <form className="modal-form" onSubmit={save}>
        {error && <Notice>{error}</Notice>}
        <label>笔记本名称 / Notebook name<input autoFocus required maxLength={120} value={title} onChange={(event) => setTitle(event.target.value)} placeholder="英语语法 / English grammar" /></label>
        <footer><button className="button primary" disabled={busy || !title.trim()}>{busy && <LoaderCircle size={16} className="spin" />} 创建 / Create</button></footer>
      </form>
    </Modal>}
  </>;
}

type View = { sourceId: string; position: number; citation?: Citation };
type SourcePage = { source: Source; position: number; chunks: Chunk[] };
type ProviderStatus = { key: boolean; kit: boolean; pdfVision?: boolean };
const modes = [
  { value: "overview", label: "概览", english: "Overview" },
  { value: "chat", label: "问答", english: "Chat" },
  { value: "studio", label: "创作", english: "Studio" },
] as const;
type Mode = typeof modes[number]["value"];
const jobLabels = { queued: "排队中 / Queued", running: "生成中 / Generating", succeeded: "已完成 / Done", failed: "生成失败 / Failed" };

export function NotebookStudio({ id, linkedArtifact, linkedConcept }: { id: string; linkedArtifact?: string; linkedConcept?: string }) {
  const base = "/api/notebooks/" + id;
  const developer = useDeveloperMode();
  const router = useRouter();
  const [workspace, setWorkspace] = useState<Workspace>();
  const [provider, setProvider] = useState<ProviderStatus>();
  const [loadError, setLoadError] = useState("");
  const [mode, setMode] = useState<Mode>("overview");
  const [dialog, setDialog] = useState<"add" | "generate" | "study" | "graph" | null>(null);
  const [reader, setReader] = useState<View | null>(null);
  const lastPosition = useRef<Pick<View, "sourceId" | "position">>(null);
  const readerTrigger = useRef<HTMLElement>(null);
  const [artifact, setArtifact] = useState<Artifact | null>(null);
  const [activeConcept, setActiveConcept] = useState<string>();
  const [artifactError, setArtifactError] = useState("");
  const [sourceError, setSourceError] = useState("");
  const [pendingSource, setPendingSource] = useState<string>();
  const [removing, setRemoving] = useState<Source | null>(null);
  const [question, setQuestion] = useState("");
  const [pendingQuestion, setPendingQuestion] = useState("");
  const [chatError, setChatError] = useState("");
  const [retrying, setRetrying] = useState<string>();
  const chatBody = useRef<HTMLDivElement>(null);
  const chatScroll = useRef(0);
  const scrollToLatest = useRef(true);
  const refreshVersion = useRef(0);
  const artifactVersion = useRef(0);

  const refresh = useCallback(async () => {
    const version = ++refreshVersion.current;
    try {
      const value = await api<Workspace>(base);
      if (version === refreshVersion.current) { setWorkspace(value); setLoadError(""); }
    } catch (error) {
      if (version === refreshVersion.current) setLoadError(message(error));
    }
  }, [base]);

  useEffect(() => {
    void refresh();
    let active = true;
    function refreshProvider() {
      void api<ProviderStatus>("/api/status").then((value) => { if (active) setProvider(value); }).catch(() => {});
    }
    refreshProvider();
    return () => {
      active = false;
      refreshVersion.current++;
      artifactVersion.current++;
    };
  }, [refresh]);

  const inProgress = workspace?.jobs.some((job) => job.status === "queued" || job.status === "running");
  useEffect(() => {
    if (!inProgress) return;
    const timer = window.setInterval(() => { void refresh(); }, 1400);
    return () => window.clearInterval(timer);
  }, [inProgress, refresh]);

  const exchangesCount = workspace?.exchanges.length ?? 0;
  useEffect(() => { scrollToLatest.current = true; }, [exchangesCount, pendingQuestion]);
  useEffect(() => {
    const body = chatBody.current;
    if (body && scrollToLatest.current && (mode === "overview" || mode === "chat")) {
      body.scrollTop = body.scrollHeight;
      scrollToLatest.current = false;
    } else if (body && (mode === "overview" || mode === "chat")) {
      body.scrollTop = chatScroll.current;
    }
  }, [mode, exchangesCount, pendingQuestion, workspace?.notebook.id]);
  async function toggle(source: Source) {
    setSourceError("");
    setPendingSource(source.id);
    try {
      await api(base + "/sources/" + source.id, jsonBody({ selected: !source.selected }, "PATCH"));
      await refresh();
    } catch (error) {
      setSourceError(message(error));
    } finally { setPendingSource(undefined); }
  }

  async function ask(event: FormEvent) {
    event.preventDefault();
    if (pendingQuestion || !question.trim()) return;
    const draft = question.trim();
    setPendingQuestion(draft);
    setChatError("");
    setQuestion("");
    try {
      await api<Exchange>(base + "/chat", jsonBody({ question: draft }));
      await refresh();
    } catch (error) {
      setChatError(message(error));
      setQuestion(draft);
    } finally { setPendingQuestion(""); }
  }

  async function openArtifact(artifactId: string) {
    const version = ++artifactVersion.current;
    setArtifactError("");
    try {
      const value = await api<Artifact>(base + "/artifacts/" + artifactId);
      if (version === artifactVersion.current) setArtifact(value);
    } catch (error) {
      if (version === artifactVersion.current) setArtifactError(message(error));
    }
  }

  useEffect(() => {
    if (!linkedArtifact) return;
    let active = true;
    void api<Artifact>(base + "/artifacts/" + linkedArtifact).then((value) => {
      if (active) { setDialog(null); setActiveConcept(linkedConcept); setArtifact(value); }
    }).catch((error) => { if (active) setArtifactError(message(error)); });
    return () => { active = false; };
  }, [base, linkedArtifact, linkedConcept]);

  async function retry(job: Job) {
    setRetrying(job.id);
    setArtifactError("");
    try {
      await api(base + "/jobs/" + job.id + "/retry", { method: "POST" });
      await refresh();
    } catch (error) {
      setArtifactError(message(error));
    } finally { setRetrying(undefined); }
  }

  const sources = workspace?.sources ?? [];
  const selected = sources.filter((source) => source.selected);
  function switchMode(next: Mode) {
    if (mode === "overview" || mode === "chat") chatScroll.current = chatBody.current?.scrollTop ?? 0;
    setMode(next);
  }

  function positionFor(sourceId: string) {
    return lastPosition.current?.sourceId === sourceId ? lastPosition.current.position : 1;
  }

  function openReader(view: View, trigger?: HTMLElement) {
    if (trigger) readerTrigger.current = trigger;
    lastPosition.current = { sourceId: view.sourceId, position: view.position };
    setReader(view);
  }

  function closeReader() {
    setReader(null);
    const trigger = readerTrigger.current;
    readerTrigger.current = null;
    requestAnimationFrame(() => trigger?.focus({ preventScroll: true }));
  }

  function readCitation(citation: Citation, trigger?: HTMLElement) {
    openReader({ sourceId: citation.sourceId, position: citation.position, citation }, trigger);
  }
  if (!workspace) return <><header className="topbar"><Brand /></header><main className="library">
    {loadError ? <Notice>{loadError}</Notice> : <div className="loading"><LoaderCircle size={19} className="spin" /> 读取笔记本</div>}
  </main></>;

  return <div className="workspace-frame">
    <header className="topbar workspace-top">
      <Brand />
      <div className="notebook-heading">
        <h1 title={workspace.notebook.title}>{workspace.notebook.title}</h1>
      </div>
      <AccountActions />
    </header>
    <nav className="panel-tabs" aria-label="工作区模式 / Workspace modes">
      {modes.map(({ value, label, english }) =>
        <button key={value} aria-controls="workspace" aria-pressed={mode === value} onClick={() => switchMode(value)}>
          <span lang="en">{english}</span><small>{label}</small></button>
      )}
    </nav>
    <main id="workspace" className="workspace" data-mode={mode}>
      <section className="panel sources-panel" aria-labelledby="sources-title">
        <header className="panel-head"><h2 id="sources-title">Sources <small>资料</small></h2></header>
        <div className="panel-scroll sources-body">
          <button className="button outline add-source" onClick={() => setDialog("add")}><Plus size={17} /> 添加资料 / Add source</button>
          {sourceError && <Notice>{sourceError}</Notice>}
          {!sources.length && <div className="empty small"><FileText size={24} /><p>上传 PDF 或粘贴文字 / Upload a PDF or paste text</p></div>}
          {!!sources.length && <p className="selection-label">用于生成学习资料 / For study materials {selected.length} / {sources.length}</p>}
          {sources.map((source) => <div key={source.id} className="source-item">
            <button className="source-open" title={source.title} aria-haspopup="dialog"
              onClick={(event) => openReader({ sourceId: source.id, position: positionFor(source.id) }, event.currentTarget)}>
              <FileText size={17} className="source-file-icon" />
              <span className="source-name"><strong>{source.title}</strong>
                <small>{source.positions} {source.kind === "pdf" ? "页" : "段"}{!source.textPending && source.readable < source.positions ? ` · ${source.readable} 页可读` : ""}</small></span>
            </button>
            <input aria-label={"用于生成学习资料：" + source.title} type="checkbox" checked={source.selected}
              disabled={!!pendingSource || !!pendingQuestion} onChange={() => void toggle(source)} />
            <button className="icon-button delete-control" onClick={() => setRemoving(source)} disabled={!!pendingSource || !!pendingQuestion}
              title="删除资料 / Delete source" aria-label={`删除资料 / Delete source: ${source.title}`}><Trash2 size={15} /></button>
          </div>)}
        </div>
      </section>

      <section className="panel chat-panel" aria-labelledby="chat-title">
        <header className="panel-head"><h2 id="chat-title">Chat <small>问答</small></h2></header>
        <div className="panel-scroll chat-body" ref={chatBody} aria-busy={!!pendingQuestion}>
          {loadError && <Notice>{loadError}</Notice>}
          {!workspace.exchanges.length && !pendingQuestion && <div className="chat-empty">
            <p>直接向 DeepSeek 提问。 / Ask DeepSeek directly.</p>
          </div>}
          {workspace.exchanges.map((exchange) => <article className="exchange" key={exchange.id}>
            <p className="question-bubble">{exchange.question}</p>
            {exchange.answer.status === "direct" ? <div className="answer-section">
              <small className="answer-byline">DeepSeek</small><p className="answer-text">{exchange.answer.text}</p>
            </div> : exchange.answer.status === "insufficient"
              ? <p className="answer-text">勾选的资料不足以回答此问题。 / The selected sources don’t contain enough evidence.</p>
              : exchange.answer.sections.map((section, index) => <div className="answer-section" key={index}>
                <p className="answer-text">{section.text}</p><Citations refs={section.refs} sources={sources} onRead={readCitation} />
              </div>)}
          </article>)}
          {pendingQuestion && <article className="exchange">
            <p className="question-bubble">{pendingQuestion}</p><div className="loading" role="status"><LoaderCircle size={16} className="spin" />
              DeepSeek 正在回答 / DeepSeek is responding
            </div>
          </article>}
        </div>
        <form className="composer" onSubmit={ask}>
          {chatError && <Notice>{chatError}</Notice>}
          {provider?.key === false && !chatError && <div className="setup-hint"><CircleAlert size={14} /><ProviderHint developer={developer} /></div>}
          <div className="composer-input">
            <textarea aria-label="输入问题 / Ask a question" rows={2} maxLength={2000}
              placeholder="向 DeepSeek 提问… / Ask DeepSeek…"
              value={question} onChange={(event) => setQuestion(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === "Enter" && !event.shiftKey && !event.nativeEvent.isComposing) {
                  event.preventDefault();
                  event.currentTarget.form?.requestSubmit();
                }
              }} />
            <button className="send" type="submit" aria-label="发送问题 / Send question"
              disabled={!question.trim() || !!pendingQuestion || provider?.key === false}><Send size={17} /></button>
          </div>
        </form>
      </section>

      <section className="panel studio-panel" aria-labelledby="studio-title">
        <header className="panel-head"><h2 id="studio-title">Studio <small>创作</small></h2></header>
        <div className="panel-scroll studio-body">
          <ProductionPanel base={base} artifacts={workspace.artifacts}
            hasStudyResults={!!workspace.artifacts.length || !!workspace.jobs.length}
            learning={<div className="studio-first">
              <button className="tool-tile studio-study-materials" disabled={!sources.length} onClick={() => setDialog("generate")}
                aria-describedby="studio-first-hint">
                <BookOpen size={20} /><span>学习资料 <small>Study materials</small></span>
              </button>
              <p id="studio-first-hint">{sources.length
                ? "建议先生成学习资料，再制作课件、视频或安排学习路径。 / Start with study materials."
                : "先添加资料，再生成学习资料。 / Add a source to get started."}</p>
            </div>}
            study={<>
              <button className="tool-tile" onClick={() => setDialog("graph")}><Network size={18} /><span>Knowledge graph <small>知识图谱</small></span></button>
              <button className="button quiet studio-path" onClick={() => setDialog("study")}><CalendarCheck size={16} /> 学习路径 / Study path</button>
            </>}>
            {artifactError && <Notice>{artifactError}</Notice>}
            {workspace.jobs.filter((job) => job.status !== "succeeded").map((job) => <div key={job.id} className={"job job-" + job.status}>
              <div>{job.status === "failed" ? <CircleAlert size={15} /> : <LoaderCircle size={15} className={job.status === "running" ? "spin" : ""} />}
                <strong>{job.scope || studySkills[job.skill ?? "standard"].label}</strong><span>{jobLabels[job.status]}</span></div>
              {job.progress && job.progress.total > 1 && <p>已完成 {job.progress.completed}/{job.progress.total} 批 / Batches completed</p>}
              {job.error && <p>{job.error}</p>}
              {job.status === "failed" && <button className="button quiet" disabled={!!retrying} onClick={() => void retry(job)}><RotateCcw size={14} /> 重试</button>}
            </div>)}
            {workspace.artifacts.map((item) => <button key={item.id} className="artifact-row" onClick={() => void openArtifact(item.id)}>
              <span className="source-icon text"><Check size={16} /></span>
              <span className="source-name"><strong>{item.title}</strong><small>版本 {item.version} · {date(item.createdAt)}</small></span>
              <ChevronRight size={16} />
            </button>)}
          </ProductionPanel>
        </div>
      </section>
    </main>
    {dialog === "add" && <AddSource base={base} close={() => setDialog(null)} onSaved={refresh} />}
    {removing && <DeleteConfirmation title="删除资料 / Delete source" name={removing.title} close={() => setRemoving(null)} onDelete={async () => {
      await api(base + "/sources/" + removing.id, { method: "DELETE" });
      if (reader?.sourceId === removing.id) setReader(null);
      await refresh();
    }}>它将从资料列表和后续问答中移除，已有引用仍可回看。 / The source will be removed from your list and future answers. Existing citations still open.</DeleteConfirmation>}
    {dialog === "generate" && <Generate base={base} sources={sources} provider={provider} close={() => setDialog(null)} onSaved={refresh} />}
    {(dialog === "study" || dialog === "graph") && <StudyView base={base} notebookId={id} artifacts={workspace.artifacts}
      key={dialog} graph={dialog === "graph"} close={() => setDialog(null)} onRead={readCitation} />}
    {artifact && <ArtifactView key={artifact.id + (activeConcept ?? "")} base={base} artifact={artifact} sources={sources}
      activeConcept={activeConcept} close={() => {
        setArtifact(null);
        setActiveConcept(undefined);
        if (linkedArtifact) router.replace("/notebooks/" + id, { scroll: false });
      }} onRead={readCitation} />}
    {reader && <Modal title="原文预览 / Source preview" wide onClose={closeReader}>
      <Reader key={reader.sourceId} base={base} view={reader} change={openReader} />
    </Modal>}
  </div>;
}

function DeleteConfirmation({ title, name, close, onDelete, children }: {
  title: string; name: string; close: () => void; onDelete: () => Promise<void>; children: string;
}) {
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  async function remove(event: FormEvent) {
    event.preventDefault();
    setError("");
    setBusy(true);
    try { await onDelete(); close(); }
    catch (error) { setError(message(error)); setBusy(false); }
  }
  return <Modal title={title} onClose={() => { if (!busy) close(); }}>
    <form className="modal-form" onSubmit={remove}>
      <strong className="delete-name">{name}</strong>
      <p>{children}</p>
      {error && <Notice>{error}</Notice>}
      <footer>
        <button autoFocus type="button" className="button outline" disabled={busy} onClick={close}>取消 / Cancel</button>
        <button className="button danger" disabled={busy}><Trash2 size={16} /> 删除 / Delete</button>
      </footer>
    </form>
  </Modal>;
}

function ProviderHint({ developer }: { developer: boolean }) {
  return developer
    ? <Link href="/developer">配置模型接口 / Configure model API</Link>
    : <span>模型服务尚未配置。 / Model service is not configured.</span>;
}

type ReadCitation = (citation: Citation, trigger?: HTMLElement) => void;

function Citations({ refs, sources, onRead }: { refs: Citation[]; sources: Source[]; onRead: ReadCitation }) {
  return <div className="citations">{refs.map((ref, index) => {
    const source = sources.find(({ id }) => id === ref.sourceId);
    return <button className="citation" key={ref.chunkId + index} aria-haspopup="dialog" onClick={(event) => onRead(ref, event.currentTarget)} title={ref.quote}>
      <BookOpen size={12} /><span>{source?.title ?? "资料"} · {source ? positionLabel(source) : "位置"} {ref.position}{ref.visual ? " · 视觉读取" : ""}</span><ArrowUpRight size={12} />
    </button>;
  })}</div>;
}

function AddSource({ base, close, onSaved }: { base: string; close: () => void; onSaved: () => Promise<void> }) {
  const [kind, setKind] = useState<"pdf" | "text">("pdf");
  const [file, setFile] = useState<File>();
  const invite = useInviteMode();
  const [title, setTitle] = useState("");
  const [text, setText] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);
  const [progress, setProgress] = useState<number>();

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (busy || (kind === "pdf" ? !file : !title.trim() || !text.trim())) return;
    setError("");
    setProgress(undefined);
    setBusy(true);
    try {
      if (kind === "pdf" && file) {
        await uploadPdf(base, file, setProgress);
      } else {
        await api(base + "/sources", jsonBody({ title, text }));
      }
      await onSaved();
      close();
    } catch (error) {
      setError(message(error));
      setBusy(false);
    }
  }

  return <Modal title="添加资料 / Add source" onClose={() => { if (!busy) close(); }}>
    <div className="segmented">
      <button aria-pressed={kind === "pdf"} disabled={busy} onClick={() => { setKind("pdf"); setError(""); }}>上传 PDF / Upload PDF</button>
      <button aria-pressed={kind === "text"} disabled={busy} onClick={() => { setKind("text"); setError(""); }}>粘贴文字 / Paste text</button>
    </div>
    <form className="modal-form" onSubmit={submit}>
      {error && <Notice>{error}</Notice>}
      {invite && <p className="upload-disclosure">管理员可查看你上传的 PDF 和粘贴的文字。 / Administrators can view uploaded PDFs and pasted text.</p>}
      {kind === "pdf" && <p className="upload-disclosure" id="pdf-upload-hint">
        大文件上传到云服务器可能需要几分钟，请等待上传完成。 / Large files may take a few minutes to upload. Please wait for the upload to finish.
      </p>}
      {kind === "pdf" ? <label className="upload-field">
        <Upload size={26} />
        <strong>{file?.name ?? "选择 PDF / Choose a PDF"}</strong>
        <small>每份最多 {maxPdfMb} MB / Up to {maxPdfMb} MB per file</small>
        <input type="file" aria-label="PDF 文件 / PDF file" aria-describedby="pdf-upload-hint" accept=".pdf,application/pdf" disabled={busy}
          onChange={(event) => {
            const picked = event.target.files?.[0];
            if (picked && picked.size > maxPdfBytes) {
              event.target.value = "";
              setFile(undefined);
              setError(pdfSizeMessage);
            } else {
              setFile(picked);
              setError("");
            }
          }} />
      </label> : <>
        <label>资料名称 / Source title<input autoFocus value={title} disabled={busy} required maxLength={120} onChange={(event) => setTitle(event.target.value)} /></label>
        <label>原文 / Source text<textarea value={text} disabled={busy} required maxLength={400000} rows={7} onChange={(event) => setText(event.target.value)} placeholder="用空行分隔段落 / Separate paragraphs with blank lines" /></label>
      </>}
      {busy && progress !== undefined && <div className="upload-progress">
        <progress aria-label="PDF 上传进度 / PDF upload progress" max={100} value={progress} />
        <span role="status">{progress === 100 ? "正在保存 PDF / Saving PDF" : `${progress}%`}</span>
      </div>}
      <footer><button className="button primary" disabled={busy || (kind === "pdf" ? !file : !title.trim() || !text.trim())}>
        {busy && <LoaderCircle size={16} className="spin" />}{busy
          ? kind === "pdf" ? "正在上传 PDF / Uploading PDF" : "正在保存 / Saving"
          : "添加资料 / Add source"}
      </button></footer>
    </form>
  </Modal>;
}

function Generate({ base, sources, provider, close, onSaved }: {
  base: string; sources: Source[]; provider?: ProviderStatus; close: () => void; onSaved: () => Promise<void>;
}) {
  const developer = useDeveloperMode();
  const [scope, setScope] = useState("");
  const [skill, setSkill] = useState<StudySkill>("standard");
  const [customRange, setCustomRange] = useState(false);
  const [ranges, setRanges] = useState(() => Object.fromEntries(sources.map((source) =>
    [source.id, { use: source.selected, start: "1", end: String(source.positions) }])));
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const chosen = sources.filter((source) => ranges[source.id].use);
  function update(sourceId: string, update: Partial<(typeof ranges)[string]>) {
    setRanges((previous) => ({ ...previous, [sourceId]: { ...previous[sourceId], ...update } }));
  }

  async function submit(event: FormEvent) {
    event.preventDefault();
    if (busy || !chosen.length) return;
    setError("");
    setBusy(true);
    try {
      await api(base + "/jobs", jsonBody({
        scope,
        skill,
        sources: chosen.map(({ id }) => ({
          sourceId: id,
          ...(customRange ? { start: Number(ranges[id].start), end: Number(ranges[id].end) } : {}),
        })),
      }));
      await onSaved();
      close();
    } catch (error) {
      setError(message(error));
      setBusy(false);
    }
  }

  return <Modal title="生成学习资料 / Create study materials" onClose={() => { if (!busy) close(); }}>
    <form className="modal-form" onSubmit={submit}>
      {error && <Notice>{error}</Notice>}
      {provider?.key === false && <Notice><ProviderHint developer={developer} /></Notice>}
      {provider?.kit === false && <Notice>找不到 DeepSeek Harness。 / DeepSeek Harness is unavailable.</Notice>}
      <label>学习方案 / Study skill
        <select value={skill} disabled={busy} aria-describedby="study-skill-description"
          onChange={(event) => setSkill(event.target.value as StudySkill)}>
          {studySkillIds.map((id) => <option key={id} value={id}>{studySkills[id].label}</option>)}
        </select>
      </label>
      <p id="study-skill-description" className="api-help">
        技能备注 / Skill profile · {studySkills[skill].description}
        <br />当前网页成果可导出 Markdown。 / Web study materials export to Markdown.
      </p>
      <label>学习重点（选填） / Focus (optional)<input value={scope} maxLength={160} onChange={(event) => setScope(event.target.value)} placeholder="比较三类非谓语动词 / Compare three non-finite verb forms" /></label>
      <fieldset className="ranges" disabled={busy}>
        <legend>生成来源 / Sources</legend>
        <p className="api-help">默认使用所选资料的全部可读正文。长 PDF 会自动分批，合并成一份学习资料。 / Uses all readable text by default and combines long PDFs into one study kit.</p>
        {provider?.pdfVision && chosen.some(({ kind }) => kind === "pdf") && <p className="api-help">
          无文字层的页面会在生成时发给 DeepSeek 视觉读取，扫描书可能用时较长。 / Pages without a text layer are sent to DeepSeek for visual reading during generation.
        </p>}
        <label className="range-source"><input type="checkbox" checked={customRange}
          onChange={(event) => setCustomRange(event.target.checked)} /> 自定义页码或段落 / Choose specific pages or paragraphs</label>
        {sources.map((source) => {
          const range = ranges[source.id];
          return <div key={source.id} className="range">
            <label className="range-source"><input type="checkbox" checked={range.use} onChange={(event) => update(source.id, { use: event.target.checked })} /> <span>{source.title}</span></label>
            {range.use && source.kind === "pdf" && !source.textPending && source.readable < source.positions && <p className="selection-label">
              可读正文 {source.readable} / {source.positions} 页 / Readable pages
            </p>}
            {range.use && customRange && <div className="range-inputs">
              <small>{positionLabel(source)}</small>
              <input aria-label={source.title + " 起始位置"} type="number" min={1} max={source.positions} required value={range.start}
                onChange={(event) => update(source.id, { start: event.target.value })} /><span>至</span>
              <input aria-label={source.title + " 结束位置"} type="number" min={Number(range.start) || 1} max={source.positions} required value={range.end}
                onChange={(event) => update(source.id, { end: event.target.value })} />
            </div>}
          </div>;
        })}
      </fieldset>
      <footer><button className="button primary" disabled={busy || !chosen.length || provider?.key === false || provider?.kit === false}>
        {busy ? <LoaderCircle size={16} className="spin" /> : <Sparkles size={16} />} 开始生成 / Generate
      </button></footer>
    </form>
  </Modal>;
}

function Reader({ base, view, change }: { base: string; view: View; change: (view: View) => void }) {
  const [page, setPage] = useState<SourcePage>();
  const [error, setError] = useState("");
  const [pageDraft, setPageDraft] = useState<string>();
  const highlighted = useRef<HTMLElement>(null);
  const textBody = useRef<HTMLDivElement>(null);
  const current = page?.source.id === view.sourceId && page.position === view.position ? page : undefined;
  const pageInput = pageDraft ?? String(view.position);

  useEffect(() => {
    let active = true;
    api<SourcePage>(base + "/sources/" + view.sourceId + "?position=" + view.position).then((data) => {
      if (active) { setPage(data); setError(""); }
    }).catch((error) => { if (active) setError(message(error)); });
    return () => { active = false; };
  }, [base, view]);

  useEffect(() => {
    if (!current) return;
    if (view.citation) highlighted.current?.scrollIntoView({ block: "center" });
    else if (textBody.current) textBody.current.scrollTop = 0;
  }, [current, view.citation]);

  function go(position: number) {
    setPageDraft(undefined);
    if (!page || !Number.isInteger(position) || position < 1 || position > page.source.positions) return;
    if (position !== view.position) change({ sourceId: view.sourceId, position });
  }

  return <>
    {page && <div className="reader-title"><FileText size={20} /><h3>{page.source.title}</h3></div>}
    <div className="reader-controls">
      {page && <>
        <form onSubmit={(event) => { event.preventDefault(); go(Number(pageInput)); }}>
          <button type="button" className="icon-button" aria-label="上一处" disabled={view.position <= 1} onClick={() => go(view.position - 1)}><ChevronLeft size={18} /></button>
          <label>{positionLabel(page.source)} <input type="number" aria-label="原文位置" value={pageInput} min={1} max={page.source.positions} onChange={(event) => setPageDraft(event.target.value)} onBlur={() => {
            if (pageDraft !== undefined) go(Number(pageDraft));
          }} /> / {page.source.positions}</label>
          <button type="button" className="icon-button" aria-label="下一处" disabled={view.position >= page.source.positions} onClick={() => go(view.position + 1)}><ChevronRight size={18} /></button>
        </form>
        {page.source.kind === "pdf" && <a className="button outline" href={base + "/sources/" + view.sourceId + "/pdf#page=" + view.position} target="_blank" rel="noreferrer">打开 PDF <ArrowUpRight size={15} /></a>}
      </>}
    </div>
    <div className="reader-body" ref={textBody}>
      {error && <Notice>{error}</Notice>}
      {!current && !error && <div className="loading"><LoaderCircle className="spin" size={17} /> 正在读取原文</div>}
      {current?.chunks.some(({ visual }) => visual) && <p className="selection-label">
        本页文字来自模型视觉读取，可打开原始 PDF 核对。 / This text comes from visual reading. Check it against the original PDF.
      </p>}
      {current?.chunks.map((chunk) => {
        const quote = view.citation?.chunkId === chunk.id ? view.citation.quote : "";
        const offset = quote ? chunk.text.indexOf(quote) : -1;
        return <p key={chunk.id}>{offset >= 0 ? <>
          {chunk.text.slice(0, offset)}<mark ref={highlighted}>{quote}</mark>{chunk.text.slice(offset + quote.length)}
        </> : chunk.text}</p>;
      })}
      {current && !current.chunks.length && <p>{current.source.textPending
        ? "可打开原始 PDF 查看本页。 / Open the original PDF to view this page."
        : "本页没有可读文字，可打开原始 PDF 查看。 / This page has no readable text. Open the original PDF to view it."}</p>}
    </div>
  </>;
}

function ArtifactView({ base, artifact, sources, activeConcept, close, onRead }: {
  base: string; artifact: Artifact; sources: Source[]; activeConcept?: string; close: () => void; onRead: ReadCitation;
}) {
  const workbench = artifact.request.skill === "study-review-workbench";
  const [tab, setTab] = useState<"route" | "notes" | "quiz" | "cards" | "relations">(
    activeConcept || workbench ? "notes" : "route",
  );
  const [noteId, setNoteId] = useState(activeConcept);
  const review = artifact.kit.review;
  const names = new Map(artifact.kit.concepts.map(({ id, title }) => [id, title]));
  const target = useRef<HTMLElement>(null);
  useEffect(() => {
    if (tab !== "notes") return;
    target.current?.scrollIntoView({ block: "center" });
    target.current?.focus({ preventScroll: true });
  }, [tab, noteId]);
  function openNote(id: string) {
    setNoteId(id);
    setTab("notes");
  }
  return <Modal title={artifact.title} onClose={close} wide>
    <div className="artifact-toolbar">
      <span>版本 {artifact.version} · {date(artifact.createdAt)}{artifact.request.skill ? " · " + artifact.request.skill : ""}</span>
      <div className="artifact-exports">
        <a className="button primary" href={base + "/artifacts/" + artifact.id + "/pdf"}><ArrowDownToLine size={16} /> 导出 PDF / PDF</a>
        <a className="button outline" href={base + "/artifacts/" + artifact.id + "/markdown"}>Markdown</a>
      </div>
    </div>
    <div className="segmented review-tabs">
      {([["route", "学习路线"], ["notes", "讲义"], ["quiz", "自测"]] as const).map(([value, label]) =>
        <button key={value} aria-pressed={tab === value} onClick={() => setTab(value)}>{label}</button>
      )}
      {review && <>
        <button aria-pressed={tab === "relations"} onClick={() => setTab("relations")}>知识关联</button>
        <button aria-pressed={tab === "cards"} onClick={() => setTab("cards")}>闪卡</button>
      </>}
    </div>
    <div className="artifact-body">
      {tab === "route" && <>
        <div className="coverage">
          <h3>材料范围</h3>{artifact.request.scope && <p>{artifact.request.scope}</p>}
          {artifact.request.sources.map((range) => {
            const source = sources.find(({ id }) => id === range.sourceId);
            const readable = artifact.kit.examCoverage?.find(({ sourceId }) => sourceId === range.sourceId)?.readable;
            const start = range.start ?? 1;
            const end = range.end ?? source?.positions;
            return <p key={range.sourceId}>{source?.title ?? "资料"} · {source ? positionLabel(source) : "位置"} {start}–{end ?? "?"}
              {readable !== undefined && end !== undefined && <> · 正文 {readable}/{end - start + 1} / Readable</>}</p>;
          })}
        </div>
        {artifact.kit.examOverview && <section className="kit-item"><h3>知识地图 / Knowledge map</h3><p>{artifact.kit.examOverview}</p></section>}
        {review && <section className="kit-item"><h3>复习大纲 / Review outline</h3><p>{review.overview}</p></section>}
        {artifact.kit.route.map((step, index) => <section className="kit-item" key={index}>
          <h3>{index + 1}. {step.title.replace(/^第\s*\d+\s*步\s*[：:、.]?\s*/u, "")}</h3><p>{step.action}</p>
        </section>)}
      </>}
      {tab === "notes" && artifact.kit.concepts.map((concept) => <section className={"kit-item" + (noteId === concept.id ? " linked-concept" : "")}
        ref={noteId === concept.id ? target : undefined} tabIndex={noteId === concept.id ? -1 : undefined} key={concept.id}>
        <h3>{concept.title}</h3><p>{concept.explanation}</p><Citations refs={concept.refs} sources={sources} onRead={onRead} />
      </section>)}
      {tab === "quiz" && artifact.kit.questions.map((question, index) => <section className="kit-item" key={index}>
        <h3>第 {index + 1} 题{question.level && <> · {examLevelLabels[question.level]}</>}</h3><p>{question.prompt}</p><details><summary>查看答案与解析</summary>
          <p>{question.answer}</p><p>{question.explanation}</p><Citations refs={question.refs} sources={sources} onRead={onRead} />
        </details>
      </section>)}
      {tab === "relations" && review && (review.relations.length ? review.relations.map((relation, index) =>
        <section className="kit-item" key={index}>
          <h3>{reviewRelationLabels[relation.kind]}{relation.suggested && " · 编排建议 / Study suggestion"}</h3>
          <div className="review-links" aria-label="相关知识点 / Related concepts">
            <button className="button outline" onClick={() => openNote(relation.from)}>{names.get(relation.from)}</button>
            <span aria-hidden="true">{relation.kind === "contrast" ? "↔" : "→"}</span>
            <button className="button outline" onClick={() => openNote(relation.to)}>{names.get(relation.to)}</button>
          </div>
          <p>{relation.explanation}</p>
          <Citations refs={relation.refs} sources={sources} onRead={onRead} />
        </section>
      ) : <p>当前资料没有足够依据建立知识关联。 / No supported concept links in these materials.</p>)}
      {tab === "cards" && review?.cards.map((card, index) => <section className="kit-item" key={card.id}>
        <h3>{index + 1}. {card.front}</h3>
        <details><summary>翻看答案 / Reveal answer</summary>
          <p>{card.back}</p>
          <Citations refs={card.refs} sources={sources} onRead={onRead} />
          <div className="review-links">{card.conceptIds.map((id) => <button key={id} className="button outline"
            onClick={() => openNote(id)}>{names.get(id)}</button>)}</div>
        </details>
      </section>)}
    </div>
  </Modal>;
}
