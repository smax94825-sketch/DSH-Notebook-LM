import type { Metadata } from "next";
import "./studio.css";
import { WorkspaceEntry } from "./workspace-entry";
import { initializeTheme } from "./theme-preference";

export const metadata: Metadata = {
  title: "sky learning",
  description: "学习工作台 / Learning workspace",
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return <html lang="zh-CN" suppressHydrationWarning>
    <head><script dangerouslySetInnerHTML={{ __html: initializeTheme }} /></head>
    <body><div className="site-content"><WorkspaceEntry>{children}</WorkspaceEntry></div>
      <footer className="site-footer">
        <span>创作者联系 / Creator</span>
        <a href="mailto:smax94825@gmail.com">smax94825@gmail.com</a>
      </footer>
    </body>
  </html>;
}
