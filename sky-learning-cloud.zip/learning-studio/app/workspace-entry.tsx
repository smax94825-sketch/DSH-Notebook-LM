"use client";

import { ArrowRight } from "lucide-react";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, useSyncExternalStore } from "react";
import type { ReactNode } from "react";
import { SessionGate } from "./session";

const entryKey = "sky-learning-entered";
const subscribe = () => () => {};

function entrySnapshot() {
  const invite = new URLSearchParams(window.location.hash.slice(1)).has("invite");
  if (invite) return "workspace";
  try {
    if (sessionStorage.getItem(entryKey)) return "workspace";
  } catch { /* Cover remains usable when storage is disabled. */ }
  return "cover";
}

export function WorkspaceEntry({ children }: { children: ReactNode }) {
  const pathname = usePathname();
  const initial = useSyncExternalStore(subscribe, entrySnapshot, () => "checking");
  const [phase, setPhase] = useState<"idle" | "leaving" | "entered">("idle");
  const destination = useRef<HTMLDivElement>(null);
  const onHome = pathname === "/";
  const showCover = onHome && initial === "cover" && phase !== "entered";

  function finish() {
    try { sessionStorage.setItem(entryKey, "1"); }
    catch { /* The React state still remembers entry on this page. */ }
    setPhase("entered");
  }

  useEffect(() => {
    if (phase === "entered") destination.current?.focus({ preventScroll: true });
  }, [phase]);

  if (onHome && initial === "checking") return <div className="sky-entry-placeholder" aria-busy="true" />;

  return <>
    {(!showCover || phase === "leaving") && <div ref={destination} tabIndex={-1} inert={showCover} className="sky-entry-destination">
      <SessionGate>{children}</SessionGate>
    </div>}
    {showCover && <main className="sky-cover" data-leaving={phase === "leaving" || undefined}
      onAnimationEnd={(event) => { if (event.target === event.currentTarget) finish(); }}>
      <Image className="sky-cover-photo" src="/webb-cosmic-cliffs.jpg" alt="" fill sizes="100vw" preload unoptimized />
      <div className="sky-cover-content">
        <h1>Sky Learning</h1>
        <p>你的学习工作台 <span lang="en">Your learning workspace</span></p>
        <button className="sky-entry-button" type="button" disabled={phase === "leaving"} onClick={() => {
          if (window.matchMedia("(prefers-reduced-motion: reduce)").matches) finish();
          else setPhase("leaving");
        }}>
          <span>进入工作台 <small lang="en">Enter workspace</small></span><ArrowRight size={19} aria-hidden="true" />
        </button>
      </div>
      <a className="sky-cover-credit" href="https://science.nasa.gov/asset/webb/cosmic-cliffs-in-the-carina-nebula-nircam-image/"
        target="_blank" rel="noreferrer">Cosmic Cliffs · NGC 3324<br />NASA, ESA, CSA, STScI</a>
    </main>}
  </>;
}
