import { z } from "zod";
import { account, authAction, developerMode, feedbackEmail, inviteMode, saveFeedback } from "../../../lib/accounts.ts";
import { platformConnection, connectionFromInput, publicSettings, resetConnection, saveConnection } from "../../../lib/api-settings.ts";
import { answerDirectly, supportsPdfVision, testModelConnection } from "../../../lib/deepseek.ts";
import { developerSession, lockDeveloper, requireDeveloperUnlock, unlockDeveloper } from "../../../lib/developer-auth.ts";
import { developerSource, developerSources, developerUsers } from "../../../lib/developer-users.ts";
import { chatInput, id, kitInput, textInput, title } from "../../../lib/contracts.ts";
import { providerStatus } from "../../../lib/dsh.ts";
import { AppError, apiError } from "../../../lib/errors.ts";
import { kickJobs, kitRanges } from "../../../lib/jobs.ts";
import { knowledgeGraph } from "../../../lib/knowledge-graph.ts";
import { kitMarkdown } from "../../../lib/markdown.ts";
import { createProduction, editProduction, kickVideo, production, productions, streamVideo } from "../../../lib/productions.ts";
import { renderSlides } from "../../../lib/pptx.ts";
import { createSample } from "../../../lib/sample.ts";
import { conceptLibrary, studyAction, studyData } from "../../../lib/study.ts";
import { addPdf, addText, pdfResponse } from "../../../lib/sources.ts";
import { maxPdfBytes, pdfSizeMessage } from "../../../lib/upload-limit.ts";
import { beginPdfUpload, completePdfUpload, discardPdfUpload, receivePdfPart } from "../../../lib/pdf-upload.ts";
import { studyPdf } from "../../../lib/study-pdf.ts";
import {
  createNotebook, deleteNotebook, deleteSource, directChatHistory, getArtifact, getChunks, getNotebook, getSource, listNotebooks, listSources,
  queueJob, retryJob, saveExchange, setSourceSelected, workspace,
} from "../../../lib/store.ts";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type Context = { params: Promise<{ segments?: string[] }> };
const json = (value: unknown, status = 200) => Response.json(value, {
  status, headers: { "Cache-Control": "no-store" },
});

function verifyLocal(request: Request) {
  const host = request.headers.get("host") ?? "";
  const origin = request.headers.get("origin");
  const configured = process.env.STUDIO_PUBLIC_ORIGIN;
  if (inviteMode() && configured) {
    const publicOrigin = new URL(configured);
    if (publicOrigin.protocol === "https:" && host === publicOrigin.host && (!origin || origin === publicOrigin.origin)) return;
    throw new AppError("请使用配置的内测地址访问。", 403);
  }
  if (!/^(?:localhost|127\.0\.0\.1|\[::1\])(?::\d+)?$/i.test(host) ||
      (origin && origin !== "http://" + host && origin !== "https://" + host)) {
    throw new AppError("此工作台仅允许本机同源访问。", 403);
  }
}

async function dispatch(request: Request, context: Context) {
  verifyLocal(request);
  const parts = (await context.params).segments ?? [];
  const [resource, notebook, section, entity, action] = parts;
  const method = request.method;
  if (resource === "session" && method === "GET" && parts.length === 1) {
    const user = account(request);
    return json({ invite: inviteMode(), developer: developerMode() && user?.id === "local",
      user: user ? { name: user.name } : null, email: feedbackEmail() });
  }
  if (resource === "session" && method === "POST" && parts.length === 2) return authAction(request, notebook);
  const user = account(request);
  if (!user) throw new AppError("请先登录。", 401);
  if (resource === "feedback" && method === "POST" && parts.length === 1) {
    const body = z.object({ message: z.string().trim().min(1).max(4000) }).parse(await request.json());
    saveFeedback(user.id, body.message);
    return json({ ok: true }, 201);
  }
  if (method === "GET" && resource === "status" && parts.length === 1) return json(providerStatus(platformConnection()));
  if (resource === "developer") {
    if (!developerMode() || user.id !== "local") throw new AppError("需要本机开发者模式。 / Local developer mode required.", 403);
    if (notebook === "session" && parts.length === 2) {
      if (method === "GET") return json(developerSession(request));
      if (method === "POST") return unlockDeveloper(request);
      if (method === "DELETE") return lockDeveloper(request);
    }
    requireDeveloperUnlock(request);
    if (notebook === "users" && method === "GET") {
      if (parts.length === 2) return json(developerUsers());
      const userId = id.parse(section);
      if (entity === "sources" && parts.length === 4) return json(developerSources(userId));
      if (entity === "sources" && (parts.length === 5 || parts.length === 6 && parts[5] === "pdf")) {
        const source = developerSource(userId, id.parse(action));
        if (parts.length === 6) {
          if (source.kind !== "pdf") throw new AppError("找不到原始 PDF。 / Original PDF not found.", 404);
          return pdfResponse(source.id);
        }
        const position = sourcePosition(request, source.positions);
        return json({ source, position, chunks: getChunks(source.id, position, position) });
      }
    }
    if (notebook !== "settings") throw new AppError("找不到这个接口。", 404);
    if (parts.length === 2 && method === "GET") return json(publicSettings());
    if (parts.length === 2 && method === "PATCH") {
      const input = await request.json();
      requireDeveloperUnlock(request);
      return json(saveConnection(connectionFromInput(input)));
    }
    if (parts.length === 3 && section === "reset" && method === "POST") return json(resetConnection());
    if (parts.length === 3 && section === "test" && method === "POST") {
      const input = await request.json();
      requireDeveloperUnlock(request);
      const connection = connectionFromInput(input);
      await testModelConnection(connection);
      return json({ ok: true });
    }
  }
  if (method === "GET" && resource === "graph" && parts.length === 1) return json(knowledgeGraph(user.id));
  if (method === "GET" && resource === "concepts" && parts.length === 1) return json(conceptLibrary(user.id));
  if (method === "POST" && resource === "sample" && parts.length === 1) return json(createSample(user.id), 201);
  if (resource !== "notebooks") throw new AppError("找不到这个接口。", 404);
  if (parts.length === 1) {
    if (method === "GET") return json(listNotebooks(user.id));
    if (method === "POST") return json(createNotebook(z.object({ title }).parse(await request.json()).title, user.id), 201);
  }
  const notebookId = id.parse(notebook);
  getNotebook(notebookId, user.id);
  if (method === "GET" && parts.length === 2) {
    kickJobs();
    return json(workspace(notebookId));
  }
  if (method === "DELETE" && parts.length === 2) {
    deleteNotebook(notebookId, user.id);
    return json({ ok: true });
  }
  if (section === "pdf-uploads") {
    if (method === "POST" && parts.length === 3) {
      const input = z.object({ name: z.string().min(1).max(255), size: z.number().int().positive() }).parse(await request.json());
      return json(await beginPdfUpload(notebookId, input), 201);
    }
    const uploadId = id.parse(entity);
    if (method === "PUT" && parts.length === 5 && /^\d+$/.test(action)) {
      await receivePdfPart(notebookId, uploadId, Number(action), request.body);
      return json({ ok: true });
    }
    if (method === "POST" && parts.length === 4) return json(await completePdfUpload(notebookId, uploadId), 201);
    if (method === "DELETE" && parts.length === 4) {
      await discardPdfUpload(notebookId, uploadId);
      return json({ ok: true });
    }
  }
  if (section === "sources") {
    if (method === "POST" && parts.length === 3) {
      const type = request.headers.get("content-type")?.split(";")[0];
      const size = Number(request.headers.get("content-length") ?? 0);
      if (type === "application/pdf") {
        if (size > maxPdfBytes) throw new AppError(pdfSizeMessage, 413);
        const name = z.string().min(1).max(255).parse(new URL(request.url).searchParams.get("filename"));
        return json(await addPdf(notebookId, name, request.body), 201);
      }
      if (type === "multipart/form-data") {
        if (size > maxPdfBytes + 1024 * 1024) throw new AppError(pdfSizeMessage, 413);
        const file = (await request.formData()).get("file");
        if (!(file instanceof File)) throw new AppError("请选择 PDF 文件。");
        if (file.size > maxPdfBytes) throw new AppError(pdfSizeMessage, 413);
        return json(await addPdf(notebookId, file.name, file.stream()), 201);
      }
      const input = textInput.parse(await request.json());
      return json(addText(notebookId, input.title, input.text), 201);
    }
    const sourceId = id.parse(entity);
    if (method === "DELETE" && parts.length === 4) {
      deleteSource(notebookId, sourceId);
      return json({ ok: true });
    }
    const source = getSource(notebookId, sourceId, method === "GET");
    if (method === "PATCH" && parts.length === 4) {
      const { selected } = z.object({ selected: z.boolean() }).parse(await request.json());
      setSourceSelected(notebookId, source.id, selected);
      return json({ ...source, selected });
    }
    if (method === "GET" && action === "pdf" && parts.length === 5 && source.kind === "pdf") {
      return pdfResponse(source.id);
    }
    if (method === "GET" && parts.length === 4) {
      const position = sourcePosition(request, source.positions);
      return json({ source, position, chunks: getChunks(source.id, position, position) });
    }
  }
  if (section === "chat" && method === "POST" && parts.length === 3) {
    const { question } = chatInput.parse(await request.json());
    const answer = await answerDirectly(question, directChatHistory(notebookId), platformConnection());
    return json(saveExchange(notebookId, question, answer), 201);
  }
  if (section === "jobs" && method === "POST") {
    if (parts.length === 3) {
      const input = kitInput.parse(await request.json());
      const sources = kitRanges(notebookId, input, supportsPdfVision(platformConnection()))
        .map(({ sourceId, start, end }) => ({ sourceId, start, end }));
      sources.sort((a, b) => a.sourceId.localeCompare(b.sourceId));
      const job = queueJob(notebookId, {
        scope: input.scope, sources, ...(input.skill && input.skill !== "standard" ? { skill: input.skill } : {}),
      });
      kickJobs();
      return json(job, 202);
    }
    if (action === "retry" && parts.length === 5) {
      retryJob(notebookId, id.parse(entity));
      kickJobs();
      return json({ ok: true }, 202);
    }
  }
  if (section === "artifacts" && method === "GET" && (parts.length === 4 || (action === "markdown" || action === "pdf") && parts.length === 5)) {
    const artifact = getArtifact(notebookId, id.parse(entity));
    if (!action) return json(artifact);
    const sources = listSources(notebookId, true);
    const pdf = action === "pdf";
    const extension = pdf ? "pdf" : "md";
    const body = pdf ? new Uint8Array(await studyPdf(artifact, sources)) : kitMarkdown(artifact, sources);
    return new Response(body, { headers: {
      "Content-Type": pdf ? "application/pdf" : "text/markdown; charset=utf-8",
      "Content-Disposition": `attachment; filename="study-kit-v${artifact.version}.${extension}"; filename*=UTF-8''${encodeURIComponent(artifact.title + "." + extension).replace(/['()*]/g, (char) => "%" + char.charCodeAt(0).toString(16))}`,
      "Cache-Control": "no-store",
    } });
  }
  if (section === "study") {
    if (method === "GET" && parts.length === 3) return json(studyData(notebookId, user.id));
    if (method === "POST" && parts.length === 4) return json(studyAction(notebookId, user.id, entity, await request.json()));
  }
  if (section === "productions") {
    if (parts.length === 3 && method === "GET") {
      kickVideo();
      return json(productions(notebookId));
    }
    if (parts.length === 3 && method === "POST") return json(createProduction(notebookId, await request.json()), 201);
    const itemId = id.parse(entity);
    if (method === "PATCH" && (parts.length === 4 || parts.length === 5)) {
      return json(editProduction(notebookId, itemId, action, await request.json()));
    }
    if (method === "GET" && (parts.length === 4 || parts.length === 5)) {
      kickVideo();
      const item = production(notebookId, itemId);
      if (parts.length === 4) return json(item);
      if (item.stage !== "ready") throw new AppError("请先完成审核或渲染。", 409);
      if (action === "mp4" && item.kind === "video") return streamVideo(request, item);
      if (action === "pptx" && item.kind === "slides" && item.content.slides) {
        const { kit } = getArtifact(notebookId, item.artifactId);
        const bytes = await renderSlides(item.content.outline, item.content.slides, kit, listSources(notebookId, true));
        return new Response(new Uint8Array(bytes), { headers: {
          "Content-Type": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
          "Content-Disposition": "attachment; filename=lesson.pptx",
          "Cache-Control": "no-store",
        } });
      }
    }
  }
  throw new AppError("找不到这个接口。", 404);
}

function sourcePosition(request: Request, positions: number) {
  return z.coerce.number().int().min(1).max(positions).parse(new URL(request.url).searchParams.get("position") ?? 1);
}

async function handle(request: Request, context: Context) {
  try {
    return await dispatch(request, context);
  } catch (error) {
    return apiError(error);
  }
}

export const GET = handle;
export const POST = handle;
export const PUT = handle;
export const PATCH = handle;
export const DELETE = handle;
