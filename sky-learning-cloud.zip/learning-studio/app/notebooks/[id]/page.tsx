import { NotebookStudio } from "../../studio";

export default async function NotebookPage({ params, searchParams }: {
  params: Promise<{ id: string }>; searchParams: Promise<{ artifact?: string; concept?: string }>;
}) {
  const [{ id }, query] = await Promise.all([params, searchParams]);
  return <NotebookStudio key={id} id={id} linkedArtifact={query.artifact} linkedConcept={query.concept} />;
}
