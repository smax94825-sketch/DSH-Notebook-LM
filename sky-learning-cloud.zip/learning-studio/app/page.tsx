import { NotebookLibrary } from "./studio";

export default function Home() {
  return <NotebookLibrary />;
}
