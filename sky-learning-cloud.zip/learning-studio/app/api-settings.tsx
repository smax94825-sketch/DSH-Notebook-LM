"use client";

import { useEffect, useState } from "react";
import type { FormEvent } from "react";
import type { ApiSettings } from "../lib/api-settings";
import { api, ApiRequestError, jsonBody, message, Notice } from "./ui";

const endpoint = "/api/developer/settings";

export function ApiSettingsForm({ onLocked }: { onLocked: () => void }) {
  const [settings, setSettings] = useState<ApiSettings>();
  const [baseUrl, setBaseUrl] = useState("");
  const [model, setModel] = useState("");
  const [key, setKey] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [status, setStatus] = useState("");

  function fill(value: ApiSettings) {
    setSettings(value);
    setBaseUrl(value.baseUrl);
    setModel(value.model);
    setKey("");
  }

  useEffect(() => {
    let active = true;
    void api<ApiSettings>(endpoint).then((data) => { if (active) fill(data); })
      .catch((error) => {
        if (!active) return;
        if (error instanceof ApiRequestError && error.status === 401) onLocked();
        else setError(message(error));
      });
    return () => { active = false; };
  }, [onLocked]);

  async function change(action: "save" | "test" | "reset") {
    setBusy(true);
    setError("");
    setStatus("");
    try {
      const input = { baseUrl, model, key };
      if (action === "test") {
        await api(endpoint + "/test", jsonBody(input));
        setStatus("连接成功 / Connection successful");
        return;
      }
      fill(action === "save"
        ? await api<ApiSettings>(endpoint, jsonBody(input, "PATCH"))
        : await api<ApiSettings>(endpoint + "/reset", { method: "POST" }));
      setStatus(action === "save" ? "已保存全平台设置 / Platform settings saved" : "已恢复服务器默认设置 / Server defaults restored");
    } catch (error) {
      if (error instanceof ApiRequestError && error.status === 401) onLocked();
      else setError(message(error));
    }
    finally { setBusy(false); }
  }

  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const button = (event.nativeEvent as SubmitEvent).submitter as HTMLButtonElement | null;
    void change(button?.value === "test" ? "test" : "save");
  }

  return <form className="modal-form api-form" onSubmit={submit}>
      {error && <Notice>{error}</Notice>}
      {status && <p className="settings-status" role="status">{status}</p>}
      {settings ? <>
        <fieldset className="api-fields" disabled={busy}>
          <legend>全平台模型接口 / Platform Model API</legend>
          <p className="api-help">保存后所有账号的问答和学习资料生成共用此配置。密钥仅保存在服务端。 / All accounts use this configuration for chat and study materials. The key stays on the server.</p>
          <label>接口地址 / API Base URL<input type="url" required value={baseUrl}
            maxLength={300} placeholder="https://api.deepseek.com" onChange={(event) => setBaseUrl(event.target.value)} /></label>
          <label>模型 ID / Model ID<input required value={model} maxLength={128} placeholder="deepseek-flash"
            onChange={(event) => setModel(event.target.value)} /></label>
          <label>密钥 / API Key<input type="password" value={key} maxLength={2048} autoComplete="new-password"
            placeholder={settings.hasKey ? "已配置，留空保留 / Leave blank to keep" : "输入密钥 / Enter API key"}
            onChange={(event) => setKey(event.target.value)} /></label>
          <p className="api-help">支持 OpenAI 兼容的 Chat Completions 与 JSON 输出。 / Supports OpenAI-compatible Chat Completions with JSON output.</p>
        </fieldset>
        <footer>
          {settings.saved && <button type="button" className="button quiet" disabled={busy} onClick={() => void change("reset")}>恢复默认 / Reset</button>}
          <button type="submit" className="button outline" value="test" disabled={busy}>测试连接 / Test</button>
          <button type="submit" className="button primary" value="save" disabled={busy}>保存 / Save</button>
        </footer>
      </> : !error && <p className="loading">正在读取设置 / Loading settings</p>}
    </form>;
}
