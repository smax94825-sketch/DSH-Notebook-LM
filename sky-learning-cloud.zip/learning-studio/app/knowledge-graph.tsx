"use client";

import { forceCenter, forceCollide, forceLink, forceManyBody, forceSimulation } from "d3-force";
import type { Simulation, SimulationLinkDatum, SimulationNodeDatum } from "d3-force";
import { ArrowUpRight, Minus, Plus, Scan } from "lucide-react";
import Link from "next/link";
import { useEffect, useMemo, useRef, useState } from "react";
import type { PointerEvent } from "react";
import type { GraphData, GraphEdge, GraphNode } from "../lib/knowledge-graph";
import { api, message, Notice } from "./ui";

const width = 800;
const height = 392;
const defaultCamera = { x: 0, y: 0, scale: 1 };
const relations = {
  contains: "所属笔记本 / Notebook membership", related: "相关 / Related",
  prerequisite: "前置知识 / Prerequisite", contrast: "对照 / Contrast",
};
type Point = { x: number; y: number };
type LayoutNode = GraphNode & SimulationNodeDatum;
type LayoutLink = Omit<GraphEdge, "source" | "target"> & SimulationLinkDatum<LayoutNode>;

function visibleGraph(data: GraphData, root: string | undefined, depth: number, hideIsolated: boolean) {
  const neighbors = new Map(data.nodes.map(({ id }) => [id, [] as string[]]));
  for (const edge of data.edges) {
    neighbors.get(edge.source)?.push(edge.target);
    neighbors.get(edge.target)?.push(edge.source);
  }
  const visible = root ? new Set([root]) : new Set(neighbors.keys());
  let frontier = root ? [root] : [];
  for (let level = 0; level < depth && frontier.length; level++) {
    const next: string[] = [];
    for (const id of frontier) {
      for (const neighbor of neighbors.get(id) ?? []) {
        if (visible.has(neighbor)) continue;
        visible.add(neighbor);
        next.push(neighbor);
      }
    }
    frontier = next;
  }
  const edges = data.edges.filter(({ source, target }) => visible.has(source) && visible.has(target));
  const connected = new Set(edges.flatMap(({ source, target }) => [source, target]));
  const nodes = data.nodes.filter(({ id }) => visible.has(id) && (!hideIsolated || connected.has(id) || id === root));
  return { nodes, edges };
}

export function KnowledgeGraph({ notebookId, refreshKey, onNavigate }: {
  notebookId?: string; refreshKey?: unknown; onNavigate?: () => void;
}) {
  const [data, setData] = useState<GraphData>();
  const [error, setError] = useState("");
  const [root, setRoot] = useState(notebookId);
  const [depth, setDepth] = useState(3);
  const [hideIsolated, setHideIsolated] = useState(false);
  const [selectedId, setSelectedId] = useState(notebookId);
  const [camera, setCamera] = useState(defaultCamera);
  const svg = useRef<SVGSVGElement>(null);
  const layer = useRef<SVGGElement>(null);
  const simulation = useRef<Simulation<LayoutNode, LayoutLink> | null>(null);
  const drag = useRef<{ id?: string; start: Point; camera: typeof defaultCamera; moved: boolean } | null>(null);
  const skipClick = useRef(false);

  useEffect(() => {
    let active = true;
    void api<GraphData>("/api/graph").then((value) => {
      if (active) { setData(value); setError(""); }
    }).catch((error) => { if (active) setError(message(error)); });
    return () => { active = false; };
  }, [refreshKey]);

  const visible = useMemo(() => data && visibleGraph(data, root, depth, hideIsolated), [data, root, depth, hideIsolated]);
  const selected = visible?.nodes.find((node) => node.id === selectedId);

  useEffect(() => {
    if (!visible?.nodes.length || !layer.current) return;
    const groups = [...layer.current.querySelectorAll<SVGGElement>("[data-node]")];
    const lines = [...layer.current.querySelectorAll<SVGLineElement>("[data-edge]")];
    const nodes: LayoutNode[] = visible.nodes.map((node) => ({ ...node }));
    const links: LayoutLink[] = visible.edges.map((edge) => ({ ...edge }));
    const physics = forceSimulation<LayoutNode, LayoutLink>(nodes)
      .force("link", forceLink<LayoutNode, LayoutLink>(links).id((node) => node.id)
        .distance((edge) => edge.relation === "contains" ? 84 : 115))
      .force("charge", forceManyBody().strength(-175))
      .force("collision", forceCollide<LayoutNode>().radius((node) => node.kind === "notebook" ? 29 : 24))
      .force("center", forceCenter(width / 2, height / 2));
    simulation.current = physics;
    function paint() {
      nodes.forEach(({ x, y }, index) => groups[index].setAttribute("transform", `translate(${x ?? 0}, ${y ?? 0})`));
      links.forEach((edge, index) => {
        const { x: sx, y: sy } = edge.source as LayoutNode;
        const { x: tx, y: ty } = edge.target as LayoutNode;
        const line = lines[index];
        line.setAttribute("x1", String(sx)); line.setAttribute("y1", String(sy));
        line.setAttribute("x2", String(tx)); line.setAttribute("y2", String(ty));
      });
    }
    physics.stop().tick(150);
    paint();
    fitGraph();
    physics.on("tick", paint);
    return () => { physics.stop(); simulation.current = null; };
  }, [visible]);

  useEffect(() => {
    const element = svg.current;
    if (!element) return;
    const wheel = (event: WheelEvent) => {
      const matrix = element.getScreenCTM();
      if (!matrix) return;
      event.preventDefault();
      const point = new DOMPoint(event.clientX, event.clientY).matrixTransform(matrix.inverse());
      zoom(Math.exp(-event.deltaY * 0.0015), point);
    };
    element.addEventListener("wheel", wheel, { passive: false });
    return () => element.removeEventListener("wheel", wheel);
  }, [!!visible?.nodes.length]);

  function zoom(factor: number, point: Point = { x: width / 2, y: height / 2 }) {
    setCamera((current) => {
      const scale = Math.min(3, Math.max(0.1, current.scale * factor));
      const ratio = scale / current.scale;
      return { x: point.x - (point.x - current.x) * ratio, y: point.y - (point.y - current.y) * ratio, scale };
    });
  }
  function point(event: PointerEvent<SVGElement>, element: SVGGraphicsElement) {
    const matrix = element.getScreenCTM();
    return matrix && new DOMPoint(event.clientX, event.clientY).matrixTransform(matrix.inverse());
  }
  function start(event: PointerEvent<SVGSVGElement>) {
    if (event.button !== 0) return;
    const location = point(event, event.currentTarget);
    if (!location) return;
    const id = (event.target as Element).closest<SVGGElement>("[data-node]")?.dataset.node;
    skipClick.current = false;
    drag.current = { id, start: location, camera, moved: false };
    if (!id) event.currentTarget.setPointerCapture(event.pointerId);
  }
  function move(event: PointerEvent<SVGSVGElement>) {
    const active = drag.current;
    if (!active) return;
    const current = point(event, event.currentTarget);
    if (!current) return;
    const dx = current.x - active.start.x;
    const dy = current.y - active.start.y;
    if (!active.moved && Math.hypot(dx, dy) < 5) return;
    if (!active.moved) event.currentTarget.setPointerCapture(event.pointerId);
    active.moved = true;
    if (!active.id) {
      setCamera({ ...active.camera, x: active.camera.x + dx, y: active.camera.y + dy });
      return;
    }
    const physics = simulation.current;
    const node = physics?.nodes().find(({ id }) => id === active.id);
    const location = layer.current && point(event, layer.current);
    if (!node || !location || !physics) return;
    node.fx = location.x;
    node.fy = location.y;
    if (physics.alphaTarget() === 0) physics.alphaTarget(0.25).restart();
  }
  function end() {
    const active = drag.current;
    if (!active) return;
    skipClick.current = active.moved;
    drag.current = null;
    const physics = simulation.current;
    const node = active.id && physics?.nodes().find(({ id }) => id === active.id);
    if (node && active.moved) { node.fx = null; node.fy = null; physics?.alphaTarget(0); }
  }
  function setScope(id: string | undefined) {
    setRoot(id);
    setSelectedId(id);
  }
  const adjacent = new Set(visible?.edges.flatMap(({ source, target }) =>
    source === selected?.id || target === selected?.id ? [source, target] : []));

  return <section className="graph" aria-label="知识图谱 / Knowledge graph">
    <div className="graph-toolbar">
      <button className="button quiet" aria-pressed={!root} onClick={() => setScope(undefined)}>全局 / Global</button>
      {notebookId && <button className="button quiet" aria-pressed={root === notebookId} onClick={() => setScope(notebookId)}>本笔记本 / This notebook</button>}
      {root && <label>邻居层数 / Depth <select aria-label="邻居层数 / Depth" value={depth} onChange={(event) => setDepth(Number(event.target.value))}>
        {[1, 2, 3].map((level) => <option key={level}>{level}</option>)}
      </select></label>}
      <label><input type="checkbox" checked={hideIsolated} onChange={(event) => setHideIsolated(event.target.checked)} /> 隐藏孤立节点 / Hide isolated</label>
    </div>
    {error && <Notice>{error}</Notice>}
    {!data && !error && <p className="loading">读取图谱 / Loading graph</p>}
    {visible && !visible.nodes.length && <p className="graph-empty">当前视图没有节点。 / No nodes in this view.</p>}
    {!!visible?.nodes.length && <>
      <div className="graph-canvas">
        <svg className="graph-plot" viewBox={`0 0 ${width} ${height}`} ref={svg} aria-label="可交互关系图 / Interactive network"
          onPointerDown={start} onPointerMove={move} onPointerUp={end} onPointerCancel={end} onLostPointerCapture={end}>
          <g ref={layer} transform={`translate(${camera.x}, ${camera.y}) scale(${camera.scale})`}>
            {visible.edges.map((edge) => <line key={edge.id} data-edge={edge.id} data-relation={edge.relation}>
              <title>{relations[edge.relation]}</title></line>)}
            {visible.nodes.map((node) => <g key={node.id} data-node={node.id} data-kind={node.kind}
              data-neighbor={adjacent.has(node.id) || undefined} role="button" tabIndex={0}
              aria-label={node.label} aria-pressed={node.id === selected?.id}
              onClick={() => { if (!skipClick.current) setSelectedId(node.id); }}
              onKeyDown={(event) => {
                if (event.key !== "Enter" && event.key !== " ") return;
                event.preventDefault(); setSelectedId(node.id);
              }}>
              <title>{node.label}</title>
              <circle className="node-hit" r={21} />
              <circle className="node-dot" r={node.kind === "notebook" ? 10 : 6} />
              <text y={node.kind === "notebook" ? -17 : 18}>{node.label.length > 21 ? node.label.slice(0, 20) + "…" : node.label}</text>
            </g>)}
          </g>
        </svg>
        <div className="graph-zoom">
          <button className="icon-button" aria-label="放大 / Zoom in" onClick={() => zoom(1.22)}><Plus size={17} /></button>
          <button className="icon-button" aria-label="缩小 / Zoom out" onClick={() => zoom(1 / 1.22)}><Minus size={17} /></button>
          <button className="icon-button" aria-label="适合窗口 / Fit graph" onClick={() => fitGraph()}><Scan size={17} /></button>
        </div>
      </div>
      <div className="graph-legend"><span><i />笔记本 / Notebook</span><span><i />知识点 / Topic</span><span><i />跨笔记本关联 / Cross-notebook link</span></div>
      {selected && <div className="graph-selection">
        <div><strong>{selected.label}</strong>{selected.kind === "concept" && <small>{selected.notebookTitle}</small>}</div>
        {selected.id !== root && <button className="button outline" onClick={() => setScope(selected.id)}>查看邻居 / Explore neighbors</button>}
        <Link className="button quiet" href={selected.href} onClick={onNavigate}>打开 / Open <ArrowUpRight size={15} /></Link>
      </div>}
    </>}
  </section>;

  function fitGraph() {
    const bounds = layer.current?.getBBox();
    if (!bounds) return;
    const scale = Math.min(1, (width - 55) / Math.max(1, bounds.width), (height - 55) / Math.max(1, bounds.height));
    setCamera({ scale, x: width / 2 - (bounds.x + bounds.width / 2) * scale, y: height / 2 - (bounds.y + bounds.height / 2) * scale });
  }
}
